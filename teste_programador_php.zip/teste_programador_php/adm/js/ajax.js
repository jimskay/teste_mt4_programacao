//	RETURN A XML HTTP OBJECT
function ajaxRequest() {
	var $ajax = false;

	if (window.XMLHttpRequest) {
		$ajax = new XMLHttpRequest();
		if ($ajax.overrideMimeType) {
			$ajax.overrideMimeType('text/xml');
		}
	}else if(window.ActiveXObject) { 
		try {
			$ajax = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				$ajax = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {}
		}
	}
	return $ajax;
}

//	CONNECT WITH SERVER
//	[object XMLHTTP] [function] [url] [attributes] [method(get or post)]
function ajaxCon(ajaxConObj,ajaxConFunc,ajaxConUrl,ajaxConAtt,ajaxConMethod){
	ajaxConAjax = ajaxConObj;
	var $function = ajaxConFunc;
	var $url = ajaxConUrl;
	var $att = ajaxConAtt;
	var $method = ajaxConMethod;
	ajaxConAjax.onreadystatechange = $function;
	if($method=='post'){
		ajaxConAjax.open('post',$url,true);
		ajaxConAjax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		ajaxConAjax.send($att);
	}else{
		ajaxConAjax.open('get',$url+"?"+$att,true);
		ajaxConAjax.send(null);
	}
}