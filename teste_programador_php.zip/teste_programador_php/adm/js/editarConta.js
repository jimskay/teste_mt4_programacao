//	*****	BONO - CLIENTE

//	ESTA FUN��O � UTILIZADA EM CONJUNTO COM A FUN��O DE RETORNO "existsEmailR" que se encontra no arquivo cliente.js
function existsOtherEmail(existsOtherEmailStr, existsOtherEmailTo, existsOtherEmailRef){
	var $str = existsOtherEmailStr;
	var $ref = existsOtherEmailRef;
	existsEmailObj = document.getElementById(existsOtherEmailTo);
	var $validation = new Validation();
	
	if($validation.checkEmail($str)===true){
		//	Email FOI DIGITADO CORRETAMENTE, FAZENDO VERIFICA��O SE JA EXISTE
		existsEmailAjax = ajaxRequest();
		ajaxCon(existsEmailAjax,existsEmailR,ROOT_HTTP+'atributos/bibliotecas/ajaxPages/existsOtherEmail.php','email='+$str+'&ref='+$ref,'get');
	}else{
		existsEmailObj.style.display = 'none';
	}
}

function alterarSenha(alterarSenhaForm){
	var $form = alterarSenhaForm;
	var $senhaCliente = $form.senhaCliente;
	var $confirmarSenhaCliente = $form.confirmarSenhaCliente;
	var $validation = new Validation();
	
	if($validation.checkLogin($senhaCliente.value)===false){
		$senhaCliente.focus();
		alert('O campo senha deve conter extamente 10 caracteres.');
		return false;
	}
	if($senhaCliente.value!=$confirmarSenhaCliente.value){
		$confirmarSenhaCliente.value='';
		$confirmarSenhaCliente.focus();
		alert('Confirmar��o de senha n�o confere.');
		return false;
	}
	
	var $q = confirm('Deseja realmente alterar sua senha?');
	return $q;
}

function minhaConta(minhaContaForm){
	var $form = minhaContaForm;
	var $validation = new Validation();
	var $tipoCliente = $form.tipoCliente;
	if($tipoCliente.value=='2'){
		var $razaoSocialCliente = $form.razaoSocialCliente;
		var $nomeFantasiaCliente = $form.nomeFantasiaCliente;
		var $ieCliente = $form.ieCliente;
		if($razaoSocialCliente.value==''){
			$razaoSocialCliente.focus();
			alert('Preencha corretamente o campo razao social.');
			return false;
		}
	}
	var $nomeCliente = $form.nomeCliente;
	var $enderecoRuaCliente = $form.enderecoRuaCliente;
	var $enderecoNumeroCliente = $form.enderecoNumeroCliente;
	var $enderecoComplementoCliente = $form.enderecoComplementoCliente;
	var $cepCliente = $form.cepCliente;
	var $cidadeCliente = $form.cidadeCliente;
	var $estadoCliente = $form.estadoCliente;
	var $contatoCliente = $form.contatoCliente;
	var $msnCliente = $form.msnCliente;
	var $skypeCliente = $form.skypeCliente;
	var $dddTelefoneComercialCliente = $form.dddTelefoneComercialCliente;
	var $telefoneComercialCliente = $form.telefoneComercialCliente;
	var $ramalTelefoneComercialCliente = $form.ramalTelefoneComercialCliente;
	var $dddCelularCliente = $form.dddCelularCliente;
	var $dddNextelCliente = $form.dddNextelCliente;
	var $celularCliente = $form.celularCliente;
	var $nextelCliente = $form.nextelCliente;
	var $radioCliente = $form.radioCliente;
	var $dddTelefoneResidencialCliente = $form.dddTelefoneResidencialCliente;
	var $telefoneResidencialCliente = $form.telefoneResidencialCliente;
	var $dddFaxCliente = $form.dddFaxCliente;
	var $faxCliente = $form.faxCliente;
	var $ramalFaxCliente = $form.ramalFaxCliente;
	var $emailContatoCliente = $form.emailContatoCliente;
	
	if($nomeCliente.value.replace(/^\s+/,"")==''){
		$nomeCliente.focus();
		alert('Preencha corretamente o campo nome.');
		return false;
	}
	if($enderecoRuaCliente.value.replace(/^\s+/,"")==''){
		$enderecoRuaCliente.focus();
		alert('Preencha corretamente o campo endere�o.');
		return false;
	}
	if($enderecoNumeroCliente.value.replace(/^\s+/,"")==''){
		$enderecoNumeroCliente.focus();
		alert('O campo n�mero � obrigat�rio.');
		return false;
	}
	if($cepCliente.value.replace(/^\s+/,"")==''){
		$cepCliente.focus();
		alert('O campo CEP � obrigat�rio.');
		return false;
	}
	if($estadoCliente.value == '-1'){
		$estadoCliente.focus();
		alert('Selecione o estado corretamente.');
		return false;
	}
	if(($telefoneResidencialCliente.value.replace(/^\s+/,"")=='')||($dddTelefoneResidencialCliente.value.replace(/^\s+/,"")=='')){
		$telefoneResidencialCliente.focus();
		alert('Preencha corretamente o campo de telefone residencial.');
		return false;
	}			
	
	//	FAZENDO VALIDA�AO DE CAMPOS NAO OBRIGAT�RIOS
	if($enderecoNumeroCliente.value!=''){
		if($validation.checkInt($enderecoNumeroCliente.value)===false){
			$enderecoNumeroCliente.focus();
			alert('Preencha um n�mero de endere�o v�lido, apenas n�meros.');
			return false;
		}
	}
	if($cepCliente.value!=''){
		if($validation.checkCEP($cepCliente.value)===false){
			$cepCliente.focus();
			alert('Preencha um cep v�lido.');
			return false;
		}
	}
	if($msnCliente.value!=''){
		if($validation.checkEmail($msnCliente.value)===false){
			$msnCliente.focus();
			alert('Preencha um endere�o de MSN v�lido.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE TELEFONE COMERCIAL	*/
	if($dddTelefoneComercialCliente.value!='' || $telefoneComercialCliente.value!='' || $ramalTelefoneComercialCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddTelefoneComercialCliente.value)===false){
			$dddTelefoneComercialCliente.focus();
			alert('Preencha um DDD v�lido para o telefone comercial, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($telefoneComercialCliente.value)===false){
			$telefoneComercialCliente.focus();
			alert('Preencha um telefone comercial v�lido, apenas n�meros.');
			return false;
		}
		if($ramalTelefoneComercialCliente.value!=''){
			//	POSSUI UM RAMAL, VERIFICANDO VALOR
			if($validation.checkInt($ramalTelefoneComercialCliente.value)===false){
				$ramalTelefoneComercialCliente.focus();
				alert('Preencha um ramal v�lido para o telefone comercial, apenas n�meros.');
				return false;
			}
		}
	}
	
	/*	VALIDA�AO DE TELEFONE CELULAR	*/
	if($dddCelularCliente.value!='' || $celularCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddCelularCliente.value)===false){
			$dddCelularCliente.focus();
			alert('Preencha um DDD v�lido para o celular, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($celularCliente.value)===false){
			$celularCliente.focus();
			alert('Preencha um celular v�lido, apenas n�meros.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE NEXTEL	*/
	if($dddNextelCliente.value!='' || $nextelCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddNextelCliente.value)===false){
			$dddNextelCliente.focus();
			alert('Preencha um DDD v�lido para o nextel, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($nextelCliente.value)===false){
			$nextelCliente.focus();
			alert('Preencha um nextel v�lido, apenas n�meros.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE TELEFONE RESIDENCIAL	*/
	if($dddTelefoneResidencialCliente.value!='' || $telefoneResidencialCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddTelefoneResidencialCliente.value)===false){
			$dddTelefoneResidencialCliente.focus();
			alert('Preencha um DDD v�lido para o telefone residencial, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($telefoneResidencialCliente.value)===false){
			$telefoneResidencialCliente.focus();
			alert('Preencha um telefone residencial v�lido, apenas n�meros.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE FAX	*/
	if($dddFaxCliente.value!='' || $faxCliente.value!='' || $ramalFaxCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddFaxCliente.value)===false){
			$dddFaxCliente.focus();
			alert('Preencha um DDD v�lido para o fax, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($faxCliente.value)===false){
			$faxCliente.focus();
			alert('Preencha um fax v�lido, apenas n�meros.');
			return false;
		}
		if($ramalFaxCliente.value!=''){
			//	POSSUI UM RAMAL, VERIFICANDO VALOR
			if($validation.checkInt($ramalFaxCliente.value)===false){
				$ramalFaxCliente.focus();
				alert('Preencha um ramal v�lido para o fax, apenas n�meros.');
				return false;
			}
		}
	}
	
	/*	VALIDA��O DO EMAIL	*/
	if($validation.checkEmail($emailContatoCliente.value)===false){
		$emailContatoCliente.focus();
		alert('Preencha um endere�o de email v�lido.');
		return false;
	}
	//	VERIFICANDO SE EMAIL JA EXISTE
	var $exists = document.getElementById('informationEmail').style.display;
	if($exists=='inline'){
		$emailContatoCliente.focus();
		alert('Este e-mail j� existe, insira um e-mail v�lido.');
		return false;
	}
	
	var $q = confirm('Deseja realmente alterar suas informa��es pessoais?');
	return $q;
}