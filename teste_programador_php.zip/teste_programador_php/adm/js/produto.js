//	*****	BONO - PRODUTO
/*
> showImg - amplia uma imagem pequena [1. url da imagem ampliada , 2. id do objeto que contem a imagem a receber a nova url]
*/

function showImg(showImgURL,showImgTo,UrlImg,idObject){
	var $url = showImgURL;
	var $to = document.getElementById(showImgTo);
	$to.firstChild.setAttribute('src',ROOT_HTTP+'atributos/imagens/global/loading.gif');
	$to.firstChild.setAttribute('src',$url);
	
	var $idObject = document.getElementById(idObject);
	$idObject.setAttribute("href",UrlImg);
	
}