//	*****	MOTION FUNCTIONS
//	*****	AS FUN��ES ABAIXO DEVEM INICIAR COM O PREFIXO m_
/*
> m_x - remove poss�veis caracteres de medida
> m_vertical - movimenta um objeto na posi��o vertical [1. id do objeto, 2. posi��o inicial , 3. posi��o final]
> m_imgAmp - redimensiona uma imagem com o evento onmouseover e onmouseaout, objeto deve conter um id [1. objto imagem, 2. largura inicial, 3. altura inicial, 4. largura final, 5. altura final]
> m_move - movimenta um objeto [1. id do objeto, 2. evento]
*/

function m_x(m_xStr){
	var $str = m_xStr;
	var $src = /[^0-9|^\-|^\.]/g;
	return $str.replace($src,'');
}

//	ARRAY QUE COMPORTA INTERVAL
m_interval = new Array();

function m_vertical(m_verticalId,m_verticalStart,m_verticalFinal){
	var $obj = document.getElementById(m_verticalId);
	var $start = m_verticalStart;
	var $final = m_verticalFinal;
	//	ATRIBUINDO POSI��O NEGATIVA
	$obj.style.marginTop = $start+'px';
	m_interval[$obj.id] = setInterval(
	function(){
		var $atual = $obj.style.marginTop;
		$atual = m_x($atual)*1;
		$atual += Math.floor(($final-$atual)*0.3);
		if($atual>$final-5&&$atual<$final+5){
			$atual = $final;
			clearInterval(m_interval[$obj.id]);
		}
		$obj.style.marginTop = $atual+'px';
	}
	,80);
}

function m_horizontal(m_horizontalId,m_horizontalStart,m_horizontalFinal){
	var $obj = document.getElementById(m_horizontalId);
	var $start = m_horizontalStart;
	var $final = m_horizontalFinal;
	//	ATRIBUINDO POSI��O NEGATIVA
	$obj.style.marginLeft = $start+'px';
	m_interval[$obj.id] = setInterval(
	function(){
		var $atual = $obj.style.marginLeft;
		$atual = m_x($atual)*1;
		$atual += Math.floor(($final-$atual)*0.3);
		if($atual>$final-5&&$atual<$final+5){
			$atual = $final;
			clearInterval(m_interval[$obj.id]);
		}
		$obj.style.marginLeft = $atual+'px';
	}
	,80);
}

function m_imgAmp(m_imgAmpObj,m_imgAmpWI,m_imgAmpHI,m_imgAmpWF,m_imgAmpHF){
	var $obj = m_imgAmpObj;
	var $wI = m_imgAmpWI;
	var $hI = m_imgAmpHI;
	var $wF = m_imgAmpWF*1;
	var $hF = m_imgAmpHF*1;
	$obj.style.width = $wI+'px';
	$obj.style.height = $hI+'px';
	clearInterval(m_interval[$obj.id]);
	m_interval[$obj.id] = setInterval(
	function(){
		var $wA = $obj.style.width;
		var $hA = $obj.style.height;
		$wA = m_x($wA)*1;
		$hA = m_x($hA)*1;
		$wA += Math.floor(($wF-$wA)*0.3);
		$hA += Math.floor(($hF-$hA)*0.3);
		if($wA>$wF-5&&$wA<$wF+5 && $hA>$hF-5&&$hA<$hF+5){
			$wA = $wF;
			$hA = $hF;
			clearInterval(m_interval[$obj.id]);
		}
		$obj.style.width = $wA+'px';
		$obj.style.height = $hA+'px';
	}
	,80);
}

function m_move(m_moveId,m_moveEvent){
	var $obj = document.getElementById(m_moveId);
	var $event = m_moveEvent;
	$obj.style.position = 'absolute';
	$obj.onmousemove = function(){
		$obj.style.left = $event.pageX;
	}
	return false;
	m_interval[$obj.id] = setInterval(
	function(){
		var $x = $event.pageX;
		var $y = $event.pageY;
		$obj.style.left = $x+'px';
		$obj.style.top = $y+'px';
		$obj.innerHTML = $x;
	}
	,60000);
}
/*
clicado = false;

function coordenadas(event)
{
x = (event.clientX*1)-10;
y = (event.clientY*1)-10;
obj = document.getElementById('ttt');
	if(clicado==false){
		clicado=true;
		obj.style.position = 'absolute';
		obj.style.top = y+'px';
		obj.style.left = x+'px';
		obj.onmousemove = function(event){
			x = (event.clientX*1)-10;
			y = (event.clientY*1)-10;
			obj.style.top = y+'px';
			obj.style.left = x+'px';
		}
	}else{
		clicado=false;
		obj.onmousemove = function(){
		}
	}
}
*/

function m_moveXOver(m_moveXOverObj,m_moveXOverDist){
	var $obj = m_moveXOverObj;
	var $dist = m_moveXOverDist;
	$obj.style.marginLeft = '0px';
	m_clearInterval($obj.id);
	m_interval[$obj.id] = setInterval(
	function(){
		var $margin = $obj.style.marginLeft;
		$margin = m_x($margin)*1;
		$margin+= ($dist-$margin)*0.3;
		$obj.style.marginLeft = $margin+'px';
		if($margin>($dist-2)&&$margin<($dist+2)){
			m_clearInterval($obj.id);
		}
	}
	,60);
}

function m_moveXOut(m_moveXOutObj){
	var $obj = m_moveXOutObj;
	m_clearInterval($obj.id);
	m_interval[$obj.id] = setInterval(
	function(){
		var $margin = $obj.style.marginLeft;
		$margin = m_x($margin)*1;
		$margin+= (0-$margin)*0.3;
		$obj.style.marginLeft = $margin+'px';
	}
	,60);
}

function m_clearInterval(m_clearIntervalId){
	clearInterval(m_interval[m_clearIntervalId]);
}