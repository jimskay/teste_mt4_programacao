//	*****	UTIL FUNCTIONS
/*
> removeAtt - remove um atributo [1. id do objeto, 2. atributo a ser removido]
> $$ - substitui o 'document.getElementById();' [1. id do objeto]
> toBlur - retira o foco de um objeto quando alcan�ado o n�mero maximo de caracteres (maxlength), normalmente utilizado com o evento onkeyup [1. objeto , destino de foco]
>removeValue - remove um valor de um elemento deixando-o nulo [1. id]
> getCidade - resgata uma lista de cidades para um objeto select [1. c�digo do estado , 2. id do objeto select cidade]
> getCidadeR - fun�ao de resposta a fun�ao getCidade, � respons�vel por inserir as cidades no objeto select
> getCidadeSQLServer - resgata uma lista de cidades para um objeto select [1. c�digo do estado , 2. id do objeto select cidade]
> getProduto - resgata os dados do produto para a inser��o no campo.
> getProdutoR - fun�ao de resposta a fun�ao getProduto, � respons�vel por inserir o valor no campo DIV e INPUT
> windowOpen - abre uma nova janela [1. url , 2. nome da janela , 3. outros parametros ]
> onlyLower - determina apenas os caracteres aceitos no campo de login e senha (usar com evento 'onkeyup') [1. objeto input]
> float2moeda - // FUN��O PARA FORMATAR O CAMPO COM APENAS 2 CASAS DECIMAIS - REAL
*/
function onlyLower(onlyLowerObj){
	var $obj = onlyLowerObj;
	var $not = /[^a-z|^0-9]/g;
	var $value = $obj.value;
	$obj.value = $value.replace($not,'');
	return null;
}
function removeAtt(setAttId,setAttType){
	var $id = document.getElementById(setAttId);
	var $type = setAttType;
	if($type=='class'){
		$id.removeAttribute('class');
		$id.removeAttribute('className');
	}else{
		$id.removeAttribute($type);
	}
}

function $$(id) {
	return document.getElementById(id);
}

function toBlur(toBlurObj,toBlurTo){
	var $obj = toBlurObj;
	var $value = $obj.value;
	var $limit = $obj.getAttribute('maxlength');
	var $to = document.getElementById(toBlurTo);
	if($value.length>=$limit){
		$to.focus();
	}
}

function removeValue(getId){
	var $element = document.getElementById(getId);
	$element.value = "";
}

function getCidade(getCidadeEstado,getCidadeId){
	var $estado = getCidadeEstado;
	if($estado=='-1'||$estado==''){
		return null;
	}else{
		getCidadeObj = document.getElementById(getCidadeId);
		getCidadeObj.setAttribute('disabled','disabled');
		while(getCidadeObj.hasChildNodes()){
			getCidadeObj.removeChild(getCidadeObj[0]);
		}
		var $dom = new Dom();
		var $loading = $dom.option('Carregando . . .','-1');
		getCidadeObj.appendChild($loading);
		
		getCidadeAjax = ajaxRequest();
		ajaxCon(getCidadeAjax,getCidadeR,ROOT_HTTP+'quise/atributos/bibliotecas/ajaxPages/getCidade.php','cdEstado='+$estado,'get');
	}
}

function getCidadeSQLServer(getCidadeEstado,getCidadeId){
	var $estado = getCidadeEstado;
	if($estado=='-1'||$estado==''){
		return null;
	}else{
		getCidadeObj = document.getElementById(getCidadeId);
		getCidadeObj.setAttribute('disabled','disabled');
		while(getCidadeObj.hasChildNodes()){
			getCidadeObj.removeChild(getCidadeObj[0]);
		}
		var $dom = new Dom();
		var $loading = $dom.option('Carregando . . .','-1');
		getCidadeObj.appendChild($loading);
		
		getCidadeAjax = ajaxRequest();
		ajaxCon(getCidadeAjax,getCidadeR,ROOT_HTTP+'quise/atributos/bibliotecas/ajaxPages/getCidadeSQLServer.php','cdEstado='+$estado,'get');
	}
}

function getCidadeR(){
	var $dom = new Dom();
	if(getCidadeAjax.readyState==4){
		if(getCidadeAjax.status==200){
			var $docxml = getCidadeAjax.responseXML;
			if($docxml.hasChildNodes()){
				while(getCidadeObj.hasChildNodes()){
					getCidadeObj.removeChild(getCidadeObj[0]);
				}
				var $cidades = $docxml.getElementsByTagName('cidade');
				for(var $i=0;$i<$cidades.length;$i++){
					var $node = $cidades[$i];
					$option = $dom.option($node.childNodes[0].nodeValue,$node.getAttribute('value'));
					getCidadeObj.appendChild($option);
				}
				getCidadeObj.removeAttribute('disabled');
				getCidadeObj.focus();
			}else{
				while(getCidadeObj.hasChildNodes()){
					getCidadeObj.removeChild(getCidadeObj[0]);
				}
				var $error = $dom.option('Erro ao listar cidades.','-1');
				getCidadeObj.appendChild($error);
			}
		}else{
			while(getCidadeObj.hasChildNodes()){
				getCidadeObj.removeChild(getCidadeObj[0]);
			}
			var $error = $dom.option('P�gina nao encontrada, contate o adminstrador para mais informa�oes.','-1');
			getCidadeObj.appendChild($error);
		}
	}
}

function getProduto(ItemCode,divPriceUnit,inputPriceUnit,divPriceSum,inputPriceSum){
	var $ItemCode = ItemCode;
	if($ItemCode=='-1'||$ItemCode==''){
		return null;
	}else{
		divPriceUnit = document.getElementById(divPriceUnit);
		inputPriceUnit = document.getElementById(inputPriceUnit);
		divPriceSum = document.getElementById(divPriceSum);
		inputPriceSum = document.getElementById(inputPriceSum);
		divSum = document.getElementById('divSum');
		inputSum = document.getElementById('inputSum');
		Price = document.getElementById('Price');
		
		divPriceUnit.innerHTML = divPriceSum.innerHTML = divSum.innerHTML = "Carregando...";
		getProdutoAjax = ajaxRequest();
		ajaxCon(getProdutoAjax,getProdutoR,ROOT_HTTP+'quise/atributos/bibliotecas/ajaxPages/getProduto.php','Pro='+$ItemCode,'get');
	}
}

function getProdutoR(){	
	var $dom = new Dom();
	if(getProdutoAjax.readyState==4){
		if(getProdutoAjax.status==200){
			var $docxml = getProdutoAjax.responseXML;
			if($docxml.hasChildNodes()){
				var $ItemCode = $docxml.getElementsByTagName('ItemCode');
				divPriceUnit.innerHTML = divPriceSum.innerHTML = divSum.innerHTML = "R$ "+$ItemCode[0].childNodes[0].nodeValue;
				inputPriceUnit.value = inputPriceSum.value = Price.value = inputPriceSum.value = inputSum.value = $ItemCode[0].childNodes[0].nodeValue;
			}else{
				divPriceUnit.innerHTML = "Erro ao resgatar valor";
				inputPriceUnit.value= 0;
			}
		}else{
			divPriceUnit.innerHTML = "P�gina n�o encontrada. Contate o administrador do sistema.";
			inputPriceUnit.value = 0;
		}
	}
}

function getEquipamento(valueIn,idLocalNext){
	var $valueSelect = valueIn;
	if($valueSelect=='-1'||$valueSelect==''){
		return null;
	}else{		
		nextIdObject = document.getElementById(idLocalNext);
		nextIdObject.innerHTML = 'Carregando campo de equipamentos. . .';
		getEquipamentoAjax = ajaxRequest();
		ajaxCon(getEquipamentoAjax,getEquipamentoR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/getEquipamento.php','marca='+$valueSelect,'get');
	}
}

function getEquipamentoSpecial(valueIn,idLocalNext){
	var $valueSelect = valueIn;
	if($valueSelect=='-1'||$valueSelect==''){
		return null;
	}else{		
		nextIdObject = document.getElementById(idLocalNext);
		nextIdObject.innerHTML = 'Carregando campo de equipamentos. . .';
		getEquipamentoAjax = ajaxRequest();
		ajaxCon(getEquipamentoAjax,getEquipamentoR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/getEquipamentoSpecial.php','marca='+$valueSelect,'get');
	}
}

function getEquipamentoR(){
	if(getEquipamentoAjax.readyState==4){
		if(getEquipamentoAjax.status==200){
			var $doctxt = getEquipamentoAjax.responseText;
			nextIdObject.innerHTML = $doctxt;
		}else{
			nextIdObject.innerHTML = 'Problema ao carregar os equipamentos! Por favor, tente novamente.';
		}
	}
}

function getModelo(valueIn,idLocalNext){
	idLocalNext = 'localModelos';
	var $valueSelect = valueIn;
	if($valueSelect=='-1'||$valueSelect==''){
		return null;
	}else{		
		nextIdObject = document.getElementById(idLocalNext);
		nextIdObject.innerHTML = 'Carregando campo de modelos. . .';
		getModeloAjax = ajaxRequest();
		ajaxCon(getModeloAjax,getModeloR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/getModelo.php','equipamento='+$valueSelect+'&marca='+document.getElementById('marcaEquipto').value,'get');
	}
}

function getModeloR(){
	if(getModeloAjax.readyState==4){
		if(getModeloAjax.status==200){
			var $doctxt = getModeloAjax.responseText;
			nextIdObject.innerHTML = $doctxt;
		}else{
			nextIdObject.innerHTML = 'Problema ao carregar os modelos! Por favor, tente novamente.';
		}
	}
}


function windowOpen(windowOpenURL, windowOpenName, windowOpenParam){
	var $url = windowOpenURL;
	var $name = windowOpenName;
	var $param = windowOpenParam;
	window.open($url,$name,$param);
}

// FUN��O PARA FORMATAR O CAMPO COM APENAS 2 CASAS DECIMAIS - REAL

function float2moeda(num) {
	x = 0;
	if(num<0) {
		num = Math.abs(num);
		x = 1;
	}
	
	if(isNaN(num)) num = "0";
	cents = Math.floor((num*100+0.5)%100);	
	num = Math.floor((num*100+0.5)/100).toString();
	
	if(cents < 10) cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++){
		num = num.substring(0,num.length-(4*i+3))+'.'+num.substring(num.length-(4*i+3));
	}	
	ret = num + ',' + cents;
	if (x == 1) ret = ' - ' + ret;
	
	//return ret;
	alert(ret);
	
}			   

