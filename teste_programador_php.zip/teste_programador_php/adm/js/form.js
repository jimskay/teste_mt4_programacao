//	VERIFICA�AO AO CADASTRAR
function emailTalentos(emailForm){
	
	var $form = emailForm;
	var $nome = $form.nome;
	var $email = $form.email;
	var $telefone = $form.telefone;
	var $curriculo = $form.curriculo;
		
	var $validation = new Validation();	//	OBJETO PARA VALIDA�AO

	if($validation.checkOnlySpace($nome.value)===false){
		$nome.focus();
		alert('Preencha corretamente o campo Nome.');
		return false;
	}

	if($validation.checkOnlySpace($email.value)===false){
		$email.focus();
		alert('Preencha corretamente o campo Email.');
		return false;
	}

	if($validation.checkOnlySpace($telefone.value)===false){
		$telefone.focus();
		alert('Preencha corretamente o campo Telefone.');
		return false;
	}

	if($validation.checkOnlySpace($curriculo.value)===false){
		$curriculo.focus();
		alert('Selecione o seu curr�culum.');
		return false;
	}

	var $q = window.confirm('Voce deseja realmente CADASTRAR como talento?');
	return $q;
}

function emailFaleConosco(emailFaleConoscoForm){
	var $form = emailFaleConoscoForm;
	var $nome = $form.nome;
	var $email = $form.email;
	var $tel = $form.tel;
	var $assunto = $form.assunto;
	var $mensagem = $form.mensagem;
	var $validation = new Validation();
	if($validation.checkOnlySpace($nome.value)===false){
		$nome.focus();
		alert('Preencha corretamente o campo Nome.');
		return false;
	}
	if($validation.checkEmail($email.value)===false){
		$email.focus();
		alert('Preencha seu e-mail corretamente.');
		return false;
	}
	if($validation.checkOnlySpace($assunto.value)===false){
		$assunto.focus();
		alert('Preencha corretamente o campo Assunto.');
		return false;
	}
	var $q = window.confirm('Deseja realmente enviar esta mensagem?');
	return $q;
}

function cotacaoOnline(cotacaoOnlineForm){
	var $form = cotacaoOnlineForm;
	var $nome = $form.nome;
	var $cnpj = $form.cnpj;
	var $cargo = $form.cargo;
	var $empresa = $form.empresa;
	var $email = $form.email;
	var $telefone = $form.telefone;
	var $detalhes = $form.detalhes;

	var $validation = new Validation();
	
	if($validation.checkOnlySpace($nome.value)===false){
		$nome.focus();
		alert('Preencha corretamente o campo Nome.');
		return false;
	}

	if($validation.checkOnlySpace($cnpj.value)===false){
		$cnpj.focus();
		alert('Preencha corretamente o campo CNPJ.');
		return false;
	}

	if($validation.checkOnlySpace($cargo.value)===false){
		$cargo.focus();
		alert('Preencha corretamente o campo Cargo.');
		return false;
	}

	if($validation.checkOnlySpace($empresa.value)===false){
		$empresa.focus();
		alert('Preencha corretamente o campo Empresa.');
		return false;
	}

	if($validation.checkOnlySpace($email.value)===false){
		$email.focus();
		alert('Preencha corretamente o campo Email.');
		return false;
	}

	if($validation.checkOnlySpace($telefone.value)===false){
		$telefone.focus();
		alert('Preencha corretamente o campo Telefone.');
		return false;
	}

	if($validation.checkOnlySpace($detalhes.value)===false){
		$detalhes.focus();
		alert('Preencha corretamente o campo Detalhes.');
		return false;
	}


	
	var $q = window.confirm('Deseja realmente enviar esta cota��o?');
	return $q;
}