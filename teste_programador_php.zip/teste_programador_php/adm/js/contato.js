// JavaScript Document
function checkFaleConosco(checkFaleConoscoForm){
	var $form = checkFaleConoscoForm;
	var $nome = $form.nome;
	var $email = $form.email;
	var $dddTelefone = $form.dddTelefone;
	var $telefone = $form.telefone;
	var $assunto = $form.assunto;
	var $mensagem = $form.mensagem;
	var $validation = new Validation();	//	OBJETO PARA VALIDA�AO
	//	CHECK ACTION
	if($form.getAttribute('action') !='atributos/bibliotecas/action/faleConosco.php'){
		alert('Erro inesperado. Esta p�gina nao pode continuar.');
		self.location = 'default.php';
		return false;
	}
	
	if($validation.checkOnlySpace($nome.value)===false){
		$nome.focus();
		alert('Preencha corretamente seu nome.');
		return false;
	}
	
	if($validation.checkEmail($email.value)===false){
		$email.focus();
		alert('Preencha corretamente seu e-mail.');
		return false;
	}
	
	//	VERIFICA SE H� ALGUM CAMPO DO TELEFONE PREENCHIDO
	if($dddTelefone.value!=''||$telefone.value!=''){
		//	CHECANDO OS CAMPOS DO TELEFONE
		if($validation.checkDDD($dddTelefone.value)===false){
			$dddTelefone.focus();
			alert('Preencha corretamente o DDD do telefone.');
			return false;
		}
		if($validation.checkPhoneNumber($telefone.value)===false){
			$telefone.focus();
			alert('Preencha corretamente o n�mero do telefone.');
			return false;
		}
	}
	
	if($validation.checkOnlySpace($assunto.value)===false){
		$assunto.focus();
		alert('Preencha corretamente um assunto para esta mensagem.');
		return false;
	}
	
	var $q = window.confirm('Deseja enviar esta mensagem para nossa �rea de contato?');
	return $q;
}