//-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#
// Loja Exemplo Locaweb
// Vers�o: 6.5
// Data: 12/09/06
// Arquivo: func_config.js
// Vers�o do arquivo: 0.0
// Data da ultima atualiza��o: 20/10/08
//
//-----------------------------------------------------------------------------
// Licen�a C�digo Livre: http://comercio.Locaweb.com.br/gpl/gpl.txt
//-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#

function mostrahelp(linha,img) {
	var linha = document.getElementById(linha);
	if (linha.style.display=='none') {
		linha.style.display='block';
		if(img != null) {
			img.src='../atributos/imagens/2.0/duvida-close.png';
		}
	} else {
		linha.style.display='none';
		if(img != null) {
			img.src='../atributos/imagens/2.0/duvida.png';
		}
	}
}

function mostracampo(linha) {
	var linha = document.getElementById(linha);
	if (linha.style.display=='none') {
		linha.style.display='block';
	} else {
		linha.style.display='none';
	}
}

function openDocuments(obj, div, plus, sent){
	if(obj.checked==true){
		div.style.display = "block";
		plus.style.display = "block";
		sent.style.display = "block";
	}else{
		div.style.display = "none";
		plus.style.display = "none";
		sent.style.display = "none";
	}
}

function changeDocumentLabel(obj, obj2){
	obj.value = obj2.value;
}

function addDocument(obj, count){
	var countdocuments = parseInt(count.value) + 1;
	var inner = obj.innerHTML;
	var newinner = "";
	newinner += "<div style=\"border:1px solid #E1E1E1;padding:10px;-webkit-border-radius: 6px;border-radius: 6px;width:96.5%;height:50px;margin:5px;\" id=\"div_document_" + countdocuments + "\">";
	newinner += "<label>Nome do documento: <span style=\"font-style:italic;font-size:10px;\">(Ex: Manual, Vista explodida, etc.)</span></label><br />";
	newinner += "<input type=\"text\" class=\"text big\" name=\"nomeDocumento_" + countdocuments + "\" id=\"nomeDocumento_" + countdocuments + "\" style=\"width:395px;\"/>";
	newinner += "<input type=\"text\" class=\"text big\" name=\"docNomeDocumento2\" id=\"docNomeDocumento2_" + countdocuments + "\" style=\"width:395px;position:absolute;margin-left:5px;\" disabled=\"disabled\" value=\"Clique aqui para escolher um arquivo...\"/>";
	newinner += "<input type=\"file\" class=\"FORMbox\" name=\"docNomeDocumento_" + countdocuments + "\" id=\"docNomeDocumento_" + countdocuments + "\" size=\"69\" style=\"width:200px;opacity:0;height:30px;\" onchange=\"return changeDocumentLabel(document.getElementById('docNomeDocumento2_" + countdocuments + "'),this);\"/>";
	newinner += "</div>";
	obj.innerHTML = inner + newinner;
	count.value = countdocuments;
}

function addPhoto(obj, count){
	var countdocuments = parseInt(count.value) + 1;
	var inner = obj.innerHTML;
	var newinner = "";
	newinner += "<div style=\"border:1px solid #E1E1E1;padding:10px;-webkit-border-radius: 6px;border-radius: 6px;width:96.5%;height:30px;margin:5px;\" id=\"div_photo_" + countdocuments + "\">";
	newinner += "<label for=\"fotoProduto\">Foto "+countdocuments+":</label>";
	newinner += "<input type=\"file\" class=\"FORMbox\" size=\"79\" id=\"fotoProduto_"+countdocuments+"\" name=\"fotoProduto_"+countdocuments+"\">";
	newinner += "</div>";
	obj.innerHTML = inner + newinner;
	count.value = countdocuments;
}

/*function addCategory(obj, count, add1){
	console.log(add1.innerHTML);return false;
	var countdocuments = parseInt(count.value) + 1;
	var inner = obj.innerHTML;
	var newinner = "";
	newinner += "<div style=\"border:1px solid #E1E1E1;padding:10px;-webkit-border-radius: 6px;border-radius: 6px;width:96.5%;height:50px;margin:5px;\" id=\"div_document_" + countdocuments + "\">";
	newinner += "<label>Nome do documento: <span style=\"font-style:italic;font-size:10px;\">(Ex: Manual, Vista explodida, etc.)</span></label><br />";
	newinner += "<input type=\"text\" class=\"text big\" name=\"nomeDocumento_" + countdocuments + "\" id=\"nomeDocumento_" + countdocuments + "\" style=\"width:395px;\"/>";
	newinner += "<input type=\"text\" class=\"text big\" name=\"docNomeDocumento2\" id=\"docNomeDocumento2_" + countdocuments + "\" style=\"width:395px;position:absolute;margin-left:5px;\" disabled=\"disabled\" value=\"Clique aqui para escolher um arquivo...\"/>";
	newinner += "<input type=\"file\" class=\"FORMbox\" name=\"docNomeDocumento_" + countdocuments + "\" id=\"docNomeDocumento_" + countdocuments + "\" size=\"69\" style=\"width:200px;opacity:0;height:30px;\" onchange=\"return changeDocumentLabel(document.getElementById('docNomeDocumento2_" + countdocuments + "'),this);\"/>";
	newinner += "</div>";
	obj.innerHTML = inner + newinner;
	count.value = countdocuments;
}*/

function addCategory(obj, count, ROOT_HTTP_ADMIN){
	var countdocuments = parseInt(count.value) + 1;
	addCategoryAjax = ajaxRequest();
	ajaxCon(addCategoryAjax,addCategoryR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/addCategory.php','countdocuments='+countdocuments,'get');
}

function addCor(obj, count, ROOT_HTTP_ADMIN){
	var countdocuments = parseInt(count.value) + 1;
	addCorAjax = ajaxRequest();
	ajaxCon(addCorAjax,addCorR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/addCor.php','countdocuments='+countdocuments,'get');
}

function addTamanho(obj, count, ROOT_HTTP_ADMIN){
	var countdocuments = parseInt(count.value) + 1;
	addTamanhoAjax = ajaxRequest();
	ajaxCon(addTamanhoAjax,addTamanhoR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/addTamanho.php','countdocuments='+countdocuments,'get');
}

function addCategoryR(){
	var nextIdObject = document.getElementById('place_category');
	var countdocuments = document.getElementById('count_category');
	if(addCategoryAjax.readyState==4){
		if(addCategoryAjax.status==200){
			var $doctxt = addCategoryAjax.responseText;
                        var select = document.createElement('select');
                        select.innerHTML = $doctxt;
                        select.className = 'selectform';
                        select.id = 'idCategoria_' + (parseInt(countdocuments.value) + 1);
                        select.name = 'idCategoria_' + (parseInt(countdocuments.value) + 1);
                        select.setAttribute('style', 'width:280px;margin-right:5px;');
                        select.setAttribute('onchange', "return getSubcategoria(this.value,\'idSubcategoria_" + (parseInt(countdocuments.value) + 1) + "\',\'idSubcategoria1_" + (parseInt(countdocuments.value) + 1) +"\')");
                        nextIdObject.appendChild(select);
                        
                        //subcategoria 1
                        var select_subcat_1 = document.createElement('select');
						var option_subcat_1 = document.createElement('option');
                        //select.innerHTML = $doctxt;
                        select_subcat_1.className = 'selectform';
                        select_subcat_1.id = 'idSubcategoria_' + (parseInt(countdocuments.value) + 1);
                        select_subcat_1.name = 'idSubcategoria_' + (parseInt(countdocuments.value) + 1);
                        select_subcat_1.setAttribute('style', 'width:280px;margin-right:4px;');
                        select_subcat_1.setAttribute('disabled', 'disabled');
						option_subcat_1.value = '-1';
						option_subcat_1.innerHTML = "<-- Selecione uma Categoria";
						option_subcat_1.setAttribute('selected','selected');
						select_subcat_1.appendChild(option_subcat_1);
                        nextIdObject.appendChild(select_subcat_1);
                        
                        //subcategoria 2
                        var select_subcat_2 = document.createElement('select');
                        var option_subcat_2 = document.createElement('option');
                        //select.innerHTML = $doctxt;
                        select_subcat_2.className = 'selectform';
                        select_subcat_2.id = 'idSubcategoria1_' + (parseInt(countdocuments.value) + 1);
                        select_subcat_2.name = 'idSubcategoria1_' + (parseInt(countdocuments.value) + 1);
                        select_subcat_2.setAttribute('style', 'width:280px;margin-right:1px;');
                        select_subcat_2.setAttribute('disabled', 'disabled');
						option_subcat_2.value = '-1';
						option_subcat_2.innerHTML = "<-- Selecione uma Subcategoria";
						option_subcat_2.setAttribute('selected','selected');
						select_subcat_2.appendChild(option_subcat_2);
                        nextIdObject.appendChild(select_subcat_2);
			//nextIdObject.innerHTML += $doctxt;
			countdocuments.value = parseInt(countdocuments.value) + 1;
		}else{
			nextIdObject.innerHTML += 'Problema ao inserir mais categorias! Por favor, tente novamente.';
		}
	}
}

function addCorR(){
	var nextIdObject = document.getElementById('place_cor');
        //alert(nextIdObject.innerHTML);
	var countdocuments = document.getElementById('count_cor');
	if(addCorAjax.readyState==4){
		if(addCorAjax.status==200){
			var $doctxt = addCorAjax.responseText;
                        var select = document.createElement('select');
                        select.innerHTML = $doctxt;
                        select.className = 'selectform';
                        select.id = 'idCor' + (parseInt(countdocuments.value) + 1);
                        select.name = 'idCor' + (parseInt(countdocuments.value) + 1);
                        nextIdObject.appendChild(select);
			//nextIdObject.innerHTML += $doctxt;
			countdocuments.value = parseInt(countdocuments.value) + 1;
		}else{
			nextIdObject.innerHTML += 'Problema ao inserir mais cores! Por favor, tente novamente.';
		}
	}
}

function addTamanhoR(){
	var nextIdObject = document.getElementById('place_tamanho');
	var countdocuments = document.getElementById('count_tamanho');
	if(addTamanhoAjax.readyState==4){
		if(addTamanhoAjax.status==200){
			var $doctxt = addTamanhoAjax.responseText;
                        var select = document.createElement('select');
                        select.innerHTML = $doctxt;
                        select.className = 'selectform';
                        select.id = 'idTamanho' + (parseInt(countdocuments.value) + 1);
                        select.name = 'idTamanho' + (parseInt(countdocuments.value) + 1);
                        nextIdObject.appendChild(select);
			//nextIdObject.innerHTML += $doctxt;
			countdocuments.value = parseInt(countdocuments.value) + 1;
		}else{
			nextIdObject.innerHTML += 'Problema ao inserir mais tamanhos! Por favor, tente novamente.';
		}
	}
}

function removeElement(id) {

	var lista    = document.getElementById('divProdutoRel');
	var elemento = document.getElementById(id);
	lista.removeChild(elemento);

}

function addJunto(obj, count, ROOT_HTTP_ADMIN){
	var countdocuments = parseInt(count.value) + 1;
	addJuntoAjax = ajaxRequest();
	if (countdocuments >= 5) {
		alert('S� � permitido no m�ximo 4 itens relacionados!');
	} else {
		ajaxCon(addJuntoAjax,addJuntoR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/addJunto.php','countdocuments='+countdocuments,'get');
	}
}

function addJuntoR(){
	var nextIdObject = document.getElementById('place_junto');
	var countdocuments = document.getElementById('count_junto');
	if(addJuntoAjax.readyState==4){
		if(addJuntoAjax.status==200){
			var $doctxt = addJuntoAjax.responseText;
                        var select = document.createElement('select');
                        var div = document.createElement('div');
                        div.setAttribute('style', 'width:380px;float:left;');
                        div.setAttribute('id', 'divProdutoRel');	
						div.innerHTML = '<label>PRODUTO ' + (parseInt(countdocuments.value) + 1) + ':</label>';
                        select.innerHTML = $doctxt;
                        select.className = 'selectform';
                        select.id = 'idProdutoJunto_' + (parseInt(countdocuments.value) + 1);
                        select.setAttribute('style', 'width:840px;margin-right:5px;');
                        select.name = 'idProdutoJunto_' + (parseInt(countdocuments.value) + 1);
                        div.innerHTML = '<a href="" onclick="removeElement('+select.id +');">Excluir Produto</a>';
                        nextIdObject.appendChild(div);
                        nextIdObject.appendChild(select);
			//nextIdObject.innerHTML += $doctxt;
			countdocuments.value = parseInt(countdocuments.value) + 1;
		}else{
			nextIdObject.innerHTML += 'Problema ao inserir mais produtos! Por favor, tente novamente.';
		}
	}
}


function addRelacionado(obj, count, ROOT_HTTP_ADMIN){
	var countdocuments = parseInt(count.value) + 1;
	addRelacionadoAjax = ajaxRequest();
	if (countdocuments >= 5) {
		alert('S� � permitido no m�ximo 4 itens relacionados!');
	} else {
		ajaxCon(addRelacionadoAjax,addRelacionadoR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/addRelacionado.php','countdocuments='+countdocuments,'get');
	}
}

function addRelacionadoR(){
	var nextIdObject = document.getElementById('place_relacionado');
	var countdocuments = document.getElementById('count_relacionados');
	if(addRelacionadoAjax.readyState==4){
		if(addRelacionadoAjax.status==200){
			var $doctxt = addRelacionadoAjax.responseText;
                        var select = document.createElement('select');
                        var div = document.createElement('div');
                        div.setAttribute('style', 'width:380px;float:left;');
                        div.setAttribute('id', 'divProdutoRel');	
						div.innerHTML = '<label>PRODUTO ' + (parseInt(countdocuments.value) + 1) + ':</label>';
                        select.innerHTML = $doctxt;
                        select.className = 'selectform';
                        select.id = 'idProduto_' + (parseInt(countdocuments.value) + 1);
                        select.setAttribute('style', 'width:840px;margin-right:5px;');
                        select.name = 'idProduto_' + (parseInt(countdocuments.value) + 1);
                        div.innerHTML = '<a href="" onclick="removeElement('+select.id +');">Excluir Produto</a>';
                        nextIdObject.appendChild(div);
                        nextIdObject.appendChild(select);
			//nextIdObject.innerHTML += $doctxt;
			countdocuments.value = parseInt(countdocuments.value) + 1;
		}else{
			nextIdObject.innerHTML += 'Problema ao inserir mais produtos! Por favor, tente novamente.';
		}
	}
}

function addAba(obj, count){
	
	var newinner = "";
        
        for (var i=1; i<= count.value; i++) {
            
            var labelAbaProdutoValue = document.getElementById("labelAbaProduto"+i).value;
            var descricaoAbaProdutoValue = document.getElementById("descricaoAbaProduto"+i).value;
            
            newinner += "<br /><br /><div style=\"width:380px;float:left;\"><label>Nome da Aba "+(i == 1 ? '': i)+":</label></div>";
            newinner += "<input type=\"text\" class=\"text big\" size=\"69\" id=\"labelAbaProduto"+i+"\" name=\"labelAbaProduto"+i+"\" style=\"width:98.5%;\" value=\"" + labelAbaProdutoValue + "\" />";
            newinner += "<div style=\"width:380px;float:left;\"><label>Conte�do da Aba "+(i == 1 ? '': i)+":</label></div>";
            newinner += "<textarea name=\"descricaoAbaProduto"+i+"\" id=\"descricaoAbaProduto"+i+"\" rows=\"10\" style=\"width:840px;-webkit-border-radius: 6px;border-radius: 6px;resize:none;margin-top:5px;\">" + descricaoAbaProdutoValue + "</textarea>";
        }
        
        var countdocuments = parseInt(count.value) + 1;
	var inner = document.getElementById(obj).innerHTML;
	newinner += "<br /><br /><div style=\"width:380px;float:left;\"><label>Nome da Aba "+countdocuments+":</label></div>";
	newinner += "<input type=\"text\" class=\"text big\" size=\"69\" id=\"labelAbaProduto"+countdocuments+"\" name=\"labelAbaProduto"+countdocuments+"\" style=\"width:98.5%;\" />";
	newinner += "<div style=\"width:380px;float:left;\"><label>Conte�do da Aba "+countdocuments+":</label></div>";
	newinner += "<textarea name=\"descricaoAbaProduto"+countdocuments+"\" id=\"descricaoAbaProduto"+countdocuments+"\" rows=\"10\" style=\"width:840px;-webkit-border-radius: 6px;border-radius: 6px;resize:none;margin-top:5px;\"></textarea>";
	document.getElementById(obj).innerHTML = newinner;
	count.value = countdocuments;
}

function getSubcategoria(idCategoria,getSubcategoriaId,getSubcategoria1Id){
	var $categoria = idCategoria;
	if($categoria=='-1' || $categoria==''){
		return null;
	}else{
		subcategoria1Obj = getSubcategoria1Id;
		getSubcategoriaObj = document.getElementById(getSubcategoriaId);
		getSubcategoriaObj.setAttribute('disabled','disabled');
		while(getSubcategoriaObj.hasChildNodes()){
			getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
		}
		var $dom = new Dom();
		var $loading = $dom.option('Carregando...','-1');
		getSubcategoriaObj.appendChild($loading);
		getSubcategoriaAjax = ajaxRequest();
		ajaxCon(getSubcategoriaAjax,getSubcategoriaR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/getSubcategoria.php','idCategoria='+$categoria,'get');
	}
}

function getSubcategoriaR(){
	var $dom = new Dom();
	if(getSubcategoriaAjax.readyState==4){
		if(getSubcategoriaAjax.status==200){
			var $docxml = getSubcategoriaAjax.responseXML;
			if($docxml.hasChildNodes()){
				while(getSubcategoriaObj.hasChildNodes()){
					getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
				}
				var $subcategorias = $docxml.getElementsByTagName('subcategoria');
				for(var $i=0;$i<$subcategorias.length;$i++){
					var $node = $subcategorias[$i];
					$option = $dom.option($node.childNodes[0].nodeValue,$node.getAttribute('value'));
					getSubcategoriaObj.appendChild($option);
				}
				getSubcategoriaObj.removeAttribute('disabled');
				getSubcategoriaObj.setAttribute('onchange','return getSubcategoria1(this.value,\''+subcategoria1Obj+'\')');
				getSubcategoriaObj.focus();
			}else{
				while(getSubcategoriaObj.hasChildNodes()){
					getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
				}
				var $error = $dom.option('Erro ao listar subcategorias.','-1');
				getSubcategoriaObj.appendChild($error);
			}
		}else{
			while(getSubcategoriaObj.hasChildNodes()){
				getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
			}
			var $error = $dom.option('P�gina nao encontrada, contate o adminstrador para mais informa�oes.','-1');
			getSubcategoriaObj.appendChild($error);
		}
	}
}

function getSubcategoria1(idSubcategoria,getSubcategoriaId){
	var $subcategoria = idSubcategoria;
	if($subcategoria=='-1' || $subcategoria==''){
		return null;
	}else{
		getSubcategoriaObj = document.getElementById(getSubcategoriaId);
		getSubcategoriaObj.setAttribute('disabled','disabled');
		while(getSubcategoriaObj.hasChildNodes()){
			getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
		}
		var $dom = new Dom();
		var $loading = $dom.option('Carregando...','-1');
		getSubcategoriaObj.appendChild($loading);
		getSubcategoriaAjax = ajaxRequest();
		ajaxCon(getSubcategoriaAjax,getSubcategoria1R,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/getSubcategoria1.php','idSubcategoria='+$subcategoria,'get');
	}
}

function getSubcategoria1R(){
	var $dom = new Dom();
	if(getSubcategoriaAjax.readyState==4){
		if(getSubcategoriaAjax.status==200){
			var $docxml = getSubcategoriaAjax.responseXML;
			if($docxml.hasChildNodes()){
				while(getSubcategoriaObj.hasChildNodes()){
					getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
				}
				var $subcategorias = $docxml.getElementsByTagName('subcategoria');
				for(var $i=0;$i<$subcategorias.length;$i++){
					var $node = $subcategorias[$i];
					$option = $dom.option($node.childNodes[0].nodeValue,$node.getAttribute('value'));
					getSubcategoriaObj.appendChild($option);
				}
				getSubcategoriaObj.removeAttribute('disabled');
				getSubcategoriaObj.focus();
			}else{
				while(getSubcategoriaObj.hasChildNodes()){
					getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
				}
				var $error = $dom.option('Erro ao listar subcategorias.','-1');
				getSubcategoriaObj.appendChild($error);
			}
		}else{
			while(getSubcategoriaObj.hasChildNodes()){
				getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
			}
			var $error = $dom.option('P�gina nao encontrada, contate o adminstrador para mais informa�oes.','-1');
			getSubcategoriaObj.appendChild($error);
		}
	}
}

function showYoutube(video, altvideo, largvideo, ROOT_HTTP_ADMIN){
	video = document.getElementById(video).value;
	video = video.split('=');
	altvideo = document.getElementById(altvideo).value;
	largvideo = document.getElementById(largvideo).value;
	showYoutubeAjax = ajaxRequest();
	ajaxCon(showYoutubeAjax,showYoutubeR,ROOT_HTTP_ADMIN+'atributos/bibliotecas/ajaxPages/showYoutube.php','v='+video[1]+'&a='+altvideo+'&l='+largvideo,'get');
}

function showYoutubeR(){
	if(showYoutubeAjax.readyState==4){
		if(showYoutubeAjax.status==200){
			var divObject = document.getElementById('video_youtube');
			var $doctxt = showYoutubeAjax.responseText;
			divObject.innerHTML = $doctxt;
			divObject.style.display = "block";
		}else{
			var divObject = document.getElementById('video_youtube');
			divObject.innerHTML = 'Problema ao inserir mais categorias! Por favor, tente novamente.';
			divObject.style.display = "block";
		}
	}
}

function deleteRows(type){
	var q = window.confirm('Aten��o, voc� est� prestes a excluir esta ' + type + '.\nTem certeza que deseja excluir esta ' + type + '?');
	return q;	
}

//###################################################################################
function altLayout(vlrColuna) {
    Form = document.layout;

    if (Form.camposAtivos.value.indexOf(vlrColuna) >= 0) {
        // REMOVE
        if (Form.camposAtivos.value.indexOf("#") >= 0) {
            var array_valores = Form.camposAtivos.value.split("#");
            var part_num=0;
            var vlr_corrigido='';
            while (part_num < array_valores.length) {
                if (array_valores[part_num] != vlrColuna) {
                    if (vlr_corrigido.length > 0 ) {
                        vlr_corrigido = vlr_corrigido + '#' + array_valores[part_num];
                    } else {
                        vlr_corrigido = array_valores[part_num];
                    }
                }
                part_num+=1;
            }
            Form.camposAtivos.value = vlr_corrigido;
        } else {
            Form.camposAtivos.value = '';
        }
    } else {
        // INSERE
        if (Form.camposAtivos.value.length != 0) {
            Form.camposAtivos.value = Form.camposAtivos.value + '#' + vlrColuna
        } else {
            Form.camposAtivos.value = Form.camposAtivos.value + vlrColuna
        }
    }

}

//###################################################################################
function mostraiframe(linha) {
var linha = document.getElementById(linha);
  if (linha.style.display=='none') {
   linha.style.display='';
  } else {
   linha.style.display='none';
  }
}

//###################################################################################
function mostraimg(img,src_img) {
  var img = document.getElementById(img);
  var src_img = document.getElementById(src_img);
  if (src_img.value != '') {
    img.style.display='';
  }else {
    img.style.display='none';
  }
}

//###################################################################################
function alteraiframe_prod(linha) {
    
    var objlinha = document.getElementById(linha);
    objlinha.style.display='';
    var abaON = 'aba_' + linha;
    document.getElementById(abaON).className = 'abasON';

    var tbl = document.getElementById("abasIdioma").cells ; 
    var nCells = tbl.length;
    for(a=0;a<nCells;a++){
        if (tbl[a].id != abaON) {
            var abaOFF = tbl[a].id;
            abaOFF = abaOFF.replace("aba_", "");
            objdlinha = document.getElementById(abaOFF);
            objdlinha.style.display='none';
            document.getElementById(tbl[a].id).className = 'abas';
        }
    }

}

//###################################################################################
function alteraiframe(linha,dlinha) {
  var objlinha = document.getElementById(linha);
  objlinha.style.display='';
  var abaON = 'aba_' + linha;
  document.getElementById(abaON).className = 'abasON';

  var array_dlinha = dlinha.split(",");
  var part_num=0;

  var objdlinha
  while (part_num < array_dlinha.length)
  {
    if (array_dlinha[part_num] != linha) {
      objdlinha = document.getElementById(array_dlinha[part_num]);
      objdlinha.style.display='none';
      var abaOFF = 'aba_' + array_dlinha[part_num];
      document.getElementById(abaOFF).className = 'abas';
    }
    part_num+=1;
  }

}

//###################################################################################
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}

//###################################################################################
function valida_atualizaProd() {
    Form = document.atualizaProd;

    if (Form.txtAtualizacao.value.length == 0) {
        alert("Por favor, selecione um arquivo !");
        Form.txtAtualizacao.focus();
        return false;
    }

    return true;
}

//###################################################################################
function valida_produto(acao,idiomaDefault) {
    Form = document.produto;

    if (document.getElementsByName("nome_produto|"+idiomaDefault)[0].value.length == 0) {
        alert("O nome do produto do idioma principal da loja � um campo obrigat�rio !");
        if (document.getElementById(idiomaDefault).style.display == '') {
            document.getElementsByName("nome_produto|"+idiomaDefault)[0].focus();
        }        
        return false;
    }

    if (Form.preco_unitario.value.length == 0) {
        alert("O pre�o do produto � um campo obrigat�rio !");
        Form.preco_unitario.focus();
        return false;
    } else {
        precoStr = strReplaceAll(Form.preco_unitario.value, '.', '');
        precoStr = strReplaceAll(Form.preco_unitario.value, ',', '');
        if (isNaN(precoStr)) {
            alert("O preco deve ser num�rico !");
            Form.preco_unitario.focus();
            return false;
        }
    }

    if (Form.peso_produto.value.length == 0) {
        alert("O peso do produto � um campo obrigat�rio !");
        Form.peso_produto.focus();
        return false;
    } else {
        pesoStr = strReplaceAll(Form.peso_produto.value, ',', '.');
        if (isNaN(pesoStr)) {
            alert("O peso deve ser num�rico !");
            Form.peso_produto.focus();
            return false;
        }
    }

    if (Form.quantidade_produto.value.length == 0) {
        alert("A quantidade do produto � um campo obrigat�rio !");
        Form.quantidade_produto.focus();
        return false;
    }

    if (Form.img_produto.value.length != 0) {
        if ((Form.img_produto.value.indexOf("http://")>=0) || (Form.img_produto.value.indexOf("https://")>=0)) {
            alert("N�o � poss�vel o cadastro de URLs para imagem do produto !");
            Form.img_produto.focus();
            return false;
        }
    }

    if (Form.img_produto_adic01.value.length != 0) {
        if ((Form.img_produto_adic01.value.indexOf("http://")>=0) || (Form.img_produto_adic01.value.indexOf("https://")>=0)) {
            alert("N�o � poss�vel o cadastro de URLs para imagem do produto !");
            Form.img_produto_adic01.focus();
            return false;
        }
    }

    if (Form.img_produto_adic02.value.length != 0) {
        if ((Form.img_produto_adic02.value.indexOf("http://")>=0) || (Form.img_produto_adic02.value.indexOf("https://")>=0)) {
            alert("N�o � poss�vel o cadastro de URLs para imagem do produto !");
            Form.img_produto_adic02.focus();
            return false;
        }
    }

    if (Form.img_produto_adic03.value.length != 0) {
        if ((Form.img_produto_adic03.value.indexOf("http://")>=0) || (Form.img_produto_adic03.value.indexOf("https://")>=0)) {
            alert("N�o � poss�vel o cadastro de URLs para imagem do produto !");
            Form.img_produto_adic03.focus();
            return false;
        }
    }

    if (Form.promocao.checked == true) {
    
        if (Form.desconto.value.length == 0) {
            alert("O porcentual de desconto � obrigat�rio !");
            Form.desconto.focus();
            return false;
        }

        if (Form.desconto.value >= 101) {
            alert("Informe um porcentual de desconto correto! (at� 100%)");
            Form.desconto.focus();
            return false;
        }

        if (Form.dataInicio.value.length == 0) {
            alert("A data inicial da promo��o � obrigat�ria !");
            Form.dataInicio.focus();
            return false;
        }

        if (Form.dataFim.value.length == 0) {
            alert("A data final da promo��o � obrigat�ria !");
            Form.dataFim.focus();
            return false;
        }

    }  



    return true;
}

//###################################################################################
function valida_categoria(acao,idiomaDefault) {
    Form = document.categoria;

    if (document.getElementsByName("nome_categoria|"+idiomaDefault)[0].value.length == 0) {
        alert("O nome da categoria do idioma principal da loja � um campo obrigat�rio !");
        if (document.getElementById(idiomaDefault).style.display == '') {
            document.getElementsByName("nome_categoria|"+idiomaDefault)[0].focus();
        }        
        return false;
    }

    return true;
}

//###################################################################################
function valida_subcategoria(acao,idiomaDefault) {
    Form = document.subcategoria;

    if (document.getElementsByName("nome_subcategoria|"+idiomaDefault)[0].value.length == 0) {
        alert("O nome da subcategoria do idioma principal da loja � um campo obrigat�rio !");
        if (document.getElementById(idiomaDefault).style.display == '') {
            document.getElementsByName("nome_subcategoria|"+idiomaDefault)[0].focus();
        }        
        return false;
    }

    return true;
}

//###################################################################################
function valida_marca() {
    Form = document.marca;

    if (Form.nome.value.length == 0) {
        alert("O nome da marca � um campo obrigat�rio !");
        Form.nome.focus();
        return false;
    }
    return true;
}

//###################################################################################
function valida_cor() {
    Form = document.cor;

    if (Form.nome.value.length == 0) {
        alert("O nome da cor � um campo obrigat�rio !");
        Form.nome.focus();
        return false;
    }
    return true;
}

//###################################################################################
function valida_IdiomaeCambio() {
    Form = document.IdiomaeCambio;

    if (Form.idioma.value.length == 0) {
        alert("O idioma � um campo obrigat�rio !");
        Form.idioma.focus();
        return false;
    }
    if (Form.nome_moeda.value.length == 0) {
        alert("O nome da moeda � um campo obrigat�rio !");
        Form.nome_moeda.focus();
        return false;
    }
    if (Form.simbolo_moeda.value.length == 0) {
        alert("O simbolo da moeda � um campo obrigat�rio !");
        Form.simbolo_moeda.focus();
        return false;
    }
    if (Form.valor_moeda.value.length == 0) {
        alert("O valor da moeda � um campo obrigat�rio !");
        Form.valor_moeda.focus();
        return false;
    }
    return true;
}

//###################################################################################
function valida_tamanho() {
    Form = document.tamanho;

    if (Form.nome.value.length == 0) {
        alert("O nome da tamanho � um campo obrigat�rio !");
        Form.nome.focus();
        return false;
    }
    return true;
}

//###################################################################################
function valida_servico() {
    Form = document.servico;

    if (Form.nome.value.length == 0) {
        alert("O nome do servi�o � um campo obrigat�rio !");
        Form.nome.focus();
        return false;
    }

    if (Form.desc.value.length == 0) {
        alert("A descri��o do servi�o � um campo obrigat�rio !");
        return false;
    }

    return true;
}

//###################################################################################
function valida_login() {
    Form = document.admin;

    if (Form.usuario.value.length == 0) {
        alert("Por favor, informe o usu�rio !");
        Form.usuario.focus();
        return false;
    }

    if (Form.acao.checked == false) {
        if (Form.senha.value.length == 0) {
            alert("Por favor, informe a senha !");
            Form.senha.focus();
            return false;
        }
    }

    return true;
}

//###################################################################################
function ativa_trocasenha() {

	Form = document.usuario;

    if (Form.ativasenha.checked == true) {
		Form.senha_atual.disabled = false;
        Form.nova_senha.disabled = false;
        Form.confima_nova_senha.disabled = false;
        document.getElementById("linhasenha").disabled = false;
	} else {
        Form.senha_atual.disabled = true;
        Form.nova_senha.disabled = true;
        Form.confima_nova_senha.disabled = true;
        document.getElementById("linhasenha").disabled = true;
    }

}

//###################################################################################
function valida_newsletter() {
    Form = document.cria_newsletter;

    if (Form.de.value.length == 0) {
        alert("O nome do remetente � um campo obrigat�rio !");
        Form.de.focus();
        return false;
    }

    if (Form.emailde.value.length == 0) {
        alert("O e-mail do remetente � um campo obrigat�rio !");
        Form.emailde.focus();
        return false;
    }

    if (Form.assunto.value.length == 0) {
        alert("O assunto � um campo obrigat�rio !");
        Form.assunto.focus();
        return false;
    }

    if ((Form.enviar[0].checked==false) && (Form.enviar[1].checked==false)) {
		alert("Escolha a op��o de destino !");
        return false;
	}

    if (Form.enviar[1].checked==true) {
    
        if (Form.para.value.length == 0) {
            alert("O nome do destinat�rio � um campo obrigat�rio !");
            Form.para.focus();
            return false;
        }

        if (Form.emailpara.value.length == 0) {
            alert("O e-mail do destinat�rio � um campo obrigat�rio !");
            Form.emailpara.focus();
            return false;
        }
    
    }

    return true;
}

//###################################################################################
function valida_usuario() {
    Form = document.usuario;

    if (Form.nome_usuario.value.length == 0) {
        alert("O nome do usu�rio � um campo obrigat�rio !");
        Form.nome_usuario.focus();
        return false;
    }

    if (Form.usuario.value.length == 0) {
        alert("O usu�rio � um campo obrigat�rio !");
        Form.usuario.focus();
        return false;
    }

    padrao = /^[a-zA-Z0-9]+$/;

    campoValue = Form.usuario.value;
    
    var campoVerify = campoValue.indexOf(" ");

    if (campoVerify>=0) {

        var campoArray = campoValue.split(" ");
        
        for(part_num=0;part_num<campoArray.length;part_num++){
        
            OK = padrao.exec(campoArray[part_num]);
            if (!OK){
                window.alert ("Por favor, preencha corretamente o nome do Administrador. N�o s�o aceitos caracteres especiais.");
                return false;
                break;
            }
        
        }
    
    }else{
    
        OK = padrao.exec(campoValue);
        if (!OK){
            window.alert ("Por favor, preencha corretamente o nome do Administrador. N�o s�o aceitos caracteres especiais.");
            return false;
        }

    }

    if (Form.email_usuario.value.length == 0) {
        alert("O e-mail do usu�rio � um campo obrigat�rio !");
        Form.email_usuario.focus();
        return false;
    }

    if (Form.email_usuario.value.indexOf('@', 0) == -1 || Form.email_usuario.value.indexOf('.', 0) == -1) {
        alert("Por favor, preencha corretamente o campo e-mail."); 
        Form.email_usuario.focus();
        return false;
    }


    if (valida_campo("ativasenha",Form)) {
		if (Form.ativasenha.checked == true) {

			var i;
			var num = 0, carac = 0;
			
			if (Form.senha_atual.value.length == 0 || Form.nova_senha.value.length == 0 || Form.confima_nova_senha.value.length == 0) {
				alert("As senhas administrativas s�o obrigat�rias !");
				return false;
			}
			
			for (i = 0; i < Form.nova_senha.value.length; i++) {
				var c = Form.nova_senha.value.charAt(i);
				// ha um numero
				if (((c >= "0") && (c <= "9"))) {
					num++;
				}
				if (((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z"))) {
					carac++;
				}
				if (c == "'" || c == "`" || c == "~" || c == '"' || c == '^') {
					alert("Campo com caracteres inv�lido!!");
					Form.nova_senha.focus();
					return false;
				}
			}
			
			if (num < 2 || carac == 0) {
				alert("Senha deve conter letras e n�meros ( m�nimo 2 n�meros ) !!");
				Form.nova_senha.focus();
				return false;
			}

			if (Form.nova_senha.value.length < 6) {
				alert("A senha administrativa deve ter no m�nimo 6 caracteres !");
				Form.nova_senha.focus();
				return false;
			}

			if (Form.nova_senha.value.length > 14) {
				alert("A senha administrativa deve ter no m�ximo 14 caracteres !");
				Form.nova_senha.focus();
				return false;
			}

			if (Form.nova_senha.value != Form.confima_nova_senha.value) {
				alert("As senhas administrativas n�o s�o iguais !");
				Form.nova_senha.focus();
				return false;
			}
			
			var s;
			s = Form.nova_senha.value
			hoje = new Date()
			ano = hoje.getYear()
			for (f=-2; f<=2; f++){
				n = s.indexOf(ano + f,0)
				if (n > -1){
					alert("N�o � permitido colocar o ano como senha.");
					Form.nova_senha.focus();
					return false;
				}
			}

		}
	}
}

//###################################################################################
// esta funcao repoe caracteres. Usado para repor virgulas por pontos no preco.
function strReplaceAll ( theSource, toFind, replaceWith ) {
    if (null == theSource ) return "";
 
        li_pos = theSource.indexOf( toFind );
 
        while (li_pos != -1)
        {
            if (li_pos < theSource.length -1 )
                theSource = theSource.substring(0, li_pos ) + replaceWith +
                theSource.substring(li_pos+1, theSource.length);
            else
                theSource = theSource.substring(0, li_pos );
 
            li_pos = theSource.indexOf( toFind, li_pos + replaceWith.length ); 
        }
        return theSource;
}

//###################################################################################
function VerImagem(campo,img) { 
    img.src = campo.value;
}

//###################################################################################
function confirma_apagar() {
    var resposta;
    resposta = confirm("Tem certeza que deseja apagar ?");
    if (resposta == true) 
        return true;
    else
        return false;
}

//###################################################################################
function confirma_apagar_prod() {
    var resposta;
    resposta = confirm("Tem certeza que deseja apagar ? OBS: Ao apagar a categoria, todos os produtos relativos a essa categoria ser�o removidos.");
    if (resposta == true) 
        return true;
    else
        return false;
}


//###################################################################################
function valida_dropmenu(campo,valor) {
    if (campo.value == "") {
        alert("Escolha uma "+ valor +" !");
        campo.focus();
        return false;
    }
    return true;
}


//###################################################################################
function perfil_usuarioadm(nome) {
    var fr = document.usuario;
    var ativo = false;
    if (fr.perfil_admin.checked == true) {
        ativo = true;
    }

    for(a=0;a<fr.elements.length;a++){
        if(fr.elements[a].name == nome){
            if(ativo == true){
                fr.elements[a].checked = true;
                fr.elements[a].disabled = true;
            }else{
                fr.elements[a].checked = false;
                fr.elements[a].disabled = false;
            }
        }
    }
}


//###################################################################################
function valida_senha(Form) {

    var i;
    var num = 0, carac = 0;
    
    if (Form.senha.value.length == 0) {
        alert("Por favor, defina a senha administrativa!");
        Form.senha.focus();
        return false;
    }
    
    for (i = 0; i < Form.senha.value.length; i++) {
        var c = Form.senha.value.charAt(i);
        // ha um numero
        if (((c >= "0") && (c <= "9"))) {
            num++;
        }
        if (((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z"))) {
            carac++;
        }
        if (c == "'" || c == "`" || c == "~" || c == '"' || c == '^') {
            alert("Campo com caracteres inv�lido!!");
            Form.senha.focus();
            return false;
        }
    }
    
    if (num < 2 || carac == 0) {
        alert("Senha deve conter letras e n�meros ( m�nimo 2 n�meros ) !!");
        Form.senha.focus();
        return false;
    }

    if (Form.senha.value.length == 0 || Form.senha2.value.length == 0) {
        alert("As senhas administrativas s�o obrigat�rias !");
        Form.senha.focus();
        return false;
    }

    if (Form.senha.value.length < 6) {
        alert("A senha administrativa deve ter no m�nimo 6 caracteres !");
        Form.senha.focus();
        return false;
    }

    if (Form.senha.value.length > 14) {
        alert("A senha administrativa deve ter no m�ximo 14 caracteres !");
        Form.senha.focus();
        return false;
    }

    if (Form.senha.value != Form.senha2.value) {
        alert("As senhas administrativas n�o s�o iguais !");
        Form.senha.focus();
        return false;
    }
    
    var s;
    s = Form.senha.value
    hoje = new Date()
    ano = hoje.getYear()
    for (f=-2; f<=2; f++){
        n = s.indexOf(ano + f,0)
        if (n > -1){
            alert("N�o � permitido colocar o ano como senha.");
            Form.senha.focus();
            return false;
        }
    }

    return true;

}

//###################################################################################
function valida_campo(campo,fr) {

    for(a=0;a<fr.elements.length;a++){
        if(fr.elements[a].name == campo){
            return true;
            break;
        }
    }

	return false;
}

//###################################################################################
function valida_relatorio() {

     var Form , precoStr;
     Form = document.relatorio;
     checado = 0 ;
     

     if ((Form.cbNrPedido.checked == false)&&(Form.cbData.checked == false)&&(Form.cbNome.checked == false)&&(Form.cbEstado.checked == false)&&(Form.cbCidade.checked == false) && (Form.cbTotal.checked == false) && (Form.cbPago.checked == false)&&(Form.cbAtendido.checked == false)) {
	alert("Pesquisa inv�lida !");
	return false;
     }

      if ((!isDate(Form.edtIni.value))&&(Form.cbData.checked == true)) {
 	alert("Data inv�lida");
 	Form.edtIni.focus();
	return false;     
     }
      
      if ((!isDate(Form.edtFim.value))&&(Form.cbData.checked == true)) {
 	alert("Data inv�lida");
 	Form.edtFim.focus();
 	return false;    
     }

     if ((Form.cbNrPedido.checked == true)&&(Form.edtNrPedido.value.length == 0)) {
	alert("N�mero do pedido inv�lido !");
        Form.edtNrPedido.focus();
        return false;
     }

	 if ((Form.cbNome.checked == true)&&(Form.edtNome.value.length == 0)) {
	alert("Nome inv�lido !");
        Form.edtNome.focus();
        return false;
     }
     
     if ((Form.cbTotal.checked == true)&&(Form.edtTotal.value.length == 0)) {
        alert("Total Inv�lido !");
        Form.edtTotal.focus();
        return false;
     } else if(Form.cbTotal.checked == true) {
	precoStr = strReplaceAll(Form.edtTotal.value, ',', '.');
	Form.edtTotal.value = precoStr;
	if (isNaN(precoStr)) {
		alert("O preco deve ser num�rico !");
	        Form.edtTotal.focus();
	        return false;
	      }
     }	

     return true;
}

//###################################################################################
function isDate(theString){
    if ((theString=="")||(!theString)) return false;
    return !isNaN(new Date(theString));
}
 
//###################################################################################
function imprimir(text){
    text=document
    print(text)
}

//###################################################################################
function imprimirFedex(text){
    var objlinha = document.getElementById('FedexInfo');
    objlinha.style.display='none';
    text=document;
    print(text);
    objlinha.style.display='';
}

//###################################################################################
var txt_focus = document.layout;
var txt_preview
function get_focus(obj){
    txt_focus = obj;
    txt_preview = txt_focus.name + '_preview';
}

//###################################################################################
function SendColor(color){
    if (txt_focus == undefined) {
        alert('Por favor escolha um campo.');
    } else {
        txt_focus.value = color;
        SetColor(color);
    }
}

//###################################################################################
function SetColor(color){
    document.getElementById(txt_preview).bgColor = color;
}

//###################################################################################
function JanelaNova(URLBoleto) {
	window.open(URLBoleto,'NOME','width=680,height=400,menubar,scrollbars,resizable','NOME','width=600,height=400,menubar,scrollbars,resizable');
}

//###################################################################################
function valida_atualizacao() { 
    
     Form = document.atualizacao;
     if (Form.txtDado.value.length == 0) {
	alert("O arquivo texto � obrigat�rio !");
        Form.txtDado.focus();
        return false;
     }
   return true;
}

//###################################################################################
function habilita_newsletter(obj) { 
  //Habilita op��es de pagamento VisaNet (novo sistema)
	if (obj == '1'){
    document.cria_newsletter.para.disabled = false ;
	document.cria_newsletter.emailpara.disabled = false ;
	}else if (obj == '0'){
    document.cria_newsletter.para.disabled = true ;
    document.cria_newsletter.para.value = '' ;
	document.cria_newsletter.emailpara.disabled = true ;
    document.cria_newsletter.emailpara.value = '' ;
	}
}

//###################################################################################
function valida_dadosGerais(Form,endLoja,tipoConfig) { 
    
    if (Form.NomeLoja.value.length == 0) {
		alert("O nome da loja � um campo obrigat�rio !");
        Form.NomeLoja.focus();
        return false;
	}

    if (Form.MailLoja.value.indexOf('@', 0) == -1 || Form.MailLoja.value.indexOf('.', 0) == -1) {
        alert("Por favor, preencha corretamente o campo e-mail."); 
        Form.MailLoja.focus();
        return false;
    }

    if (Form.ProdutosPorPagina.value.length == 0) {
		alert("A quantidade de produtos por p�gina � um campo obrigat�rio !");
        Form.ProdutosPorPagina.focus();
        return false;
	}

    if (Form.NumPedidoInicial.value.length == 0) {
		alert("O n�mero do pedido inicial � um campo obrigat�rio !");
        Form.NumPedidoInicial.focus();
        return false;
	}

    var endSSL = Form.SSLloja;

    if (endLoja != endSSL.value) {
        if (endSSL.value.indexOf("https://") < 0) {
            alert("Por favor informe um endere�o SSL v�lido.");
            Form.SSLloja.focus();
            return false;
        }
        
        if (tipoConfig == "LWConvencional") {

			var endSSLfrmt = endSSL.value.replace("https://", "");

			if ((endSSLfrmt.indexOf("/") >= 0) || (endSSLfrmt.length == 0)) {
				alert("Por favor informe um endere�o SSL v�lido.");
				Form.SSLloja.focus();
				return false;
			}

		}

    }

    var bancoLoja = Form.TipoBanco.value;

    if (bancoLoja == "mssql") {
        if (Form.EnderecoMssql.value.length == 0) {
            alert("O endere�o do servidor do banco � um campo obrigat�rio !");
            Form.EnderecoMssql.focus();
            return false;
        }

        if (Form.BaseMssql.value.length == 0) {
            alert("O nome da base do banco � um campo obrigat�rio !");
            Form.BaseMssql.focus();
            return false;
        }
        
        if (Form.UsuarioMssql.value.length == 0) {
            alert("O usu�rio do banco � um campo obrigat�rio !");
            Form.UsuarioMssql.focus();
            return false;
        }
        
        if (Form.SenhaMssql.value.length == 0) {
            alert("A senha do banco � um campo obrigat�rio !");
            Form.SenhaMssql.focus();
            return false;
        }
    }

    var CNPJ = Form.CNPJ_b1.value + Form.CNPJ_b2.value + Form.CNPJ_b3.value + Form.CNPJ_b4.value + Form.CNPJ_b5.value;
    Form.CNPJ.value = CNPJ;

    return true;

}

//###################################################################################
var isNN = (navigator.appName.indexOf("Netscape")!=-1);

function autoTab(input,len, e) {
    var keyCode = (isNN) ? e.which : e.keyCode; 
    var filter = (isNN) ? [0,8,9] : [0,8,9,16,17,18,37,38,39,40,46];
    if(input.value.length >= len && !containsElement(filter,keyCode)) {
        input.value = input.value.slice(0, len);
        input.form[(getIndex(input)+1) % input.form.length].focus();
}

function containsElement(arr, ele) {
    var found = false, index = 0;
    while(!found && index < arr.length)
        if(arr[index] == ele)
            found = true;
        else
            index++;
        return found;
    }

function getIndex(input) {
    var index = -1, i = 0, found = false;
    while (i < input.form.length && index == -1)
        if (input.form[i] == input)index = i;
        else i++;
        return index;
    }
return true;
}

//###################################################################################
function fncLimpaValue(objTexto, sString) {

	if (sString == objTexto.value) {

		objTexto.value = '';
	}

}

//###################################################################################
function fncPreencheValue(objTexto, sString) {

	if (objTexto.value == '') {

		objTexto.value = sString;

	}

}

//###################################################################################
function define_parcelamento(selParc,tipoParc,tipoChec) {

    if (tipoChec == 'parcelamento') {
        if (selParc == 'sim') {
            exibeiframe('tblTipoParc');
            exibeiframe('tblNumParc');
            exibeiframe('tblValorMinParc');
            define_parcelamento(selParc,tipoParc,'tipoParcelamento')
        } else {
            ocultaiframe('tblTipoParc');
            ocultaiframe('tblTaxaDesc');
            ocultaiframe('tblTaxaAcresc');
            ocultaiframe('tblNumParc');
            ocultaiframe('tblValorMinParc');
            ocultaiframe('tblCondParc');
        }
    } else {
        if (tipoParc == 'Juros do lojista') {
            exibeiframe('tblTaxaDesc');
            exibeiframe('tblTaxaAcresc');
            exibeiframe('divCondParc');
        } else {
            ocultaiframe('tblTaxaDesc');
            ocultaiframe('tblTaxaAcresc');
            ocultaiframe('divCondParc');
            ocultaiframe('tblCondParc');
        }

    }

}

//###################################################################################
function ajusta_exibeiframe(maxOpcao,selOpcao,prefixOpcao) {

    for (i=1;i<=maxOpcao;i++) {
        if (i<=selOpcao) {
            exibeiframe(prefixOpcao+i);
        } else {
            ocultaiframe(prefixOpcao+i);
        }
    }

}

//###################################################################################
function exibeiframe(linha) {
    var linha = document.getElementById(linha);
    linha.style.display='';

}

//###################################################################################
function ocultaiframe(linha) {
    var linha = document.getElementById(linha);
    linha.style.display='none';
}

//###################################################################################
function verificaTipoVisa(opcao) {
    if (opcao == 'VISAMOSET') {
		ocultaiframe('tblVisanetAuthentType');
		ocultaiframe('tblVisaNetAntiPopup');
	} else {
		exibeiframe('tblVisanetAuthentType');
		exibeiframe('tblVisaNetAntiPopup');
	}
}

