//	*****	BONO - CLIENTE
/*
> goToStage - avan�a ou retorna para um passo [1. show , 2. hide]
> returnTipoCliente - retorna para um passo de dados de um cliente, verificando o tipo selecionado [1. input de tipo , 2. id da pessoa fisica , 3. id da pessoa juridica , 4. id do objeto a ser hide ]
> checkEtapa1 - valida primeira etapa do cadastro de cliente, verificando pelo tipo selecionado [1. id do formul�rio , 2. show , 3. hide]
> existsCPF - verifica se CPF ja foi cadastrado[1. string , 2. objeto para resposta]
> existsCPFR - fun��o de retorno a fun��o existsCPF, chamada por ajax
> existsCNPJ - verifica se CNPJ ja foi cadastrado[1. string , 2. objeto para resposta]
> existsCNPJR - fun��o de retorno a fun��o existsCNPJ, chamada por ajax
> existsEmail - verifica se email ja foi cadastrado[1. string , 2. objeto para resposta]
> existsEmailR - fun��o de retorno a fun��o existsEmail, chamada por ajax
> cadastrarCliente - valida um formul�rio de cadastro de um cliente [1. objeto formul�rio]
> checkLogin - valida formulario de login de um cliente [1. objeto formul�rio]
> esqueciMinhaSenha - solicita um envio de senha para cliente atrav�s de um e-mail [1. objeto formulario, 2. objeto resposta]
*/

//	VERIFICA O TIPO DE CLIENTE 1 = F�SICA | 2 = JUR�DICA
function goToStage(goToStageShow,goToStageHide,recebe1,recebe2){
	var $show = document.getElementById(goToStageShow);
	var $hide = document.getElementById(goToStageHide);
	var valor1 = document.getElementById('valor1');
	var valor2 = document.getElementById('valor2');
	
	valor1.value = recebe1;
	valor2.value = recebe2;
	$show.style.display = 'block';
	$hide.style.display = 'none';
}

function returnTipoCliente(returnTipoClienteInput,returnTipoClienteFisica, returnTipoClienteJuridica,returnTipoClienteHide){
	var $input = returnTipoClienteInput;
	var $fisica = document.getElementById(returnTipoClienteFisica);
	var $juridica = document.getElementById(returnTipoClienteJuridica);
	var $hide = document.getElementById(returnTipoClienteHide);
	var $checkFisica = $input[0].checked;
	var $checkJuridica= $input[1].checked;
	if($checkFisica==true){
		$fisica.style.display = 'block';
	}else{
		$juridica.style.display = 'block';
	}
	$hide.style.display = 'none';
}

function checkEtapa1(checkEtapa1Form, checkEtapa1Show, checkEtapa1Hide,valorDocumento){
/*
	if(checkEtapa1Hide == 'fisica'){		
		existsCPF(valorDocumento.value,'informationCPF')	
	}else{
		existsCNPJ(valorDocumento,'informationCNPJ');
	}
*/

	var $form = document.getElementById(checkEtapa1Form);
	var $show = document.getElementById(checkEtapa1Show);
	var $hide = document.getElementById(checkEtapa1Hide);
	var $tipoFisica = $form.tipoCliente[0].checked;
	var $tipoJuridica = $form.tipoCliente[1].checked;
//	var $tipoFisica = true;
//	var $tipoJuridica = false;
	var $validation = new Validation();
	
	//	VERIFICANDO O TIPO DE PESSOA SELECIONADA
	if($tipoFisica==false && $tipoJuridica == false){
		alert('N�o foi selecionado nenhum tipo de cliente, o cadastro n�o pode continuar.');
		return false;
	}else if($tipoFisica==true){
		var $cpfCliente = $form.cpfCliente;
		//	TIPO DE PESSOA = F�SICA
		if($validation.checkCPF($cpfCliente.value)===false){
			$cpfCliente.focus();
			alert('CPF inv�lido.');
			return false;
		}
		//	VERIFICANDO SE CPF JA EXISTE
		var $exists = document.getElementById('informationCPF').style.display;
		if($exists=='inline'){
			$cpfCliente.focus();
			alert('Este CPF j� existe, insira um CPF v�lido.');
			return false;
		}
	}else{
		var $cnpjCliente = $form.cnpjCliente;
		var $razaoSocialCliente = $form.razaoSocialCliente;
		//	TIPO DE PESSOA = JUR�DICA
		if($validation.checkCNPJ($cnpjCliente.value)==false){
			$cnpjCliente.focus();
			alert('CNPJ inv�lido.');
			return false;
		}
		if($razaoSocialCliente.value==''){
			$razaoSocialCliente.focus();
			alert('Preencha corretamente o campo razao social.');
			return false;
		}
		//	VERIFICANDO SE CNPJ JA EXISTE
		var $exists = document.getElementById('informationCNPJ').style.display;
		if($exists=='inline'){
			$cnpjCliente.focus();
			alert('Este CNPJ j� existe, insira um CNPJ v�lido.');
			return false;
		}
	}
	$show.style.display = 'block';
	$hide.style.display = 'none';
}

function checkEtapa2(checkEtapa2Form, checkEtapa2Show, checkEtapa2Hide){
	var $form = document.getElementById(checkEtapa2Form);
	var $show = document.getElementById(checkEtapa2Show);
	var $hide = document.getElementById(checkEtapa2Hide);
	var $nomeCliente = $form.nomeCliente;
	var $validation = new Validation();
	
	//	VERIFICANDO O TIPO DE PESSOA SELECIONADA
	if($nomeCliente.value==''){
		$nomeCliente.focus();
		alert('Preencha corretamente o campo nome.');
		return false;
	}
	$show.style.display = 'block';
	$hide.style.display = 'none';
}

function existsCPF(existsCPFStr, existsCPFTo){
	var $str = existsCPFStr;
	existsCPFObj = document.getElementById(existsCPFTo);
	var $validation = new Validation();
	
	if($validation.checkSizeStr($str,14,14)===true){
		if($validation.checkCPF($str)!==false){
			//	CPF FOI DIGITADO CORRETAMENTE, FAZENDO VERIFICA��O SE JA EXISTE
			existsCPFAjax = ajaxRequest();
			ajaxCon(existsCPFAjax,existsCPFR,ROOT_HTTP+'atributos/bibliotecas/ajaxPages/existsCPF.php','cpf='+$str,'get');
		}else{
			existsCPFObj.innerHTML = 'CPF incorreto.';
			existsCPFObj.style.display = 'inline';
		}
	}else{
		existsCPFObj.style.display = 'none';
	}
}

function existsCPFR(){
	existsCPFObj.style.display = 'inline';
	existsCPFObj.innerHTML = 'Verificando CPF...';
	if(existsCPFAjax.readyState==4){
		if(existsCPFAjax.status==200){
			var $docxml = existsCPFAjax.responseText;
			if($docxml!='true'){
				existsCPFObj.style.display = 'inline';
				existsCPFObj.innerHTML = $docxml;
			}else{
				existsCPFObj.style.display = 'none';
			}
		}else{
			existsCPFObj.style.display = 'inline';
			existsCPFObj.innerHTML = 'Erro 404 - Tente novamente mais tarde.';
		}
	}
}

function existsCNPJ(existsCNPJStr, existsCNPJTo){
	var $str = existsCNPJStr;
	existsCNPJObj = document.getElementById(existsCNPJTo);
	var $validation = new Validation();
	
	if($validation.checkSizeStr($str,19,18)===true){
		if($validation.checkCNPJ($str)!==false){
			//	CNPJ FOI DIGITADO CORRETAMENTE, FAZENDO VERIFICA��O SE JA EXISTE
			existsCNPJAjax = ajaxRequest();
			ajaxCon(existsCNPJAjax,existsCNPJR,ROOT_HTTP+'atributos/bibliotecas/ajaxPages/existsCNPJ.php','cnpj='+$str,'get');
		}else{
			existsCNPJObj.style.display = 'none';
		}
	}else{
		existsCNPJObj.style.display = 'none';
	}
}

function existsCNPJR(){
	existsCNPJObj.style.display = 'inline';
	existsCNPJObj.innerHTML = 'Verificando CNPJ...';
	if(existsCNPJAjax.readyState==4){
		if(existsCNPJAjax.status==200){
			var $docxml = existsCNPJAjax.responseText;
			if($docxml!='true'){
				existsCNPJObj.style.display = 'inline';
				existsCNPJObj.innerHTML = $docxml;
			}else{
				existsCNPJObj.style.display = 'none';
			}
		}else{
			existsCNPJObj.style.display = 'inline';
			existsCNPJObj.innerHTML = 'Erro 404 - Tente novamente mais tarde.';
		}
	}
}

function existsEmail(existsEmailStr, existsEmailTo){
	var $str = existsEmailStr;
	existsEmailObj = document.getElementById(existsEmailTo);
	var $validation = new Validation();
	
	if($validation.checkEmail($str)===true){
		//	Email FOI DIGITADO CORRETAMENTE, FAZENDO VERIFICA��O SE JA EXISTE
		existsEmailAjax = ajaxRequest();
		ajaxCon(existsEmailAjax,existsEmailR,ROOT_HTTP+'atributos/bibliotecas/ajaxPages/existsEmail.php','email='+$str,'get');
	}else{
		existsEmailObj.style.display = 'none';
	}
}

function existsEmailR(){
	existsEmailObj.style.display = 'inline';
	existsEmailObj.innerHTML = 'Verificando E-mail...';
	if(existsEmailAjax.readyState==4){
		if(existsEmailAjax.status==200){
			var $docxml = existsEmailAjax.responseText;
			if($docxml!='true'){
				existsEmailObj.style.display = 'inline';
				existsEmailObj.innerHTML = $docxml;
			}else{
				existsEmailObj.style.display = 'none';
			}
		}else{
			existsEmailObj.style.display = 'inline';
			existsEmailObj.innerHTML = 'Erro 404 - Tente novamente mais tarde.';
		}
	}
}

function existsLogin(existsLoginStr, existsLoginTo){
	var $str = existsLoginStr;
	existsLoginObj = document.getElementById(existsLoginTo);
	var $validation = new Validation();
	if($validation.checkLogin($str)===true){
		//	Login FOI DIGITADO CORRETAMENTE, FAZENDO VERIFICA��O SE JA EXISTE
		existsLoginAjax = ajaxRequest();
		ajaxCon(existsLoginAjax,existsLoginR,ROOT_HTTP+'atributos/bibliotecas/ajaxPages/existsLogin.php','login='+$str,'get');
	}else{
		existsLoginObj.style.display = 'none';
	}
}

function existsLoginR(){
	existsLoginObj.style.display = 'inline';
	existsLoginObj.innerHTML = 'Verificando Login...';
	if(existsLoginAjax.readyState==4){
		if(existsLoginAjax.status==200){
			var $docxml = existsLoginAjax.responseText;
			if($docxml!='true'){
				existsLoginObj.style.display = 'inline';
				existsLoginObj.innerHTML = $docxml;
			}else{
				existsLoginObj.style.display = 'none';
			}
		}else{
			existsLoginObj.style.display = 'inline';
			existsLoginObj.innerHTML = 'Erro 404 - Tente novamente mais tarde.';
		}
	}
}

//	VERIFICA�AO AO CADASTRAR
function cadastrarCliente(cadastrarClienteForm){	



	var $form = cadastrarClienteForm;	
	/*	PRIMEIRO CHECA A ETAPA CORRENTE	
	var $etapa04 = document.getElementById('etapa02');
	if($etapa04.style.display=='' || $etapa04.style.display == 'none'){
		return false;
	}
	*/
	var $cnpjCliente = $form.cnpjCliente;
	var $cpfCliente = $form.cpfCliente;
	var $ieCliente = $form.ieCliente;
	var $tipoCliente = $form.tipoCliente;
	var $nomeCliente = $form.nomeCliente;
	var $razaoSocialCliente = $form.razaoSocialCliente;
	var $nomeFantasiaCliente = $form.nomeFantasiaCliente;
	var $enderecoRuaCliente = $form.enderecoRuaCliente;
	var $enderecoNumeroCliente = $form.enderecoNumeroCliente;
	var $enderecoComplementoCliente = $form.enderecoComplementoCliente;
	var $cepCliente = $form.cepCliente;
	var $cidadeCliente = $form.cidadeCliente;
	var $estadoCliente = $form.estadoCliente;
	var $contatoCliente = $form.contatoCliente;
	var $emailContatoCliente = $form.emailContatoCliente;
	var $confEmailContatoCliente = $form.confEmailContatoCliente;
	var $msnCliente = $form.msnCliente;
	var $skypeCliente = $form.skypeCliente;
	var $dddTelefoneComercialCliente = $form.dddTelefoneComercialCliente;
	var $telefoneComercialCliente = $form.telefoneComercialCliente;
	var $ramalTelefoneComercialCliente = $form.ramalTelefoneComercialCliente;
	var $dddCelularCliente = $form.dddCelularCliente;
	var $dddNextelCliente = $form.dddNextelCliente;
	var $celularCliente = $form.celularCliente;
	var $nextelCliente = $form.nextelCliente;
	var $radioCliente = $form.radioCliente;
	var $dddTelefoneResidencialCliente = $form.dddTelefoneResidencialCliente;
	var $telefoneResidencialCliente = $form.telefoneResidencialCliente;
	var $dddFaxCliente = $form.dddFaxCliente;
	var $faxCliente = $form.faxCliente;
	var $ramalFaxCliente = $form.ramalFaxCliente;
	var $senhaCliente = $form.senhaCliente;
	var $confSenhaCliente = $form.confSenhaCliente;
	var $validation = new Validation();	//	OBJETO PARA VALIDA�AO
	//	CHECK ACTION
	

	if($form.getAttribute('action') !='atributos/bibliotecas/action/cadastrar.php'){
		alert('Erro inesperado. Esta p�gina nao pode continuar.');
		self.location = '/';
		return false;
	}

	
	if($tipoCliente.value == '1'){
		var $tipoFisica = true;
		var $tipoJuridica = false;		
	}else{
		var $tipoFisica = false;
		var $tipoJuridica = true;				
	}



	//	VERIFICANDO TIPO DE PESSOA

//	var $tipoFisica = $tipoCliente[0].checked;
//	var $tipoJuridica = $tipoCliente[1].checked;
	
	//	VALIDANDO CAMPOS OBRIGAT�RIOS PARA O TIPO DE PESSOA
	if($tipoFisica==false&&$tipoJuridica==false){
		alert('Selecione um tipo de pessoa para continuar o cadastro.');
		return false;
	}else if($tipoFisica==true){
		//	TIPO DE PESSOA = F�SICA
		if($validation.checkCPF($cpfCliente.value)===false){
			$cpfCliente.focus();
			alert('CPF inv�lido.');
			return false;
		}
	}else{
		//	TIPO DE PESSOA = JUR�DICA
		if($validation.checkCNPJ($cnpjCliente.value)===false){
			$cnpjCliente.focus();
			alert('CNPJ inv�lido.');
			return false;
		}
		if($razaoSocialCliente.value==''){
			$razaoSocialCliente.focus();
			alert('Preencha corretamente o campo razao social.');
			return false;
		}
	}
	
	
	if($nomeCliente.value.replace(/^\s+/,"")==''){
		$nomeCliente.focus();
		$nomeCliente.select();
		alert('Preencha corretamente o campo nome.');
		return false;
	}
	if($enderecoRuaCliente.value.replace(/^\s+/,"")==''){
		$enderecoRuaCliente.focus();
		$enderecoRuaCliente.select();
		alert('Preencha corretamente o campo endere�o.');
		return false;
	}
	if($enderecoNumeroCliente.value==''){
		$enderecoNumeroCliente.focus();
		alert('Preencha corretamente o campo n�mero.');
		return false;
	}
	//	FAZENDO VALIDA�AO DE CAMPOS NAO OBRIGAT�RIOS
	if($enderecoNumeroCliente.value!=''){
		if($validation.checkInt($enderecoNumeroCliente.value)===false){
			$enderecoNumeroCliente.focus();
			alert('Preencha um n�mero de endere�o v�lido, apenas n�meros.');
			return false;
		}
	}
	if($cepCliente.value.replace(/^\s+/,"")==''){
		$cepCliente.focus();
		$cepCliente.select();
		alert('Preencha corretamente o campo CEP.');
		return false;
	}

	if($cepCliente.value!=''){
		if($validation.checkCEP($cepCliente.value)===false){
			$cepCliente.focus();
			alert('Preencha um cep v�lido.');
			return false;
		}
	}

	if($estadoCliente.value == '-1'){
		$estadoCliente.focus();
		alert('Selecione o estado corretamente.');
		return false;
	}
	
	if($tipoFisica==true){
		if(($telefoneResidencialCliente.value.replace(/^\s+/,"")=='')||($dddTelefoneResidencialCliente.value.replace(/^\s+/,"")=='')){
			$telefoneResidencialCliente.focus();
			alert('Preencha corretamente o campo de telefone residencial.');
			return false;
		}			
	}else{
		if(($telefoneComercialCliente.value.replace(/^\s+/,"")=='')||($dddTelefoneComercialCliente.value.replace(/^\s+/,"")=='')){
			$telefoneComercialCliente.focus();
			alert('Preencha corretamente o campo de telefone comercial.');
			return false;
		}					
	}
	

	if($msnCliente.value!=''){
		if($validation.checkEmail($msnCliente.value)===false){
			$msnCliente.focus();
			alert('Preencha um endere�o de MSN v�lido.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE TELEFONE COMERCIAL	*/
	if($dddTelefoneComercialCliente.value!='' || $telefoneComercialCliente.value!='' || $ramalTelefoneComercialCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddTelefoneComercialCliente.value)===false){
			$dddTelefoneComercialCliente.focus();
			alert('Preencha um DDD v�lido para o telefone comercial, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($telefoneComercialCliente.value)===false){
			$telefoneComercialCliente.focus();
			alert('Preencha um telefone comercial v�lido, apenas n�meros.');
			return false;
		}
		if($ramalTelefoneComercialCliente.value!=''){
			//	POSSUI UM RAMAL, VERIFICANDO VALOR
			if($validation.checkInt($ramalTelefoneComercialCliente.value)===false){
				$ramalTelefoneComercialCliente.focus();
				alert('Preencha um ramal v�lido para o telefone comercial, apenas n�meros.');
				return false;
			}
		}
	}
	
	/*	VALIDA�AO DE TELEFONE CELULAR	*/
	if($dddCelularCliente.value!='' || $celularCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddCelularCliente.value)===false){
			$dddCelularCliente.focus();
			alert('Preencha um DDD v�lido para o celular, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($celularCliente.value)===false){
			$celularCliente.focus();
			alert('Preencha um celular v�lido, apenas n�meros.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE NEXTEL	*/
	if($dddNextelCliente.value!='' || $nextelCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddNextelCliente.value)===false){
			$dddNextelCliente.focus();
			alert('Preencha um DDD v�lido para o nextel, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($nextelCliente.value)===false){
			$nextelCliente.focus();
			alert('Preencha um nextel v�lido, apenas n�meros.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE TELEFONE RESIDENCIAL	*/
	if($dddTelefoneResidencialCliente.value!='' || $telefoneResidencialCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddTelefoneResidencialCliente.value)===false){
			$dddTelefoneResidencialCliente.focus();
			alert('Preencha um DDD v�lido para o telefone residencial, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($telefoneResidencialCliente.value)===false){
			$telefoneResidencialCliente.focus();
			alert('Preencha um telefone residencial v�lido, apenas n�meros.');
			return false;
		}
	}
	
	/*	VALIDA�AO DE FAX	*/
	if($dddFaxCliente.value!='' || $faxCliente.value!='' || $ramalFaxCliente.value!=''){
		//	POSSUI UM TELEFONE, VERIFICANDO DADOS DE DDD E N�MERO
		if($validation.checkDDD($dddFaxCliente.value)===false){
			$dddFaxCliente.focus();
			alert('Preencha um DDD v�lido para o fax, apenas n�meros.');
			return false;
		}
		if($validation.checkPhoneNumber($faxCliente.value)===false){
			$faxCliente.focus();
			alert('Preencha um fax v�lido, apenas n�meros.');
			return false;
		}
		if($ramalFaxCliente.value!=''){
			//	POSSUI UM RAMAL, VERIFICANDO VALOR
			if($validation.checkInt($ramalFaxCliente.value)===false){
				$ramalFaxCliente.focus();
				alert('Preencha um ramal v�lido para o fax, apenas n�meros.');
				return false;
			}
		}
	}
	
	/*	VALIDA��O DO EMAIL	*/
	if($validation.checkEmail($emailContatoCliente.value)===false){
		$emailContatoCliente.focus();
		alert('Preencha um endere�o de email v�lido.');
		return false;
	}
	if($validation.checkEmail($confEmailContatoCliente.value)===false){
		$confEmailContatoCliente.focus();
		alert('Preencha um endere�o de email v�lido para confirma��o.');
		return false;
	}
	if($emailContatoCliente.value!=$confEmailContatoCliente.value){
		$emailContatoCliente.focus();
		$emailContatoCliente.select();
		alert('Os campos de email e confirma��o de email n�o est�o iguais.');
		return false;
	}

	/*	VALIDA��O DO LOGIN	*/
	if($senhaCliente.value.length<=5){
		$senhaCliente.focus();
		$senhaCliente.select();
		alert('O campo senha deve conter no m�nimo 6 posi��es.');
		return false;
	}
	if($senhaCliente.value!=$confSenhaCliente.value){
		$senhaCliente.focus();
		$senhaCliente.select();
		alert('Os campos de senha e confirma��o de senha n�o est�o iguais.');
		return false;
	}
	
	//	VERIFICANDO SE EMAIL JA EXISTE
	var $exists = document.getElementById('informationEmail').style.display;
	if($exists=='inline'){
		$emailContatoCliente.focus();
		alert('Este e-mail j� existe, insira um e-mail v�lido.');
		return false;
	}
	//	VERIFICANDO SE LOGIN JA EXISTE
/*
	var $exists = document.getElementById('informationSenha').style.display;
	if($exists=='inline'){
		$loginCliente.focus();
		alert('Este login j� existe, insira um login v�lido.');
		return false;
	}
*/	
	var $q = window.confirm('Deseja realmente efetuar o cadastro?');
	return $q;
}

function checkLogin(checkLoginForm){
	var $form = checkLoginForm;
	var $loginCliente = $form.loginCliente;
	var $senhaCliente = $form.senhaCliente;
	var $validation = new Validation();
	
	if($loginCliente.value.replace(/^\s+/,"")==''){
		$loginCliente.focus();
		alert('Preencha o campo login para acesso a loja.');
		return false;
	}
	if($validation.checkLogin($senhaCliente.value)===false){
		$senhaCliente.focus();
		alert('Preencha uma senha v�lida.');
		return false;
	}
	
	return true;
}

function esqueciMinhaSenha(esqueciMinhaSenhaForm, esqueciMinhaSenhaTo){
	var $form = esqueciMinhaSenhaForm;
	esqueciMinhaSenhaObj = document.getElementById(esqueciMinhaSenhaTo);
	var $emailCliente = $form.emailCliente;
	var $validation = new Validation();
	if($validation.checkEmail($emailCliente.value)===false){
		$emailCliente.focus();
		alert('Preencha seu e-mail corretamente.');
		return false;
	}else{
		esqueciMinhaSenhaAjax = ajaxRequest();
		ajaxCon(esqueciMinhaSenhaAjax,esqueciMinhaSenhaR,ROOT_HTTP+'atributos/bibliotecas/ajaxPages/sendPassword.php','email='+$emailCliente.value,'post');
	}
	return false;
}

function esqueciMinhaSenhaR(){
	esqueciMinhaSenhaObj.innerHTML = 'Processando... Aguarde...';
	if(esqueciMinhaSenhaAjax.readyState==4){
		if(esqueciMinhaSenhaAjax.status==200){
			var $docxml = esqueciMinhaSenhaAjax.responseText;
			if($docxml=='1'){
				esqueciMinhaSenhaObj.innerHTML = '<p>Seus dados de acesso foram enviados com sucesso.</p><p><em><a href="javascript:;"  onclick="clearEsqueciMinhaSenha();">Fechar</a></em></p>';
			}else{
				esqueciMinhaSenhaObj.innerHTML = $docxml;
			}
		}else{
			esqueciMinhaSenhaObj.innerHTML = 'Erro 404 - Tente novamente mais tarde.';
		}
	}
}

function clearEsqueciMinhaSenha(){
	setStyle('esqueciMinhaSenha','display','none');
	document.getElementById('emailCliente').value = '';
	document.getElementById('esqueciMinhaSenhaResponse').innerHTML = '';
}

function validaTipoCliente(tipoCliente){
	var tipoClienteFisica = document.getElementById('tipoClienteFisica');
	var tipoClienteJuridica = document.getElementById('tipoClienteJuridica');
	if((tipoClienteFisica.checked == false)&&(tipoClienteJuridica.checked==false)){
		alert('Selecione o tipo de cliente ao lado.');
		return false;
	}
	
}