/*****     TYNE MCE     *****/
//	CLASSE PARA TRABALHAR COM UM EDITOR DE TEXTO
/*
INSTANCIA	> determina o tipo de editor [1. tipo do editor ('simple'|'full')]
> render - renderiza as textareas
> buildAllButtons - monta cadeia de bot�es para serem renderizados, � executado quando o editor � advanced e ao executar a fun��o render
*/

function TinyMce(TinyMceType){
	var $type = TinyMceType;	/*	simple	|	full	*/
	
	/*	ITENS DO EDITOR PARA ADVANCED	*/
	
	var $plugins = '';
	var $buttons1 = '';
	var $buttons2 = '';
	var $buttons3 = '';
	var $buttons4 = '';
	var $content_css = "css/content.css";
	var $template_external = "lists/template_list.js";
	var $external_link = "lists/link_list.js";
	var $external_image = "lists/image_list.js";
	var $media_external = "lists/media_list.js";
	
	/******		PLUGINS		******/
	var $safari = true;							var $pagebreak = true;							var $style = true;
	var $layer = true;							var $table = true;								var $save = true;
	var $advhr = true;							var $advimage = true;							var $advlink = true;
	var $emotions = true;						var $iespell = true;							var $inlinepopups = true;
	var $insertdatetime = true;					var $preview = true;							var $media = true;
	var $searchreplace = true;					var $print = true;								var $contextmenu = true;
	var $paste = true;							var $directionality = true;						var $fullscreen = true;
	var $noneditable = true;					var $visualchars = true;						var $nonbreaking = true;
	var $xhtmlxtras = true;						var $template = true;
	
	/******		BUTTONS 1		******/
	var $saveBt1 = false;						var $newdocument = false;						var $bold = true;
	var $italic = true;							var $underline = true;							var $strikethrough = true;
	var $justifyleft = true;					var $justifycenter = true;						var $justifyright = true;
	var $justifyfull = true;					var $styleselect = true;						var $formatselect = true;
	var $fontselect = true;						var $fontsizeselect = true;
	
	/******		BUTTONS 2		******/
	var $cut = false;							var $copy = false;								var $paste = true;
	var $pastetext = true;						var $pasteword = true;							var $search = true;
	var $replace = true;						var $bullist = true;							var $numlist = true;
	var $outdent = true;						var $indent = true;								var $blockquote = true;
	var $undo = true;							var $redo = true;								var $link = true;
	var $unlink = true;							var $anchor = false;							var $image = true;
	var $cleanup = false;						var $help = false;								var $code = false;
	var $insertdate = true;						var $inserttime = true;							var $preview = true;
	var $forecolor = true;						var $backcolor = true;
	
	/******		BUTTONS 3		******/
	var $tablecontrols = true;					var $hr = true;									var $removeformat = true;
	var $visualaid = true;						var $sub = true;								var $sup = true;
	var $charmap = true;						var $emotionsBt3 = false;						var $iespell = true;
	var $media = true;							var $advhr = true;								var $print = true;
	var $ltr = true;							var $rtl = true;								var $fullscreen = true;
	
	/******		BUTTONS 4		******/
	var $insertlayer = false;					var $moveforward = false;						var $movebackward = false;
	var $absolute = false;						var $styleprops = false;						var $cite = false;
	var $abbr = false;							var $acronym = false;							var $del = false;
	var $ins = false;							var $attribs = false;							var $visualchars = false;
	var $nonbreaking = false;					var $template = false;							var $pagebreak = false;
	
	/******		ALINHAMENTO		******/
	var $toolbar_location = 'top';				//	POSI��O DO MENU
	var $toolbar_align = 'left';				//	ALINHAMENTO DO MENU
	var $statusbar_location = 'bottom';			//	
	var $resizing = true;						//	EDITOR PODE SER REDIMENSIONADO
	
	
	this.render = function(){
		if($type=='simple'){
			tinyMCE.init({
				mode : "textareas",
				theme : "simple"
			});
		}else{
			this.buildAllButtons();
			tinyMCE.init({
				// General options
				mode : "textareas",
				theme : "advanced",
				plugins : $plugins,
		
				// Theme options
				theme_advanced_buttons1 : $buttons1,
				theme_advanced_buttons2 : $buttons2,
				theme_advanced_buttons3 : $buttons3,
				theme_advanced_buttons4 : $buttons4,
				theme_advanced_toolbar_location : $toolbar_location,
				theme_advanced_toolbar_align : $toolbar_align,
				theme_advanced_statusbar_location : $statusbar_location,
				theme_advanced_resizing : $resizing,
		
				// Example content CSS (should be your site CSS)
				content_css : $content_css,
		
				// Drop lists for link/image/media/template dialogs
				template_external_list_url : $template_external,
				external_link_list_url : $external_link,
				external_image_list_url : $external_image,
				media_external_list_url : $media_external,
				
				// Replace values for the template plugin
				template_replace_values : {
					username : "Some User",
					staffid : "991234"
				}
			});
		}
	}
	
	this.buildAllButtons = function(){
		//	CONSTRUINDO PLUGINS
		if( $safari===true ){ $plugins += 'safari,'; }					if( $pagebreak===true ){ $plugins += 'pagebreak,'; }
		if( $style===true ){ $plugins += 'style,'; }					if( $layer===true ){ $plugins += 'layer,'; }
		if( $table===true ){ $plugins += 'table,'; }					if( $save===true ){ $plugins += 'save,'; }
		if( $advhr===true ){ $plugins += 'advhr,'; }					if( $advimage===true ){ $plugins += 'advimage,'; }
		if( $advlink===true ){ $plugins += 'advlink,'; }				if( $emotions===true ){ $plugins += 'emotions,'; }
		if( $iespell===true ){ $plugins += 'iespell,'; }				if( $inlinepopups===true ){ $plugins += 'inlinepopups,'; }
		if( $insertdatetime===true ){ $plugins += 'insertdatetime,'; }	if( $preview===true ){ $plugins += 'preview,'; }
		if( $media===true ){ $plugins += 'media,'; }					if( $searchreplace===true ){ $plugins += 'searchreplace,'; }
		if( $print===true ){ $plugins += 'print,'; }					if( $contextmenu===true ){ $plugins += 'contextmenu,'; }
		if( $paste===true ){ $plugins += 'paste,'; }					if( $directionality===true ){ $plugins += 'directionality,'; }
		if( $fullscreen===true ){ $plugins += 'fullscreen,'; }			if( $noneditable===true ){ $plugins += 'noneditable,'; }
		if( $visualchars===true ){ $plugins += 'visualchars,'; }		if( $nonbreaking===true ){ $plugins += 'nonbreaking,'; }
		if( $xhtmlxtras===true ){ $plugins += 'xhtmlxtras,'; }			if( $template===true ){ $plugins += 'template'; }
		
		//	CONSTRUINDO BUTTONS1
		if( $saveBt1===true ){ $buttons1 += 'save,'; }					if( $newdocument===true ){ $buttons1 += 'newdocument,|,'; }
		if( $bold===true ){ $buttons1 += 'bold,'; }						if( $italic===true ){ $buttons1 += 'italic,'; }
		if( $underline===true ){ $buttons1 += 'underline,'; }			if( $strikethrough===true ){ $buttons1 += 'strikethrough,|,'; }
		if( $justifyleft===true ){ $buttons1 += 'justifyleft,'; }		if( $justifycenter===true ){ $buttons1 += 'justifycenter,'; }
		if( $justifyright===true ){ $buttons1 += 'justifyright,'; }		if( $justifyfull===true ){ $buttons1 += 'justifyfull,'; }
		if( $styleselect===true ){ $buttons1 += 'styleselect,'; }		if( $formatselect===true ){ $buttons1 += 'formatselect,'; }
		if( $fontselect===true ){ $buttons1 += 'fontselect,'; }			if( $fontsizeselect===true ){ $buttons1 += 'fontsizeselect'; }
		
		//	CONSTRUINDO BUTTONS2
		if( $cut===true ){ $buttons2 += 'cut,'; }						if( $copy===true ){ $buttons2 += 'copy,'; }
		if( $paste===true ){ $buttons2 += 'paste,'; }					if( $pastetext===true ){ $buttons2 += 'pastetext,'; }
		if( $pasteword===true ){ $buttons2 += 'pasteword,|,'; }			if( $search===true ){ $buttons2 += 'search,'; }
		if( $replace===true ){ $buttons2 += 'replace,|,'; }				if( $bullist===true ){ $buttons2 += 'bullist,'; }
		if( $numlist===true ){ $buttons2 += 'numlist,|,'; }				if( $outdent===true ){ $buttons2 += 'outdent,'; }
		if( $indent===true ){ $buttons2 += 'indent,'; }					if( $blockquote===true ){ $buttons2 += 'blockquote,|,'; }
		if( $undo===true ){ $buttons2 += 'undo,'; }						if( $redo===true ){ $buttons2 += 'redo,|,'; }
		if( $link===true ){ $buttons2 += 'link,'; }						if( $unlink===true ){ $buttons2 += 'unlink,'; }
		if( $anchor===true ){ $buttons2 += 'anchor,'; }					if( $image===true ){ $buttons2 += 'image,'; }
		if( $cleanup===true ){ $buttons2 += 'cleanup,'; }				if( $cleanup===true ){ $buttons2 += 'cleanup,'; }
		if( $help===true ){ $buttons2 += 'help,'; }						if( $code===true ){ $buttons2 += 'code,|,'; }
		if( $insertdate===true ){ $buttons2 += 'insertdate,'; }			if( $inserttime===true ){ $buttons2 += 'inserttime,'; }
		if( $preview===true ){ $buttons2 += 'preview,|,'; }				if( $forecolor===true ){ $buttons2 += 'forecolor,'; }
		if( $backcolor===true ){ $buttons2 += 'backcolor'; }
		
		//	CONSTRUINDO BUTTONS3
		if( $tablecontrols===true ){ $buttons3 += 'tablecontrols,|,'; }	if( $hr===true ){ $buttons3 += 'hr,'; }
		if( $removeformat===true ){ $buttons3 += 'removeformat,'; }		if( $visualaid===true ){ $buttons3 += 'visualaid,|,'; }
		if( $sub===true ){ $buttons3 += 'sub,'; }						if( $sup===true ){ $buttons3 += 'sup,|,'; }
		if( $charmap===true ){ $buttons3 += 'charmap,'; }				if( $emotionsBt3===true ){ $buttons3 += 'emotions,'; }
		if( $iespell===true ){ $buttons3 += 'iespell,'; }				if( $media===true ){ $buttons3 += 'media,'; }
		if( $advhr===true ){ $buttons3 += 'advhr,|,'; }					if( $print===true ){ $buttons3 += 'print,|,'; }
		if( $ltr===true ){ $buttons3 += 'ltr,'; }						if( $rtl===true ){ $buttons3 += 'rtl,|,'; }
		if( $fullscreen===true ){ $buttons3 += 'fullscreen'; }
		
		//	CONSTRUINDO BUTTONS4
		if( $insertlayer===true ){ $buttons4 += 'insertlayer,'; }		if( $moveforward===true ){ $buttons4 += 'moveforward,'; }
		if( $movebackward===true ){ $buttons4 += 'movebackward,'; }		if( $absolute===true ){ $buttons4 += 'absolute,|,'; }
		if( $styleprops===true ){ $buttons4 += 'styleprops,|,'; }			if( $cite===true ){ $buttons4 += 'cite,'; }
		if( $abbr===true ){ $buttons4 += 'abbr,'; }						if( $acronym===true ){ $buttons4 += 'acronym,'; }
		if( $del===true ){ $buttons4 += 'del,'; }		if( $ins===true ){ $buttons4 += 'ins,'; }
		if( $attribs===true ){ $buttons4 += 'attribs,|,'; }		if( $visualchars===true ){ $buttons4 += 'visualchars,'; }
		if( $nonbreaking===true ){ $buttons4 += 'nonbreaking,'; }		if( $template===true ){ $buttons4 += 'template,'; }
		if( $pagebreak===true ){ $buttons4 += 'pagebreak'; }
		
	}
	
}