//	*****	BONO - NEWS
/*
> sendNews - envia uma newsletter para os dados preenchidos [1. objeto formul�rio]
> aceitarNewsletter - ativa ou desativa o status de campanha de um cliente [1. objeto formul�rio]
*/
function sendNews(sendNewsForm){
	var $form = sendNewsForm;
	var $nomeContato = $form.nomeContato;
	var $emailContato = $form.emailContato;
	var $empresaContato = $form.empresaContato;
	var $dddTelefoneContato = $form.dddTelefoneContato;
	var $telefoneContato = $form.telefoneContato;
	var $validation = new Validation();	//	OBJETO PARA VALIDA��O
	
	if($validation.checkOnlySpace($nomeContato.value)===false){
		$nomeContato.focus();
		alert('Preencha corretamente um nome para o contato.');
		return false;
	}
	if($validation.checkEmail($emailContato.value)===false){
		$emailContato.focus();
		alert('Preencha corretamente um e-mail para o contato.');
		return false;
	}
	//	VERIFICANDO SE H� ALGUM TIPO DE TELEFONE
	if($dddTelefoneContato.value!='' || $telefoneContato.value!=''){
		//	FOI DIGITADO ALGUM DOS CAMPOS DO TELEFONE
		if($validation.checkDDD($dddTelefoneContato.value)===false){
			$dddTelefoneContato.focus();
			alert('Preencha um DDD v�lido para um telefone.');
			return false;
		}
		if($validation.checkPhoneNumber($telefoneContato.value)===false){
			$telefoneContato.focus();
			alert('Preencha um telefone v�lido.');
			return false;
		}
	}
	
	var $q = window.confirm('ATEN��O, confirme seu e-mail: "'+$emailContato.value+'"');
	return $q;
}

function aceitarNewsletter(aceitarNewsletterForm){
	var $form = aceitarNewsletterForm;
	var $aceitarNewsletterAtual = $form.aceitarNewsletterAtual;
	if($aceitarNewsletterAtual.value=='1'){
		var $q = window.confirm('Voc� deseja realmente parar de receber nossas promo��es e not�cias sobre nossos produtos?');
	}else{
		var $q = window.confirm('Voc� deseja realmente voltar a receber nossas promo��es e not�cias sobre nossos produtos?');
	}
	
	return $q;
}