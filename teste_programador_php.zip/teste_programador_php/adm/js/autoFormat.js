/*****************************************************************************************************
'Nome........: mdc_formata.js
'Descricao...: Cont�m diversas fun��es em JavaScript para formata��o.
'
'Cont�m......: Filtro                - Durante a digita��o formata campos <input type=text> de acordo  com o tipo informado;
'              FiltroFinal           - Ap�s perder o foco, formata campos <input type=text> de acordo com o tipo informado;
'              FormataPagCep         - Formata um campo <input type=text> com a m�scara 99999-999;
'              FormataPagCNPJ        - Formata um campo <input type=text> com a m�scara 999.999.999/9999-99;
'              FormataPagCPF         - Formata um campo <input type=text> com a m�scara 999.999.999-99;
'              FormataPagData_mm_aaaa - Formata um campo <input type=text> com a m�scara mm/aaaa;
'              FormataPagData_dd_mm_aaaa - Formata um campo <input type=text> com a m�scara dd/mm/aaaa;
'              FormataPagDdd_Telefone - Formata um campo <input type=text> com a m�scara (99) 9999-9999;
'              FormataPagMilhar      - Formata um campo <input type=text> com a m�scara 9.999.999;
'              FormataPagTelefone    - Formata um campo <input type=text> com a m�scara 9999-9999;
'              FormataPagValor       - Formata um campo <input type=text> com a m�scara 9.999,99;
'              FormataPagValorBlur   - Formata um campo <input type=text> com a m�scara 9.999,99;
'              FormataPagPercent     - Formata um campo <input type=text> com a m�scara 999,9999;
'              FormataPagPercentBlur - Formata um campo <input type=text> com a m�scara 999,9999.
'              FormataPagInt		 - Formata um campo <input type=text> com a m�scara [0-9] (apenas n�meros).
			   formatar_moeda(campo, separador_milhar, separador_decimal, tecla);
			   formatar(src,mask);			   
******************************************************************************************************/
/*
 * Nome:        Filtro
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Durante a digita��o formata campos <input type=text> de acordo 
 *              com o tipo informado
 * Entrada:     objCampo - campo a ser formatado
 *              strTipFmt - tipo de formata��o
 * Observa��o: 
 *              1.)Sempre atribuir esta fun��o aos eventos onKeyUp e onKeyPress 
 *              inclu�da da Tag. Assim cumprimos com todas as possibilidades 
 *              de digita��o do usu�rio, inclusive se ele mantiver a tecla 
 *              pressionada.

 *              2.)Verifica qual o browser, pois nem todos os browser permitem 
 *              formatar durante a digita��o (onKeyPress e onKeyUp n�o existem)
 *
 *              3.)Certifique-se que a fun��o indicada por strTipFmt foi 
 *              inclu�da na p�gina
 */
function Filtro (objCampo, strTipFmt) { 
    // Determina o navegador e sua vers�o
    var intIndMinNS6 = ( navigator.appName.indexOf("Netscape") >= 0 &&
                         parseFloat(navigator.appVersion) >= 5) ? 1 : 0;
    var intIndMinIE4 = ( document.all ) ? 1 : 0;

    // Se � IE4
    if (intIndMinIE4) {
        /* N�o executar as fun��es de formata��o 
           caso pressionado as seguintes teclas
             8 = backspace
             9 = tab
            16 = shift
            36 = home
            37 = left arrow
            39 = right arrow
            46 = delete
        */
        if( window.event.keyCode == 37 || window.event.keyCode == 8 ||
                window.event.keyCode == 36 || window.event.keyCode == 39 ||
                window.event.keyCode == 46 || window.event.keyCode == 16 ||
                window.event.keyCode == 9 ) {
            return;
        }  
    // Se � Netscape vers�o anterior a 5
    } else if (! intIndMinNS6) {
        // N�o executar as fun��es de formata��o
        return
    }
    // Deixar o Campo apenas com caracteres de 0 � 9
    objCampo.value = (objCampo.value).replace( /\D/g, "" );

    if (strTipFmt != "Numero") {
        // Formatar o campo de acordo com o tipo informado
        objCampo.value = eval( "FormataPag" + strTipFmt + "(\"" + objCampo.value + "\")" );
    }
}

/*
 * Nome:        FiltroFinal
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Ap�s perder o foco, formata campos <input type=text> de acordo 
 *              com o tipo informado
 * Entrada:     objCampo - campo a ser formatado
 *              strTipFmt - tipo de formata��o
 * Observa��o: 
 *              1.) Sempre atribuir esta fun��o ao evento onBlur da Tag. Assim
 *              quando o usu�rio tirar o foco do campo este ser� formatado.
 *
 *              2.) N�O verifica qual o browser, pois todos os browser entendem
 *              o evento onBlur.
 *
 *              3.) Certifique-se que a fun��o indicada por strTipFmt foi 
 *              inclu�da na p�gina
 */
function FiltroFinal (objCampo, strTipFmt) {
    // Deixar o Campo apenas com caracteres de 0 � 9
    objCampo.value = (objCampo.value).replace( /\D/g, "" );

    if (strTipFmt != "Numero") {
        // Formatar o campo de acordo com o tipo informado
        objCampo.value = eval( "FormataPag" + strTipFmt + 
                "(\"" + objCampo.value + "\")" );
    }
}

/*
 * Nome:        FormataPagCep
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 99999-999
 * Entrada:     strCep - Cep que ser� formatado
 *              
 * Sa�da:       String contendo o Cep formatado
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagCep (strCep) {
    var intTamCep;
    var strCepFmt;

    //Inicializar o cep de retorno com o conte�do do cep de entrada como string
    strCepFmt = strCep.toString();

    // Obter o tamanho a strCep
    intTamCep = strCepFmt.length;
    
    if (intTamCep > 8) {
        intTamCep = 8;
        strCepFmt = strCepFmt.substr(0, 8);
    }
    
    // Formatar Cep com o -
    if (intTamCep > 5) {
        strCepFmt = strCepFmt.substr( 0, 5 ) + "-" + strCepFmt.substr( 5 );
    }

    // Retornar Cep formatada
    return strCepFmt;
}

/*
 * Nome:        FormataPagCNPJ
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 
 *              999.999.999/9999-99 
 * Entrada:     strCNPJ - CNPJ que ser� formatado
 * Sa�da:       String contendo o CNPJ formatado
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagCNPJ (strCNPJ) {
    var intCont;
    var intTamCNPJ;
    var strCNPJFmt, strCNPJAux;

    // Inicializar o CNPJ de retorno com vazio
    strCNPJFmt = "";

    // Inicializar o CNPJ auxiliar com o conte�do do CNPJ de entrada como string
    strCNPJAux = strCNPJ.toString();

    // Obter o tamanho da strCNPJ
    intTamCNPJ = strCNPJAux.length;
    
    if (intTamCNPJ > 15) {
        intTamCNPJ = 15;
        strCNPJAux = strCNPJAux.substr(0, 15);
    }

    // Formatar CNPJ com o '-', a '/' e os '.'
    if (intTamCNPJ > 2) {
        strCNPJFmt = "-" + strCNPJAux.substr(intTamCNPJ - 2);
            
        if (intTamCNPJ > 6) {
            strCNPJFmt = "/" + strCNPJAux.substr(intTamCNPJ - 6, 4) + 
                    strCNPJFmt;
                    
            for (intCont = 9; intCont <= intTamCNPJ; intCont += 3) {
                strCNPJFmt = strCNPJAux.substr( intTamCNPJ - intCont, 3 ) +
                         strCNPJFmt;
                if ( intTamCNPJ > intCont ) {
                    strCNPJFmt = "." + strCNPJFmt;
                }
            }
            
            strCNPJFmt = strCNPJAux.substr( 0, intTamCNPJ - intCont + 3 ) + 
                    strCNPJFmt;        
        } else {
            strCNPJFmt = strCNPJAux.substr( 0, intTamCNPJ - 2 ) + strCNPJFmt;       
        }     
    } else {
        strCNPJFmt = strCNPJAux;
    }    
    // Retornar CNPJ formatada
    return strCNPJFmt;
}

/*
 * Nome:        FormataPagCPF
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 
 *              999.999.999-99 
 * Entrada:     strCPF - CPF que ser� formatado
 * Sa�da:       String contendo o CPF formatado
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagCPF (strCPF) {
    var intCont;
    var intTamCPF;
    var strCPFFmt, strCPFAux;

    // Inicializar o CPF de retorno com vazio
    strCPFFmt = "";

    // Inicializar o CPF auxiliar com o conte�do do CPF de entrada como string
    strCPFAux = strCPF.toString();

    // Obter o tamanho da strCPF
    intTamCPF = strCPFAux.length;
    
    if (intTamCPF > 11) {
        intTamCPF = 11;
        strCPFAux = strCPFAux.substr(0, 11);
    }

    // Formatar CPF com o '-' e os '.'
    if ( intTamCPF > 2 ) {
        strCPFFmt = "-" + strCPFAux.substr(intTamCPF - 2);

        for ( intCont = 5; intCont <= intTamCPF; intCont += 3 ) {
            strCPFFmt = strCPFAux.substr( intTamCPF - intCont, 3 ) + strCPFFmt;
            if ( intTamCPF > intCont ) {
                strCPFFmt = "." + strCPFFmt;
            }            
        }

        strCPFFmt = strCPFAux.substr( 0, intTamCPF - intCont + 3 ) + strCPFFmt;
    } else {
        strCPFFmt = strCPFAux;
    }
    
    // Retornar CPF formatada
    return strCPFFmt;
}

/*
 * Nome:        FormataPagData_mm_aaaa
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara mm/aaaa 
 * Entrada:     strData - data que ser� formatada
 *                                                  
 * Sa�da:       String do tamanho intTamanhoFinal, ap�s inserir o caracter
 *              strCaracter do lado strLado da string
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagData_mm_aaaa (strData) {
    var intTamData;
    var strDataFmt;

    // Inicializar a data de retorno com o conte�do da data de entrada como 
    //string
    strDataFmt = strData.toString();

    // Obter o tamanho a strData
    intTamData = strDataFmt.length;

    if (intTamData > 6) {
        intTamData = 6;
        strDataFmt = strDataFmt.substr(0, 6);
    }
    
    // Formatar data com as /  
    if ( intTamData > 2 ) {
        strDataFmt = strDataFmt.substr( 0, 2 ) + "/" + strDataFmt.substr( 2 );
    }
    // Retornar data formatada
    return strDataFmt;
}

/*
 * Nome:        FormataPagData_dd_mm_aaaa
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara dd/mm/aaaa 
 * Entrada:     strData - data que ser� formatada
 *              
 * Sa�da:       String contendo a data formatada     
 *    
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia          
 */
function FormataPagData_dd_mm_aaaa (strData) {
    var intTamData;
    var strDataFmt;

    // Inicializar a data de retorno com o conte�do da data de entrada como 
    //string
    strDataFmt = strData.toString();

    // Obter o tamanho a strData
    intTamData = strDataFmt.length;

    if (intTamData > 8) {
        intTamData = 8;
        strDataFmt = strDataFmt.substr(0, 8);
    }
      
    // Formatar data com as /  
    if (intTamData > 4) {
        strDataFmt = strDataFmt.substr( 0, 2 ) + "/" + strDataFmt.substr( 2, 2 ) 
                + "/" + strDataFmt.substr( 4 );

    } else if ( intTamData > 2 ) {
        strDataFmt = strDataFmt.substr( 0, 2 ) + "/" + strDataFmt.substr( 2 );
    } 
    // Retornar data formatada
    return strDataFmt;
}

/*
 * Nome:        FormataPagDdd_Telefone
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara (99) 9999-9999 
 * Entrada:     strTelefone - Telefone que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Telefone formatado
 *              
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagDdd_Telefone (strTelefone) {
    var intTamTelefone;
    var strTelefoneFmt;

    // Inicializar o Telefone de retorno com o conte�do do Telefone de entrada
    // como string
    strTelefoneFmt = strTelefone.toString();

    // Obter o tamanho a strTelefone
    intTamTelefone = strTelefoneFmt.length;
    
    if (intTamTelefone > 10) {
        intTamTelefone = 10;
        strTelefoneFmt = strTelefoneFmt.substr(0, 10);
    }
    
    // Formatar Telefone com o -    
    if (intTamTelefone > 6) {
        strTelefoneFmt = "" + strTelefoneFmt.substr(0, 2) + " " +
                strTelefoneFmt.substr(2, 4) + "-" +
                strTelefoneFmt.substr(6, 4);
    
    } else if (intTamTelefone > 1) {
        strTelefoneFmt = "" + strTelefoneFmt.substr(0, 2) + " " +
                strTelefoneFmt.substr(2, 4) 
    
    } else if (intTamTelefone > 0) {
        strTelefoneFmt = "" + strTelefoneFmt;
    }
    
    // Retornar Telefone formatado
    return strTelefoneFmt;
}

/*
 * Nome:        FormataPagMilhar
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 9.999.999 ... 
 * Entrada:     strMilhar - Milhar que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Milhar formatado
 *             
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagMilhar (strMilhar) {
    var intCont;
    var intTamMilhar;
    var strMilharFmt, strMilharAux;

    // Inicializar o Milhar de retorno com vazio
    strMilharFmt = "";

    // Inicializar o Milhar auxiliar com o conte�do do Milhar de entrada como 
    //string
    strMilharAux = strMilhar.toString();

    // Obter o tamanho da strMilhar
    intTamMilhar = strMilharAux.length;

    // Formatar Milhar com os .
    if (intTamMilhar > 3) {
        for (intCont = 3; intCont <= intTamMilhar; intCont += 3) {
            strMilharFmt = strMilharAux.substr( intTamMilhar - intCont, 3) +
                    strMilharFmt;
            if ( intTamMilhar > intCont )  {
                strMilharFmt = "." + strMilharFmt;
            }
        }

        strMilharFmt = strMilharAux.substr( 0, intTamMilhar - intCont + 3 ) + 
                strMilharFmt;
    
    } else { 
        strMilharFmt = strMilharAux;
    }
    // Retornar Milhar formatada
    return strMilharFmt;
    
}

/*
 * Nome:        FormataPagTelefone
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 9999-9999 
 * Entrada:     strTelefone - Telefone que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Telefone formatado
 *              
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagTelefone (strTelefone) {
    var intTamTelefone;
    var strTelefoneFmt;

    // Inicializar o Telefone de retorno com o conte�do do Telefone de entrada
    // como string
    strTelefoneFmt = strTelefone.toString();

    // Obter o tamanho a strTelefone
    intTamTelefone = strTelefoneFmt.length;
    
    if (intTamTelefone > 8) {
        intTamTelefone = 8;
        strTelefoneFmt = strTelefoneFmt.substr(0, 8);
    }
    
    // Formatar Telefone com o -
    if (intTamTelefone > 4) {
        strTelefoneFmt = strTelefoneFmt.substr(0, strTelefoneFmt.length-4) +
                "-" + strTelefoneFmt.substr(strTelefoneFmt.length-4, 4);
    }

    // Retornar Telefone formatado
    return strTelefoneFmt;
}

/*
 * Nome:        FormataPagHora_Min
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara hh:mm
 * Entrada:     strHora - hora que ser� formatada
 *              
 * Sa�da:       String contendo a hora formatada     
 *    
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia          
 */
function FormataPagHora_Min (strHora) {
    var intTamHora;
    var strHoraFmt;

    // Inicializar a hora de retorno com o conte�do da hora de entrada como 
    //string
    strHoraFmt = strHora.toString();

    // Obter o tamanho a strHora
    intTamHora = strHoraFmt.length;

    if (intTamHora > 4) {
        intTamHora = 4;
        strHoraFmt = strHoraFmt.substr(0, 4);
    }
      
    // Formatar hora com o ':'
    if (intTamHora > 2) {
        strHoraFmt = strHoraFmt.substr( 0, 2 ) + ":" + strHoraFmt.substr(2, 2);
    }

    // Retornar hora formatada
    return strHoraFmt;
}

/*
 * Nome:        FormataPagValor
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 9.999,99
 * Entrada:     strValor - Valor que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Valor formatado
 *              
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagValor (strValor) {
    var intCont;
    var intTamValor;
    var strValorFmt, strValorAux; 
	var intDecimais = 2;

    // Inicializar o Valor de retorno com vazio
    strValorFmt = "";

    // Inicializar o Valor auxiliar com o conte�do do Valor de entrada como
    // string
    strValorAux = strValor.toString();

    // Obter o tamanho da strValor
    intTamValor = strValorAux.length;

    // Formatar Valor com os . e a ,
    if (intTamValor > 2) {
        strValorFmt = "," + strValorAux.substr( intTamValor - 2, 2 );

        for (intCont = 5; intCont <= intTamValor; intCont += 3) {
            strValorFmt = strValorAux.substr( intTamValor - intCont, 3 ) + 
                    strValorFmt;
            if (intTamValor > intCont) {
                strValorFmt = "" + strValorFmt;
            }
        }

        strValorFmt = strValorAux.substr( 0, intTamValor - intCont + 3 ) + strValorFmt;
    } else {
        strValorFmt = strValorAux;
    }    

    // Retornar Valor formatada
    return strValorFmt;
    
}

/*
 * Nome:        FormataPagValorBlur
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 9.999,99    
 * Entrada:     strValor - Valor que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Valor formatado
 *              
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagValorBlur (strValor) {
    var intCont;
    var intTamValor;
    var strValorFmt, strValorAux;

    // Inicializar o Valor de retorno com vazio
    strValorFmt = "";

    // Inicializar o Valor auxiliar com o conte�do do Valor de entrada como
    // string
    strValorAux = strValor.toString();

    // Obter o tamanho da strValor
    intTamValor = strValorAux.length;

    // Formatar Valor com os . e a ,
    if ( intTamValor > 2 ) {
        strValorFmt = "," + strValorAux.substr( intTamValor - 2, 2 );

        for ( intCont = 5; intCont <= intTamValor; intCont += 3 ) {
            strValorFmt = strValorAux.substr( intTamValor - intCont, 3 ) + 
                    strValorFmt;
            if ( intTamValor > intCont ) {
                strValorFmt = "" + strValorFmt;
            }
        }

        strValorFmt = strValorAux.substr( 0, intTamValor - intCont + 3 ) +
                strValorFmt;
    } else if ( intTamValor == 0 ) {
        strValorFmt = strValorAux;
    } else {
         strValorFmt = strValorAux + ",00";
    }

    // Retornar ValorBlur formatada
    return strValorFmt;
}

/*
 * Nome:        FormataPagPercent
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 99,9999
 * Entrada:     strValor - Valor que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Valor formatado
 *              
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagPercent (strValor) {
    var intCont;
    var intTamValor;
    var strValorFmt, strValorAux; 

    // Inicializar o Valor de retorno com vazio
    strValorFmt = "";

    // Inicializar o Valor auxiliar com o conte�do do Valor de entrada como
    // string
    strValorAux = strValor.toString();

    // Obter o tamanho da strValor
    intTamValor = strValorAux.length;

    // Formatar Valor com a ,
    if (intTamValor > 4) {
        strValorFmt = strValorAux.substr( 0, intTamValor - 4 ) +
                      "," + strValorAux.substr( intTamValor - 4, 4 );
    } else {
        strValorFmt = strValorAux;
    }    

    // Retornar Valor formatada
    return strValorFmt;
    
}

/*
 * Nome:        FormataPagPercentBlur
 * Autor:       NaBoa Solutions - Marcela Pimenta
 * Data:        06/08/2003
 * Descri��o:   Formata um campo <input type=text> com a m�scara 99,9999
 * Entrada:     strValor - Valor que ser� formatado
 *                                                  
 * Sa�da:       String contendo o Valor formatado
 *              
 * Observa��o: 
 *              1.) Normalmente utilizada para formatar campos da p�gina
 *
 *              2.) N�o faz nenhuma consist�ncia
 */
function FormataPagPercentBlur (strValor) {
    var intCont;
    var intTamValor;
    var strValorFmt, strValorAux;

    // Inicializar o Valor de retorno com vazio
    strValorFmt = "";

    // Inicializar o Valor auxiliar com o conte�do do Valor de entrada como
    // string
    strValorAux = strValor.toString();

    // Obter o tamanho da strValor
    intTamValor = strValorAux.length;

    // Formatar Valor com os . e a ,
    if ( intTamValor > 4 ) {
        strValorFmt = strValorAux.substr( 0, intTamValor - 4 ) +
                      "," + strValorAux.substr( intTamValor - 4, 4 );
    } else if ( intTamValor == 0 ) {
        strValorFmt = strValorAux;
    } else if ( intTamValor == 4 ) {
        strValorFmt = "0," + strValorAux.substr( intTamValor - 4, 4 );
    } else {
         strValorFmt = strValorAux + ",0000";
    }

    // Retornar ValorBlur formatada
    return strValorFmt;
}

function FormataPagIE (strIE) {
    var intTamIE;
    var strIEFmt;

    //Inicializar o cep de retorno com o conte�do do cep de entrada como string
    strIEFmt = strIE.toString();

    // Obter o tamanho a strCep
    intTamIE = strIEFmt.length;
    
    if (intTamIE > 15) {
        intTamIE = 15;
        strIEFmt = strIEFmt.substr(0, 15);
    }
    
    // Formatar IE com o . depois dos 3
    if (intTamIE > 3) {
        strIEFmt = strIEFmt.substr( 0, 3 ) + "." + strIEFmt.substr( 3 );
    }
    // Formatar IE com o . depois dos 6
    if (intTamIE > 6) {
        strIEFmt = strIEFmt.substr( 0, 7 ) + "." + strIEFmt.substr( 7 );
    }
    if (intTamIE > 9) {
        strIEFmt = strIEFmt.substr( 0, 11 ) + "." + strIEFmt.substr( 11 );
    }

    // Retornar Cep formatada
    return strIEFmt;
}

function FormataPagInt (FormataPagIntStr) {
    var $str = FormataPagIntStr;
	var $not = /[^0-9]/g;
	var $newStr = $str.replace($not,'');
    // Retornar Cep formatada
    return $newStr;
}
function formatar_moeda(campo, separador_milhar, separador_decimal, tecla) {
	var sep = 0;
	var key = '';
	var i = j = 0;
	var len = len2 = 0;
	var strCheck = '0123456789';
	var aux = aux2 = '';
	var whichCode = (window.Event) ? tecla.which : tecla.keyCode;

	if (whichCode == 13) return true; // Tecla Enter
	if (whichCode == 8) return true; // Tecla Delete
	key = String.fromCharCode(whichCode); // Pegando o valor digitado
	if (strCheck.indexOf(key) == -1) return false; // Valor inv�lido (n�o inteiro)
	len = campo.value.length;
	for(i = 0; i < len; i++)
	if ((campo.value.charAt(i) != '0') && (campo.value.charAt(i) != separador_decimal)) break;
	aux = '';
	for(; i < len; i++)
	if (strCheck.indexOf(campo.value.charAt(i))!=-1) aux += campo.value.charAt(i);
	aux += key;
	len = aux.length;
	if (len == 0) campo.value = '';
	if (len == 1) campo.value = '0'+ separador_decimal + '0' + aux;
	if (len == 2) campo.value = '0'+ separador_decimal + aux;

	if (len > 2) {
		aux2 = '';

		for (j = 0, i = len - 3; i >= 0; i--) {
			if (j == 3) {
				aux2 += separador_milhar;
				j = 0;
			}
			aux2 += aux.charAt(i);
			j++;
		}

		campo.value = '';
		len2 = aux2.length;
		for (i = len2 - 1; i >= 0; i--)
		campo.value += aux2.charAt(i);
		campo.value += separador_decimal + aux.substr(len - 2, len);
	}

	return false;
}
function formatar(src, mask){
  var i = src.value.length;
  var saida = mask.substring(0,1);
  var texto = mask.substring(i)
if (texto.substring(0,1) != saida)
  {
    src.value += texto.substring(0,1);
  }
}