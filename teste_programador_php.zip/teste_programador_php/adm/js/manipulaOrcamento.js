//	*****	QUIDDE - MANIPULAORCAMENTO
/*
> addProduto - adiciona um produto na lista de or�amento [1. objeto formul�rio]
> removeProduto - remove um produto por inteiro da lista de or�amento [1. c�digo do produto]
*/

function addProduto(addProdutoForm){
	var $form = addProdutoForm;
	var $openOrcamento = $form.openOrcamento;
	var $codProduto = $form.codProduto;
	var $quantidadeProduto = $form.quantidadeProduto;
	var $validation = new Validation();
	if($codProduto==''){
		alert('Ocorreu um problema ao inserir o produto. Produto n�o encontrado.\nEsta p�gina n�o pode continuar, tente mais tarde ou contate o administrador.');
		self.location = 'meuOrcamento.php';
		return false;
	}
	
	if($validation.checkInt($quantidadeProduto.value)==false || $quantidadeProduto.value=='0'){
		$quantidadeProduto.focus();
		alert('Insira um valor v�lido, apenas n�meros.');
		return false;
	}
	//	CONFIRMA��O DE ABERTURA DE UM OR�AMENTO
	if($openOrcamento.value=='0'){
		var $confirm = confirm('Voc� no momento n�o possui nenhum pedido em aberto.\nDeseja continuar com o processo e abrir um novo pedido?');
		if($confirm==false){
			return false;
		}
	}
	
	
	var $q = confirm('Deseja realmente inserir '+$quantidadeProduto.value+' produto(s) no carrinho?');
	return $q;
}

function removeProduto(removeProdutoCod){
	var $cod = removeProdutoCod;
	var $q = confirm('Deseja realmente remover este produto da lista de pedido?');
	if($q==true){
		self.location = 'atributos/bibliotecas/action/removeProduto.php?codProduto='+$cod;
	}

}

function atualizarProduto(quantidade,valorItem,peso,codProdutoOrcamento){

	var $quantidade = document.getElementById(quantidade).value;
	var $valorItem = document.getElementById(valorItem).value;
	var $peso = document.getElementById(peso).value;
	var $codProdutoOrcamento = document.getElementById(codProdutoOrcamento).value;
	//var $q = confirm('Deseja atualizar o pedido com estes dados?');
	var $q = true;
	if($q==true){
		self.location = 'atributos/bibliotecas/action/atualizaProduto.php?q='+$quantidade+'&v='+$valorItem+'&p='+$peso+'&c='+$codProdutoOrcamento;
		
	}

}

function habilitaCampoCliente(codCliente,sessionName,buttonSession,linkUpdate){
	var $codCliente = document.getElementById(codCliente).value;
	var $sessionName = document.getElementById(sessionName).style.display;
	var $buttonSession = document.getElementById(buttonSession).style.display;
	var $linkUpdate = document.getElementById(linkUpdate).style.display;
	var $q = true;
	if($q==true){
	document.getElementById("codCliente").disabled = false;
	document.getElementById("codCliente").style.display = "inline";
	document.getElementById("sessionName").style.display = "none";
	document.getElementById("buttonSession").style.display = "inline";
	document.getElementById("linkUpdate").style.display = "none";
	}
}

function atualizaCliente(codCliente){
	var $codCliente = document.getElementById(codCliente).value;
	var $q = true;
	if($q==true){
		self.location = ROOT_HTTP+'quidde/atributos/bibliotecas/action/updateClient.php?cdclnt='+$codCliente;
	}
}

function habilitaEstado(codEstado,codEstadoLabel,codPais){
	var $codPais = document.getElementById(codPais).value;
	var $codEstado = document.getElementById(codEstado).style.display;
	var $codEstadoLabel = document.getElementById(codEstadoLabel).style.display;
	var $q = true;
	if($q==true){
		if (document.getElementById(codPais).value == 'MzM='){
			document.getElementById(codEstado).style.display = "inline";
			document.getElementById(codEstadoLabel).style.display = "inline";
		}else{
			document.getElementById(codEstado).style.display = "none";
			document.getElementById(codEstadoLabel).style.display = "none";
		}
	}
}