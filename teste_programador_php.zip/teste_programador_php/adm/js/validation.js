//	*****	VALIDATION
/*
> checkCEP - verifica se � um cep brasileiro v�lido no formato '00000-000' [1. cep]
> checkCNPJ - verifica se � um CNPJ v�lido [1. CNPJ]
> checkCPF - verifica se � um CPF v�lido [1. CPF]
> checkDate - verifica se � uma data v�lida no formato 'DD-MM-AAAA' [1. data]
> checkDDD - verifica se � um DDD v�lido no formato (XX) apenas n�meros [1. string]
> checkEmail - verifica se � um e-mail v�lido [1. e-mail]
> checkImg - verifica se � uma imagem v�lida para o padr�o adotado no website [1. string]
> checkInt - verifica se � apenas inteiro [1. string]
> checkOnlySpace - verifica se a string � apenas espa�os em branco [1. string]
> checkPassword - verifica se � uma senha v�lida [1. password]
> checkPhone - verifica se � um n�mero de telefone|celular [1. n�mero]
> checkPhoneNumber - verifica se � um n�mero de telefone v�lido no formato (XXXXXXXX) apenas n�meros [string]
> checkSizeStr - verifica se a quantidade de caractere de um conte�do coincide com os valores max e min [1. string , 2. valor m�ximo , 3. valor m�nimo]
> checkUF - verifica se � uma sigla no formato 'AA' (duas letras) [1. sigla]
> checkTypeImg - verifica qual � o tipo de imagem [1. string]
> checkLogin - verifica caracteres inadequados em um login e senha [1. string]
*/
function Validation(){
	
	this.checkCEP = function(checkCEPValue){
		var $valid = /[0-9]{5}-[0-9]{3}/;
		var $number = checkCEPValue;
		var $src = $number.search($valid);
		if($src===0){
			return true;
		}else{
			return false;
		}
	}
	
	this.checkCNPJ = function(checkCNPJStr) {
		var $cnpj = checkCNPJStr;
		var $valid = /^([0-9]){2,3}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$/;
		$src = $cnpj.search($valid);
		if($src==-1){
			return false;
		}
		if($cnpj.length==18){
			var $chars = new Array(6,5,4,3,2,9,8,7,6,5,4,3,2);
		}else{
			var $chars = new Array(7,6,5,4,3,2,9,8,7,6,5,4,3,2);
		}
		//	CRIANDO UM CNPJ COM APENAS N�MEROS
		var $rep = /\.|\/|\-/g;
		var $int = $cnpj.replace($rep,'');
		//	EXECUTANDO A OPERA��O DOS D�GITOS
			//	GERANDO 1� DIGITO
		var $soma = 0;
		for(var $i=0;$i<$int.length-2;$i++){
			$soma+= $int.substr($i,1)*$chars[$i+1];
		}
		var $rest = $soma%11;
		var $firstDigit = $rest<2 ? 0 : (11-$rest);
		
			//	GERANDO 2� DIGITO
		$soma = 0;
		for(var $i=0;$i<$int.length-1;$i++){
			$soma+= $int.substr($i,1)*$chars[$i];
		}
		$rest = $soma%11;
		var $secondDigit = $rest<2 ? 0  : (11-$rest);
		//	VERIFICANDO ULTIMOS DIGITOS
		var $pD = $int.substr($int.length-2,1);
		var $uD = $int.substr($int.length-1,1);
		if($firstDigit!=$pD){
			return false;
		}else if($secondDigit!=$uD){
			return false;
		}else{
			return true;
		}
	}
	
	this.checkCPF = function(checkCPFValue){
		var $valid = /^[0-9]{3}\.[0-9]{3}\.[0-9]{3}\-[0-9]{2}$/;
		var $cpf = checkCPFValue;
		var $src = $cpf.search($valid);
		if($src!=0){
			return false;
		}
		//	REMOVE OTHERS CHARACTERS
		$cpf = $cpf.replace(/\./g,"");
		$cpf = $cpf.replace(/\-/g,"");
		
		//	CREATING ARRAY WITH DIGITS
		var $array = new Array();
		for(var $i=0;$i<$cpf.length;$i++){
			$array[$i] = $cpf.substr($i,1);
		}
		
		for($i=1;$i<=9;$i++){
			$error = new String();
			for(var $j = 0;$j<11;$j++){
				$error+=$i;
			}
			if($error===$cpf){
				return false;
			}
		}
		
		//	GENERATING THE FIRST DIGIT
		var $add = 0;
		for($i=0;$i<9;$i++){
			$add += $array[$i]*(10-$i);
		}
		$rest = $add%11;
		if($rest<2){
			$firstDigit = 0;
		}else{
			$firstDigit = 11-$rest;
		}
		
		//	CHECK FIRST DIGIT
		if($firstDigit!=$array[9]){
			return false;
		}
		
		//	GENERATING THE SECOND DIGIT
		$add = 0;
		for($i=0;$i<10;$i++){
			$add += $array[$i]*(11-$i);
		}
		$rest = $add%11;
		if($rest<2){
			$secondDigit = 0;
		}else{
			$secondDigit = 11-$rest;
		}
		
		//	CHECK SECOND DIGIT
		if($secondDigit!=$array[10]){
			return false;
		}
		
		return true;
	}
	
	this.checkDate = function(checkDateValue){
		var $value = checkDateValue;
		var $reg = /^((0[0-9]|[12][0-9]|3[01])\/(0[13578]|1[02])|(0[0-9]|[12][0-9]|3+0)\/(0[469]|1[1])|(0[0-9]|[12][0-8])\/(0+2))\/(1+9|2[01])[0-9]{2}$/;
		var $check = $value.search($reg);
		if($check!='0'){
			return false;
		}else{
			return true;
		}
	}
	
	this.checkDDD = function(checkDDDStr){
		var $str = checkDDDStr;
		var $src = /^[0-9]{2}$/;
		return $str.search($src)==0 ? true : false;
	}
	
	this.checkEmail = function(checkEmailValue){
		var $valid = /^[\.,\w]*?\w*@\w*\.\w*[\.,\w]*?$/;
		var $email = checkEmailValue;
		var $src = $email.search($valid);
		if($src===0){
			return true;
		}else{
			return false;
		}
	}
	
	this.checkImg = function(checkImgPath){
		var $path = checkImgPath;
		var $type = this.checkTypeImg($path);
		switch($type){
			case 'jpg':
			case 'gif':
			case 'png':
				$return = true;
				break;
			default:
				$return = 'Formato de imagem inv�lida, apenas (*.jpg,*.gif,*.png).';
				break;
		}
		return $return;
	}
	
	this.checkInt = function(checkIntStr){
		var $str = checkIntStr;
		var $src = /^[0-9]/g;
		return $str.search($src)==0 ? true : false;
	}
	
	this.checkOnlySpace = function(checkOnlySpaceStr){
		var $str = checkOnlySpaceStr;
		var $src = /^\s*?$/g;
		return $str.search($src)=='-1' ? true : false;
	}
	
	this.checkPassword = function(checkPasswordValue){
		var $valid = /^\w{6,20}$/;
		var $pass = checkPasswordValue;
		var $src = $pass.search($valid);
		if($src===0){
			return true;
		}else{
			return false;
		}
	}
	
	this.checkPhone = function(checkPhoneValue){
		var $valid = /^[0-9]{2} [0-9]{8}$/;
		var $phone = checkPhoneValue;
		var $src = $phone.search($valid);
		if($src===0){
			return true;
		}else{
			return false;
		}
	}
	
	this.checkPhoneNumber = function(checkPhoneNumberStr){
		var $str = checkPhoneNumberStr;
		var $src = /^[0-9]{8}$/;
		return $str.search($src)==0 ? true : false;
	}
	
	this.checkSizeStr = function(checkSizeStrStr,checkSizeStrMax,checkSizeStrMin){
		var $str = checkSizeStrStr;
		var $max = checkSizeStrMax;
		var $min = checkSizeStrMin;
		
		var $size = $str.length;
		return $size>=$min&&$size<=$max ? true : false;
	}
	
	this.checkUF = function(checkUFValue){
		var $valid = /^[a-zA-Z]{2}$/;
		var $uf = checkUFValue;
		var $src = $uf.search($valid);
		if($src===0){
			return true;
		}else{
			return false;
		}
	}
	
	this.checkTypeImg = function(checkTypeImgPath){
		var $path = checkTypeImgPath;
		var $delimiter = $path.lastIndexOf('.');
		var $type = $path.substr($delimiter+1);
		return $type.toLowerCase();
	}
	
	this.checkLogin = function(checkLoginStr){
		var $str = checkLoginStr;
		var $not = /^([a-z|0-9]){6,10}$/;
		return $str.search($not)==0 ? true : false;
	}
}