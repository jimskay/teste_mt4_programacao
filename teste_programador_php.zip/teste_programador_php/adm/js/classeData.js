function Data(){
	var $data = new Date();
	var $dia = $data.getDate();
	var $semana = $data.getDay();
	var $mes = $data.getMonth();
	var $ano = $data.getFullYear();
	
	this.completa = function(){
		var diaSemana = new Array("Domingo","Segunda-Feira","Ter�a-Feira","Quarta-Feira","Quinta-Feira","Sexta-Feira","S�bado");
		var meses = new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
		var objData = document.getElementById("data");
		
		data.innerHTML = (diaSemana[$semana]+", "+$dia+" de "+meses[$mes]+" de "+$ano);	
	}
	
}