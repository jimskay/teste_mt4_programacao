//	***	CREATE OBJECTS OF A DOCUMENT	***	//
function Dom(){
	
				/*	OBJECTS OF FORM	*/
	this.select = function(selectName){
		var $name = selectName;
		var $select = document.createElement('select');
		$select.setAttribute('name',$name);
		return $select;
	}
	
	this.option = function(optionText,optionValue){
		var $text = optionText;
		var $value = optionValue;
		var $option = document.createElement('option');
		var $optionText = document.createTextNode($text);
		$option.appendChild($optionText);
		$option.setAttribute('value',$value);
		return $option;
	}
	this.input = function(inputType,inputName,inputValue){
		var $type = inputType;
		var $name = inputName;
		var $value = inputValue;
		var $input = document.createElement('input');
		$input.setAttribute('type',$type);
		$input.setAttribute('name',$name);
		$input.setAttribute('value',$value);
		return $input;
	}
	
				/*	OBJECTS OF TABLE	*/
	this.tr = function(trId,trClass){
		var $id = trId;
		var $class = trClass;
		var $tr = document.createElement('tr');
		$tr.setAttribute('id',$id);
		$tr.setAttribute('class',$class);
		$tr.setAttribute('className',$class);
		return $tr;
	}
	this.td = function(tdId,tdClass){
		var $id = tdId;
		var $class = $class;
		var $td = document.createElement('td');
		$td.setAttribute('id',$id);
		$td.setAttribute('class',$class);
		$td.setAttribute('className',$class);
		return $td;
	}
	this.th = function(thId,thClass){
		var $id = thId;
		var $class = $class;
		var $th = document.createElement('th');
		$th.setAttribute('id',$id);
		$th.setAttribute('class',$class);
		$th.setAttribute('className',$class);
		return $th;
	}
	
					/*	SIMPLES OBJECTS OF XHTML	*/
	this.text = function(textValue){
		var $value = textValue;
		var $text = document.createTextNode($value);
		return $text;
	}
	
					/*	SET FUNCTIONS IN AN OBJECT	*/
	this.setFunction = function(setFunctionObj,setFunctionType,setFunctionExecute){
		var $obj = setFunctionObj;
		var $type = setFunctionType;
		var $execute = setFunctionExecute;
		$obj.setAttribute($type,$execute);
		$obj[$type] = $execute;
		return $obj;
	}
	
	this.li = function(){
		var $li = document.createElement('li');
		return $li;
	}
	
	this.a = function(){
		var $a = document.createElement('a');
		return $a;
	}
}