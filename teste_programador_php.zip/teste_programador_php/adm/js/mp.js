// JavaScript Document

function manipulaValorCategorias(quantidade,valor,valorPersonalizado,valorItem,objeto,peso,pesoItem,quantidadeBase){

	Filtro(objeto,'Int');
	var $quantidade = document.getElementById(quantidade).value;
	var $valor = document.getElementById(valor).value.replace(",", ".");
	var $valorPersonalizado = document.getElementById(valorPersonalizado);
	var $valorItem = document.getElementById(valorItem);
	var $peso = document.getElementById(peso).value.replace(",", ".");
	var $pesoItem = document.getElementById(pesoItem);
	var $quantTotal = 0;
	var $totalItem = 0;
	var $descricaoFotoProduto = '';
	

	var $qtCampos = document.getElementById("qtCampos").value;	
	for($i=2;$i<=$qtCampos;$i++){
		$quantTotal += document.getElementById("quantidade"+$i).value*1;
		if (document.getElementById("quantidade"+$i).value*1 > 0){
			$descricaoFotoProduto += "("+document.getElementById("quantidade"+$i).value+") unidades - " + document.getElementById("descricaoFotoProduto"+$i).value +" / ";
		}
	}

	//$quantTotal.value = $quantTotal.value+$quantidade;
	$totalItem = $valor*$quantTotal;
	document.getElementById(quantidadeBase).value = $quantTotal;
	document.getElementById("descItemPedido").value = $descricaoFotoProduto;
	$valorPersonalizado.innerHTML = "R$ "+number_format($totalItem, 2, ',', '.')+"</span>";
	$valorItem.value = number_format($totalItem, 2, ',', '.');
	$pesoItem.value =number_format(($peso*$quantTotal), 3, ',', '.');
	//formataMoeda(document.getElementById('valorItem'), 2);
}

//<![CDATA[
addEvent = function(o, e, f, s){
	var r = o[r = "_" + (e = "on" + e)] = o[r] || (o[e] ? [[o[e], o]] : []), a, c, d;
	r[r.length] = [f, s || o], o[e] = function(e){
		try{
			(e = e || event).preventDefault || (e.preventDefault = function(){e.returnValue = false;});
			e.stopPropagation || (e.stopPropagation = function(){e.cancelBubble = true;});
			e.target || (e.target = e.srcElement || null);
			e.key = (e.which + 1 || e.keyCode + 1) - 1 || 0;
		}catch(f){}
		for(d = 1, f = r.length; f; r[--f] && (a = r[f][0], o = r[f][1], a.call ? c = a.call(o, e) : (o._ = a, c = o._(e), o._ = null), d &= c !== false));
		return e = null, !!d;
    }
};
 
removeEvent = function(o, e, f, s){
	for(var i = (e = o["_on" + e] || []).length; i;)
		if(e[--i] && e[i][0] == f && (s || o) == e[i][1])
			return delete e[i];
	return false;
};
 
function formataMoeda(o, n, dig, dec){
	o.c = !isNaN(n) ? Math.abs(n) : 2;
	o.dec = typeof dec != "string" ? "," : dec, o.dig = typeof dig != "string" ? "." : dig;
	addEvent(o, "keypress", function(e){
		if(e.key > 47 && e.key < 58){
			var o, s, l = (s = ((o = this).value.replace(/^0+/g, "") + String.fromCharCode(e.key)).replace(/\D/g, "")).length, n;
			if(o.maxLength + 1 && l >= o.maxLength) return false;
			l <= (n = o.c) && (s = new Array(n - l + 2).join("0") + s);
			for(var i = (l = (s = s.split("")).length) - n; (i -= 3) > 0; s[i - 1] += o.dig);
			n && n < l && (s[l - ++n] += o.dec);
			o.value = s.join("");
		}
		e.key > 30 && e.preventDefault();
	});
}
//]]>

function number_format( number, decimals, dec_point, thousands_sep ) {
    // %        nota 1: Para 1000.55 retorna com precis�o 1 no FF/Opera � 1,000.5, mas no IE � 1,000.6
    // *     exemplo 1: number_format(1234.56);
    // *     retorno 1: '1,235'
    // *     exemplo 2: number_format(1234.56, 2, ',', ' ');
    // *     retorno 2: '1 234,56'
    // *     exemplo 3: number_format(1234.5678, 2, '.', '');
    // *     retorno 3: '1234.57'
    // *     exemplo 4: number_format(67, 2, ',', '.');
    // *     retorno 4: '67,00'
    // *     exemplo 5: number_format(1000);
    // *     retorno 5: '1,000'
    // *     exemplo 6: number_format(67.311, 2);
    // *     retorno 6: '67.31'
 
    var n = number, prec = decimals;
    n = !isFinite(+n) ? 0 : +n;
    prec = !isFinite(+prec) ? 0 : Math.abs(prec);
    var sep = (typeof thousands_sep == "undefined") ? ',' : thousands_sep;
    var dec = (typeof dec_point == "undefined") ? '.' : dec_point;
 
    var s = (prec > 0) ? n.toFixed(prec) : Math.round(n).toFixed(prec); //fix for IE parseFloat(0.55).toFixed(0) = 0;
 
    var abs = Math.abs(n).toFixed(prec);
    var _, i;
 
    if (abs >= 1000) {
        _ = abs.split(/\D/);
        i = _[0].length % 3 || 3;
 
        _[0] = s.slice(0,i + (n < 0)) +
              _[0].slice(i).replace(/(\d{3})/g, sep+'$1');
 
        s = _.join(dec);
    } else {
        s = s.replace('.', dec);
    }
 
    return s;
}

function validaFechamentoPedido(){
	
	if(!window.confirm("Deseja realmente fechar este pedido?\nAp�s este fechamento nenhuma troca de informa��o ser� poss�vel nos dados, pois o pedido ser� enviado ao PagSeguro.")){
		return false;
		
	}
	
}

function verificaFp03(formulario){
	var $form = formulario;
	var $numero = $form.numero;
	var $tipoEntrega = $form.tipoEntrega;		
	
	if($numero.value==''){
		$numero.focus();
		alert('O campo n�mero � obrigat�rio.');
		return false;
	}
	
	if($tipoEntrega.value=='0'){
		alert('Selecione como ser� a entrega (Sedex ou PAC).');
		return false;
	}
	
	
	
}