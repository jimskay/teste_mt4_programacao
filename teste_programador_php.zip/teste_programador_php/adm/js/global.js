//	REDIRECIONAMENTO
function redirect(redirectFolder){
	var $folder = redirectFolder;
	self.location = ROOT_HTTP_ADMIN+$folder+'/';
}

//	ATRIBUI UM ESTILO
function setStyle(setStyleId,setStyleType,setStyleValue){
	var $obj = document.getElementById(setStyleId);
	var $type = setStyleType;
	var $value = setStyleValue;
	$obj.style[$type] = $value;
}

function informacao(informacaoId){
	var $obj = document.getElementById(informacaoId);
	var $h = $obj.style.height;
	if($h=='auto'){
		var $nH = '25px';
	}else{
		var $nH = 'auto';
	}
	$obj.style.height = $nH;
}