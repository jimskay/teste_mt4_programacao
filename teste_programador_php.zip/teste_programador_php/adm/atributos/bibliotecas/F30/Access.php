<?php
/*
> insert (public) - faz uma consulta de inser��o [1. nome da tabela , 2. array com campos , 3. array com valores]
> select (public) - faz uma consulta de sele��o [1. nome da tabela , 2. array com campos , 3. atributos para filtragem] # array[assoc]
> update (public) - faz uma consulta de edi��o [1. nome da tabela , 2. array com campos , 3. array com valores , 4. atributos de condi��o]
> delete (public) - faz uma consulta de remo��o [1. nome da tabela , 2. atributos de condi��o]
*/
abstract class Access extends AccessCommands {

	public function __construct($dbAccess,$userAccess,$passwordAccess) {
		parent::__construct($dbAccess,$userAccess,$passwordAccess);
	}
	
	public function insert($tableAccess,$fieldAccess,$valueAccess){		
		$checkAccess = Util::testArraySize( array($fieldAccess,$valueAccess) );
		if($checkAccess!==true){
			return false;
		}else{
			$fieldsAccess = NULL;
			$sizeAccess = count($fieldAccess);
			for($i=0;$i<$sizeAccess;$i++){				
				$fieldsAccess[] = $fieldAccess[$i];
				$valuesAccess[] = "'".$valueAccess[$i]."'";
			}
			
			$fieldsAccess = implode(",",$fieldsAccess);
			$valuesAccess = implode(",",$valuesAccess);		
			$sqlAccess = "insert into ".$tableAccess." (".$fieldsAccess.") values (".$valuesAccess.")";
			//echo $sqlAccess;exit;
			$resultadoAccess = parent::queryAccess($sqlAccess);
			$returnAccess = $resultadoAccess!==false ? true : false;
			return $returnAccess;
		}
	}
	
	public function select($tableAccess,$fieldAccess,$attributeAccess = NULL){				
		$fieldsAccess = implode(",",$fieldAccess);
		$sqlAccess = "select ".$fieldsAccess." from ".$tableAccess." ".$attributeAccess;
		//echo $sqlAccess; exit;
		$resultadoAccess = parent::queryAccess($sqlAccess);
		$checkAccess = $resultadoAccess!==false ? parent::fetchArrayAccess($resultadoAccess) : false;
		$returnAccess = $checkAccess!==false ? ( count($checkAccess)===0 ? false : $checkAccess ) : false;				
		return $returnAccess;
	}
	
	public function update($tableAccess,$fieldAccess,$valueAccess,$attributeAccess = NULL){
		$checkAccess = Util::testArraySize( array($fieldAccess,$valueAccess) );
		if($checkAccess!==true){
			return false;
		}else{
			$fieldsAccess = NULL;
			$sizeAccess = count($fieldAccess);
			for($i=0;$i<$sizeAccess;$i++){
				$fieldsAccess[] = $fieldAccess[$i]." = '".$valueAccess[$i]."'";
			}
			$fieldsAccess = implode(",",$fieldsAccess);
		}
		$sqlAccess = "update ".$tableAccess." set ".$fieldsAccess." ".$attributeAccess;
		//echo $sqlAccess;exit;
		$resultadoAccess = parent::queryAccess($sqlAccess);
		$returnAccess = $resultadoAccess!==false ? true : false;
		return $returnAccess;
	}
	
	public function delete($tableAccess,$attributeAccess = NULL){
		$sqlAccess = "delete from ".$tableAccess." ".$attributeAccess;
		//echo $sqlAccess;exit;
		$resultadoAccess = parent::queryAccess($sqlAccess);
		$returnAccess = $resultadoAccess!==false ? true : false;
		return $returnAccess;
	}
	
}

?>