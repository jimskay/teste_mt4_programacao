<?php
/*
> insert (public) - faz uma consulta de inser��o [1. nome da tabela , 2. array com campos , 3. array com valores]
> select (public) - faz uma consulta de sele��o [1. nome da tabela , 2. array com campos , 3. atributos para filtragem] # array[assoc]
> update (public) - faz uma consulta de edi��o [1. nome da tabela , 2. array com campos , 3. array com valores , 4. atributos de condi��o]
> delete (public) - faz uma consulta de remo��o [1. nome da tabela , 2. atributos de condi��o]
*/
abstract class SQLServer extends SQLServerCommands {

	public function __construct($dbSQLServer,$userSQLServer,$passwordSQLServer) {
		parent::__construct($dbSQLServer,$userSQLServer,$passwordSQLServer);
	}
	
	public function insert($tableSQLServer,$fieldSQLServer,$valueSQLServer){		
		$checkSQLServer = Util::testArraySize( array($fieldSQLServer,$valueSQLServer) );
		if($checkSQLServer!==true){
			return false;
		}else{
			$fieldsSQLServer = NULL;
			$sizeSQLServer = count($fieldSQLServer);
			for($i=0;$i<$sizeSQLServer;$i++){				
				$fieldsSQLServer[] = $fieldSQLServer[$i];
				$valuesSQLServer[] = "'".$valueSQLServer[$i]."'";
			}
			
			$fieldsSQLServer = implode(",",$fieldsSQLServer);
			$valuesSQLServer = implode(",",$valuesSQLServer);		
			$sqlSQLServer = "insert into ".$tableSQLServer." (".$fieldsSQLServer.") values (".$valuesSQLServer.")";
			//echo $sqlSQLServer;exit;
			$resultadoSQLServer = parent::querySQLServer($sqlSQLServer);
			$returnSQLServer = $resultadoSQLServer!==false ? true : false;
			return $returnSQLServer;
		}
	}
	
	public function select($tableSQLServer,$fieldSQLServer,$attributeSQLServer = NULL){				
		$fieldsSQLServer = implode(",",$fieldSQLServer);
		$sqlSQLServer = "select ".$fieldsSQLServer." from ".$tableSQLServer." ".$attributeSQLServer;
		//echo $sqlSQLServer;exit;
		$resultadoSQLServer = parent::querySQLServer($sqlSQLServer);
		$checkSQLServer = $resultadoSQLServer!==false ? parent::fetchArraySQLServer($resultadoSQLServer) : false;
		$returnSQLServer = $checkSQLServer!==false ? ( count($checkSQLServer)===0 ? false : $checkSQLServer ) : false;				
		return $returnSQLServer;
	}
	
	public function update($tableSQLServer,$fieldSQLServer,$valueSQLServer,$attributeSQLServer = NULL){
		$checkSQLServer = Util::testArraySize( array($fieldSQLServer,$valueSQLServer) );
		if($checkSQLServer!==true){
			return false;
		}else{
			$fieldsSQLServer = NULL;
			$sizeSQLServer = count($fieldSQLServer);
			for($i=0;$i<$sizeSQLServer;$i++){
				$fieldsSQLServer[] = $fieldSQLServer[$i]." = '".$valueSQLServer[$i]."'";
			}
			$fieldsSQLServer = implode(",",$fieldsSQLServer);
		}
		$sqlSQLServer = "update ".$tableSQLServer." set ".$fieldsSQLServer." ".$attributeSQLServer;
		//echo $sqlSQLServer;exit;
		$resultadoSQLServer = parent::querySQLServer($sqlSQLServer);
		$returnSQLServer = $resultadoSQLServer!==false ? true : false;
		return $returnSQLServer;
	}
	
	public function delete($tableSQLServer,$attributeSQLServer = NULL){
		$sqlSQLServer = "delete from ".$tableSQLServer." ".$attributeSQLServer;
		//echo $sqlSQLServer;exit;
		$resultadoSQLServer = parent::querySQLServer($sqlSQLServer);
		$returnSQLServer = $resultadoSQLServer!==false ? true : false;
		return $returnSQLServer;
	}
	
}

?>