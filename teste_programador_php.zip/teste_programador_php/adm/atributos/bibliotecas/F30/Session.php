<?php
/***************************** CLASS SESSION *****************************/
/*
set > cria uma sess�o
remove > remove uma sess�o
get > resgata uma sess�o
getAndDestroy > resgata uma sessao e logo em seguida a remove
clearAll > remove todas sess�es criadas
*/
class Session {
	
	function __construct(){
		session_write_close();
		session_start();
	}
	
	public function set($name,$value){
		$_SESSION[$name] = $value;
	}
	
	public function remove($name){
		//$return = isset($_SESSION[$name]) ? ( session_unregister($name) ? true : false ) : true; // PHP 4
		unset($_SESSION[$name]); //PHP 5.0
		return $return=true;
	}
	
	public function get($name){
		$return = isset($_SESSION[$name]) ? $_SESSION[$name] : false;
		return $return;
	}
	
	public function getAndDestroy($name){
		$return = isset($_SESSION[$name]) ? $_SESSION[$name] : false;
		self::remove($name);
		return $return;
	}
	
	public function clearAll(){
		self::__construct();
		session_unset();
	}
	
	public function exists($key) {
		return isset($_SESSION[$key]) ? true : false;
	}
	
	public function checkSession($key,$value){
		if( $this->exists($key) ){
			if($_SESSION[$key]===$value){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
}

?>