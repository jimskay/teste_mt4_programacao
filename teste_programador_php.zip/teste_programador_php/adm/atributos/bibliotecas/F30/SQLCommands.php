<?php

/*
  > query (public) - executa uma query [1. SQL] # retorna a query consultada
  > numRow (public) - retorna a quantidade de itens de uma consulta [1. SQL] # INT
  > existValue (public) - verifica se um valor existe em uma tabela # [1. nome da tabela , 2. nome do campo , 3. valor , 4. outra filtragem] false: n�o | true: sim
  > fetchArray (private) - retorna um array de uma consulta [1. resultado da consulta , 2. 0=assoc | 1=row] # array[?][assoc]
  > listFields (public) - lista todas as colunas relativas a uma tabela [1. nome da tabela] # array[?][0]
  > randomizar (private) - randomiza uma string para cria��o de um password [1. quantidade de caracteres a retornar]
  > encriptar (public) - encripta uma string [1. stringLogin , 2. stringSenha , tamanho]
  > desencriptar (public) - desencripta uma string [1. stringSenha , stringLogin , tamanho]
  > specialSelect (public) - executa uma query de sele��o livre [1. query]
  > randomStr (public) - gera uma string com um determinado tamanho passado, sendo sa�da padr�o de 10 caracteres [1. quantidade de caractere a retornar] # string randomica
 */

abstract class SQLCommands {

    public $conexao;
    private $db;
    private $dbName;

    public function __construct($host, $user, $password, $db) {
        $this->conexao = mysqli_connect($host, $user, $password) ? mysqli_connect($host, $user, $password) : false;
        $this->dbName = $db;
        $this->db = mysqli_select_db($this->conexao, $this->dbName) ? true : false;
    }

    public function __get($var) {
        switch ($var) {
            case 'Db' : return $this->db;
                break;
            case 'DbName' : return $this->dbName;
                break;
        }
    }

    protected function query($sql) {

        $query = mysqli_query($this->conexao, $sql);
        if ($query) {
            return $query;
        } else {
            return false;
        }
    }

    protected function numRow($query) {
        $resultado = self::query($query);
        $return = $resultado !== false ? mysqli_num_rows($resultado) : false;
        return $return;
    }

    public function listTables() {
        if ($this->db === true) {
            $tables = "show tables from " . ($this->dbName);
            $resultado = $this->query($tables);
            $return = $resultado !== false ? $this->fetchArray($resultado, 1) : false;
            return $return;
        } else {
            return false;
        }
    }

    protected function existValue($table, $field, $value, $otherType = NULL) {
        $attribute = "where " . $field . " = '" . $value . "'";
        $attribute.= $otherType !== NULL ? "and " . $otherType : NULL;
        $resultado = self::select($table, array($field), $attribute);
        $return = $resultado === false ? false : true;
        return $return;
    }

    protected function fetchArray($result, $type = 0) {
        $return = array();
        if ($type == 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $return[] = $row;
            }
        } else {
            while ($row = mysqli_fetch_row($result)) {
                $return[] = $row;
            }
        }

        //echo var_dump($return);exit;


        return $return;
    }

    public function listFields($table) {
        $fields = "show columns from " . $table;
        $resultado = $this->query($fields);
        $return = $resultado !== false ? $this->fetchArray($resultado, 1) : false;        
        $return = $return !== 0 ? $return : false;
        return $return;
    }

    private function randomizar($iv_len) {
        $iv = '';
        while ($iv_len-- > 0) {
            $iv .= chr(mt_rand() & 0xff);
        }
        return $iv;
    }

    public function encriptar($texto, $senha, $iv_len = 16) {
        $texto .= "\x13";
        $n = strlen($texto);
        if ($n % 16)
            $texto .= str_repeat("\0", 16 - ($n % 16));
        $i = 0;
        $Enc_Texto = self::randomizar($iv_len);
        $iv = substr($senha ^ $Enc_Texto, 0, 512);
        while ($i < $n) {
            $Bloco = substr($texto, $i, 16) ^ pack('H*', md5($iv));
            $Enc_Texto .= $Bloco;
            $iv = substr($Bloco . $iv, 0, 512) ^ $senha;
            $i += 16;
        }
        return base64_encode($Enc_Texto);
    }

    public function desencriptar($Enc_Texto, $senha, $iv_len = 16) {
        $Enc_Texto = base64_decode($Enc_Texto);
        $n = strlen($Enc_Texto);
        $i = $iv_len;
        $texto = '';
        $iv = substr($senha ^ substr($Enc_Texto, 0, $iv_len), 0, 512);
        while ($i < $n) {
            $Bloco = substr($Enc_Texto, $i, 16);
            $texto .= $Bloco ^ pack('H*', md5($iv));
            $iv = substr($Bloco . $iv, 0, 512) ^ $senha;
            $i += 16;
        }

        if ($texto == "")
            return $senha;
        else
            return preg_replace('/\\x13\\x00*$/', '', $texto);
    }

    public function specialSelect($query) {
        $sql = $query;
        //echo $sql;exit;
        $resultado = self::query($sql);
        $check = $resultado !== false ? @self::fetchArray($resultado) : false;
        $return = $check !== false ? ( count($check) === 0 ? false : $check ) : false;
        return $return;
    }

    public function randomStr($return = 10) {
        $caracteres = "abc123def4gh5ij6kmn7pqr8stu9vwx0yz";
        srand((double) microtime() * 1000000);
        for ($i = 0; $i < $return; $i++) {
            $senha .= $caracteres[rand() % strlen($caracteres)];
        }
        return $senha;
    }

    public function nextValue($field, $table, $where = NULL) {
        $nextValue = self::specialSelect('SELECT max(' . $field . ') as max FROM ' . $table . ' ' . $where);
        $nextValuef = $nextValue[0]['max'] + 1;
        return $nextValuef;
    }

    public function __destruct() {
        mysqli_close($this->conexao);
    }

}

?>