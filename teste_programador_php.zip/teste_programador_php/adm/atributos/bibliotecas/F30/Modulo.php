<?php
/***************************** CLASS MODULO *****************************/
/*
OBS.: NESTA CLASSE APENAS CONTER� O NOME COM RESPECTIVAS STRINGS PARA LISTAGEM NOS SISTEMA
*/
class Modulo {
	
	private $campos;
	
	public function __construct(){
		
		$this->campos = array('usuario','cargo','evento','noticia','tipoNoticia','galeriaFoto','categoria','subCategoria','produto','tarefa','newsLetter','historico','agenda','campanha','contato','imovel','tipoImovel','cliente', 'acessoCliente', 'sala', 'recado', 'agendamentoSala');
		
	}
	
	public function get(){
		return $this->campos;
	}
	
}

?>