<?php
/***************************** ABSTRACT CLASS UTIL *****************************/
/*
	*.STATIC
> description - retorna uma quantidade determinada de palavras a partir de um conteudo passado [1. conteudo , 2. tamanha de palavras] # conteudo formatado
> filterPagination - formul�rio de filtragem para uma pagina��o [1. a��o , 2. habilita campo de limite por pagina , 3. habilita campo de ir para pagina , 4. habilita campo de ordem de uma listagem , 5. quantidade de p�ginas a mostrar] # c�digo HTML a ser inserido na p�gina
> pagination - retorna uma pagina��o para ser inserida em um HTML [1. total , 2. limite por pagina , 3. pagina atual , 4. link para as paginas , 5. n�mero de p�ginas para aparecer] # c�digo HTML a ser inserido na p�gina
> partText - retorna uma parte de um texto a partir do ponto 0 (zero) [1. conteudo , 2. tamanho a ser retornado] # retorna conteudo formatado
> redirect - faz um redirecionamento a partir de uma URL [1. url de destino]
> removeNullArray - remove valores nulos em um array [1. array] # retorna o pr�prio array validado
> testArraySize - verifica se um grupo de arrays passados por um array possuem um mesmo n�mero de elementos [1. array com arrays]
> nextValue - retorna o valor m�ximo do campo na tabela informada + 1 [1. valor maximo+1]
*/
abstract class Util{
	
	static function description($text,$size = NULL){
		$words = explode(" ",$text);
		$total = count($words);
		$size = $size!==NULL ? ( $size>$total ? $total : $size ) : $total;
		$new = array();
		for($i=0;$i<$size;$i++){
			$new[] = $words[$i];
		}
		$return = implode(" ",$new);
		return $return;
	}
	
	static function filterPagination($action,$limit,$page,$order,$show){
		$return ='<form action="'.$action.'" method="get" class="paginationForm">';
		$return.='<div>';
		if($limit!=NULL){
			$return.='<label for="limit" title="Qtd./P&aacute;g.">Qtd./P&aacute;g.:</label> ';
			$return.='<input type="text" name="limit" id="limit" maxlength="2" size="1" value="'.$limit.'" /> ';
		}
		if($page!=NULL){
			$return.='<label for="page" title="P&aacute;g.">P&aacute;g.:</label> ';
			$return.='<input type="text" name="page" id="page" maxlength="10" size="1" value="'.$page.'" /> ';
		}
		if($order!=NULL){
			$return.='<label for="order" title="Ordem">Ordem:</label> ';
			$return.='<select name="order" id="order"> ';
			$return.='<option value="asc" '.($order=="asc" ? 'selected="selected"' : '').'>A - Z</option> ';
			$return.='<option value="desc" '.($order=="desc" ? 'selected="selected"' : '').'>Z - A</option> ';
			$return.='</select> ';
		}
		if($show!=NULL){
			$return.='<label for="show" title="Mostrar P&aacute;gs.">Mostrar P&aacute;gs.:</label> ';
			$return.='<input type="text" name="show" id="show" maxlength="10" size="1" value="'.$show.'" /> ';
		}
		$return.='<input type="submit" value="&gt;" title="&gt;" />';
		$return.='</div>';
		$return.='</form>';
		return $return;
	}
	
	static function pagination($total,$max,$current,$link,$size = 0){
		//	GENERATING PAGES
		//	CONVERT FOR INTEGER
		$total 	 = intval($total);
		$max 	 = intval($max);
		$current = intval($current);
		$size 	 = intval($size);
		$paginas = explode('/',$_SERVER['REQUEST_URI']);
		$qtdP    = count($paginas);		

		$linkAux = '';
		for($i=0; $i<$qtdP-1; $i++) {
			
			if ($i ==0) {
				$linkAux .=  $paginas[$i];
			} else {
				$linkAux .=  '/'.$paginas[$i];			
			}

		}

		$link = 'http://'.$_SERVER['HTTP_HOST'].$linkAux;		

		$pages = ceil($total/$max);
		$preview = $current===1 ? "" : " <a href=\"".$link."/1\" title=\"Primeira\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">Primeira</a> <a href=\"".$link.($current-1)."\" title=\"Anterior\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">&lt; Anterior</a> ";
		$next = $current==$pages ? "" : " <a href=\"".$link."/".($current+1)."\" title=\"Pr&oacute;ximo\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">Pr&oacute;xima &gt;</a> <a href=\"".$link.$pages."\" title=\"&Uacute;ltima\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">&nbsp;&nbsp;&Uacute;ltima&nbsp;&nbsp;</a> ";
		if($size!==0){
			$limit = $size>$pages ? $pages : $size;
			$middle = floor($size/2);
			$l = $current-$limit;
			$min = $l<0 ? 0 : $l;
			$min = $min + $limit > $pages ? $pages - $size : $min;
			$pageNumber = array();
			for($i=0;$i<$limit;$i++){
				$min++;
				$pageNumber[] = $min;
			}
		}else{
			$pageNumber = NULL;
		}
		$return = "<div class=\"pagination\">";
		$return.= $preview;
		if($pageNumber!==NULL){
			for($i=0;$i<count($pageNumber);$i++){
				if($pageNumber[$i]==$current){
					$return.='<a class="selected ui-corner-all" title="P&aacute;gina '.$pageNumber[$i].'" style="border:1px solid #CCC;padding:5px;background-color:#F0F0F0">'.$pageNumber[$i].'</a>';
				}else{
					$return.='<a class="selected ui-corner-all" href="'.$link."/".$pageNumber[$i].'" title="P&aacute;gina '.$pageNumber[$i].'" style="border:1px solid #CCC;padding:5px;">'.$pageNumber[$i].'</a>';
				}
			}
		}
		$return.=$next;
		$return.= "</div>";
		return $return;
	}

	static function paginationBusca($total,$max,$current,$link,$size = 0){
		//	GENERATING PAGES
		//	CONVERT FOR INTEGER
		$total 	 = intval($total);
		$max 	 = intval($max);
		$current = intval($current);
		$size 	 = intval($size);
		$paginas = explode('?',$_SERVER['REQUEST_URI']);
		$qtdP    = count($paginas);		

		$linkAux = '';
		for($i=0; $i<$qtdP-1; $i++) {
			
			if ($i ==0) {
				$linkAux .=  '?paginaAtual='.$paginas[$i];
			} else {
				$linkAux .=  '?paginaAtual='.$paginas[$i];			
			}

		}

		$link  = 'http://'.$_SERVER['HTTP_HOST'].$link;		
				

		$pages = ceil($total/$max);
		$preview = $current===1 ? "" : " <a href=\"".$link."&paginaAtual=1\" title=\"Primeira\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">Primeira</a> <a href=\"".$link.'&paginaAtual='.($current-1)."\" title=\"Anterior\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">&lt; Anterior</a> ";
		$next = $current==$pages ? "" : " <a href=\"".$link."&paginaAtual=".($current+1)."\" title=\"Pr&oacute;ximo\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">Pr&oacute;xima &gt;</a> <a href=\"".$link.'&paginaAtual='.$pages."\" title=\"&Uacute;ltima\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">&nbsp;&nbsp;&Uacute;ltima&nbsp;&nbsp;</a> ";
		if($size!==0){
			$limit = $size>$pages ? $pages : $size;
			$middle = floor($size/2);
			$l = $current-$limit;
			$min = $l<0 ? 0 : $l;
			$min = $min + $limit > $pages ? $pages - $size : $min;
			$pageNumber = array();
			for($i=0;$i<$limit;$i++){
				$min++;
				$pageNumber[] = $min;
			}
		}else{
			$pageNumber = NULL;
		}
		$return = "<div class=\"pagination\">";
		$return.= $preview;
		if($pageNumber!==NULL){
			for($i=0;$i<count($pageNumber);$i++){
				if($pageNumber[$i]==$current){
					$return.='<a class="selected ui-corner-all" title="P&aacute;gina '.$pageNumber[$i].'" style="border:1px solid #CCC;padding:5px;background-color:#F0F0F0">'.$pageNumber[$i].'</a>';
				}else{
					$return.='<a class="selected ui-corner-all" href="'.$link."paginaAtual=".$pageNumber[$i].'" title="P&aacute;gina '.$pageNumber[$i].'" style="border:1px solid #CCC;padding:5px;">'.$pageNumber[$i].'</a>';
				}
			}
		}
		$return.=$next;
		$return.= "</div>";
		return $return;
	}

	static function pagination_quise($total,$max,$current,$link,$size = 0){
		//	GENERATING PAGES
		//	CONVERT FOR INTEGER
		$total = intval($total);
		$max = intval($max);
		$current = intval($current);
		$size = intval($size);
		
		$pages = ceil($total/$max);
		$preview = $current===1 ? "" : " <a href=\"".$link."1\" title=\"Primeira\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">Primeira</a> <a href=\"".$link.($current-1)."\" title=\"Anterior\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">&lt; Anterior</a> ";
		$next = $current==$pages ? "" : " <a href=\"".$link.($current+1)."\" title=\"Pr&oacute;ximo\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">Pr&oacute;xima &gt;</a> <a href=\"".$link.$pages."\" title=\"&Uacute;ltima\" style=\"border:1px solid #CCC;padding:5px;\" class=\"ui-corner-all\">&nbsp;&nbsp;&Uacute;ltima&nbsp;&nbsp;</a> ";
		if($size!==0){
			$limit = $size>$pages ? $pages : $size;
			$middle = floor($size/2);
			$l = $current-$limit;
			$min = $l<0 ? 0 : $l;
			$min = $min + $limit > $pages ? $pages - $size : $min;
			$pageNumber = array();
			for($i=0;$i<$limit;$i++){
				$min++;
				$pageNumber[] = $min;
			}
		}else{
			$pageNumber = NULL;
		}
		$return = "<div class=\"pagination\">";
		$return.= $preview;
		if($pageNumber!==NULL){
			for($i=0;$i<count($pageNumber);$i++){
				if($pageNumber[$i]==$current){
					$return.='<a class="selected ui-corner-all" title="P&aacute;gina '.$pageNumber[$i].'" style="border:1px solid #CCC;padding:5px;background-color:#F0F0F0">'.$pageNumber[$i].'</a>';
				}else{
					$return.='<a class="selected ui-corner-all" href="'.$link.$pageNumber[$i].'" title="P&aacute;gina '.$pageNumber[$i].'" style="border:1px solid #CCC;padding:5px;">'.$pageNumber[$i].'</a>';
				}
			}
		}
		$return.=$next;
		$return.= "</div>";
		return $return;
	}
	
	static function partText($text,$size = 1){
		return Validation::toHTML(substr($text,0,$size));
	}
	
	static function redirect($url){
		header("Location: ".$url);
		exit;
	}
	
	static function removeNullArray($array){
		$total = count($array);
		for($i=0;$i<$total;$i++){
			if($array[$i] == NULL){
				unset($array[$i]);
			}
		}
		return $array;
	}
	
	static function testArraySize($array){
		if( count($array)==0 ){
			return false;
		}else{
			$c1 = count($array[0]);
			foreach ($array as $a){
				if($c1 != count($a) ){
					return false;
				}
			}
			return true;
		}
	}
	
	function buscaCep($cep){  
		$resultado = @file_get_contents('http://republicavirtual.com.br/web_cep.php?cep='.urlencode($cep).'&formato=query_string');  
		if(!$resultado){  
			$resultado = "&resultado=0&resultado_txt=erro+ao+buscar+cep";  
		}  
		parse_str($resultado, $retorno);   
		return $retorno;  
	}  
	
}
?>