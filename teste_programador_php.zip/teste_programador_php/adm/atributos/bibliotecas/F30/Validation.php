<?php

/* * *************************** ABSTRACT CLASS VALIDATION **************************** */
/*
 * .STATIC
  > cep - verifica se � um cep brasileiro v�lido no formato '00000-000' [1. cep]
  > checkFloat - verifica se � um valor do tipo float [1. valor]
  > checkLogin - verifica um login de usu�rio de syslogical [1. instancia Database , 2. instancia Sessao] # em caso 'false' redireciona para index.php do syslogical
  > checkMoneyFloat - verifica se � um valor monet�rio v�lido no formato '0.00' [1. valor]
  > checkPermission - verifica permissao de um usu�rio em um m�dulo do syslogical [1. string permissao , instancia Usuario] em caso 'false' redireciona para principal.php
  > checkSizeStr - verifica se a quantidade de caractere de um conte�do coincide com os valores max e min [1. string , 2. valor m�ximo , 3. valor m�nimo]
  > cpf - verifica se � um CPF v�lido [1. CPF]
  > cnpj - verifica se � um CNPJ v�lido [1. CNPJ]
  > floatToNumber - transforma um valor de ponto flutuante para um valor monet�rio '0.00 -> 0,00' (mesma fun��o de numberToMoney) [1. valor] # valor formatado
  > formatAllText - insere alguns tipos de formata��o para apresenta��o HTML [1. string] # string formatada
  > formatToSql formata um sql retirando todos os caracteres inadequados para uma consulta (query) [1. string] # string formatado
  > getIp - retorna o ip remoto atual
  > isDate - verifica se � uma data v�lida no formato 'AAAA-MM-DD' [1. data]
  > loginAdmin - verifica se um administrador esta logado [1. objeto de conex�o , 2. objeto de sess�o] # caso false redireciona o usu�rio para �rea de login
  > moneyToNumber - transforma um valor monet�rio para um valor de ponto flutuante '0,00 -> 0.00' (mesma fun��o de numberToFloat) [1. valor] # valor formatado
  > numberToFloat - transforma um valor monet�rio para um valor de ponto flutuante '0,00 -> 0.00' (mesma fun��o de moneyToNumber) [1. valor] # valor formatado
  > numberToMoney - transforma um valor de ponto flutuante para um valor monet�rio '0.00 -> 0,00' (mesma fun��o de floatToNumber) [1. valor] # valor formatado
  > partOfPhone - retorna uma parte de um telefone DDD|Telefone [1. n�mero , 2. retorna DDD TRUE|FALSE , 3. retorna telefone TRUE|FALSE]
  > phone - verifica se � um n�mero de telefone|celular [1. n�mero]
  > revDate - reverte uma data  a partir de um caractere para explodir e revertendo com um implode [1. data , 2. explode , 3. implode] # data formatada
  > sqlToDateTime - transforma um datetime SLQ (AAAA-MM-DD 00:00:00) para um datetime comum (DD/MM/AAAA 00:00:00) [1. datetime] # datetime formatado
  > stripTagsSize - retorna uma parte de string retirando todos os caracteres html|php e determina o tamanho da string a ser retornada [1. string, 2. tamanho da string a ser retornada (#)=tamanho atual da string] # string formatada
  > strPad - preenchimento de um caractere em uma string (esquerda|direita|ambos) [1. string , 2. tipo (L,R,B) , 3. tamanho, 4. caractere ] # string com preenchimento
  > toHTML - faz uma formata��o de texto para inserir no HTML (recomend�vel verificar formata��es) [1. string] # string formatada
  > toBd - faz uma formata��o de texto para inserir em um BD (recomend�vel verificar formata��es) [1. string] # string formatada
  > toLower - transforma um texto para caracteres min�sculos [1. string] # string formatada
  > toUpper - transforma um texto para caracteres mai�sculos [1. string] # string formatada
  > typeOfRow - retorna o tipo de campo de um database [1. string] # nome do campo
  > uf - verifica se � uma sigla no formato 'AA' (duas letras) [1. sigla]
  > validEmail - verifica se � um e-mail v�lido [1. e-mail]
  > validLogin - verifica se � um login v�lido [2. login]
  > validPassword - verifica se � um password v�lido [1. password]
 */

abstract class Validation {

    static function cep($value) {
        $src = '/[0-9]{5}-[0-9]{3}/';
        $check = preg_match($src, $value);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function checkFloat($float) {
        $src = '/[0-9]*\.[0-9]*/';
        $check = preg_match($src, $float);
        return $check === 1 ? true : false;
    }

    static function checkLogin(Database $db, Session $session) {
        
        $objUsuario = new Usuario($db, $session->get('sUsuario'));

        if (!$objUsuario->IdUsuario == '') {
            return $objUsuario;
        } else {
            Util::redirect(ROOT_HTTP_ADMIN.'pedido/index.php');
        }

    }

    static function checkLoginCliente(Database $db, Session $session) {
        $objAcessoCliente = new AcessoCliente($db, $session->get('sAcessoCliente'));
        if ($objAcessoCliente->CodAcessoCliente == '') {
            Util::redirect(ROOT_HTTP_ADMIN.'pedido/index.php');
        } else {
            return $objAcessoCliente;
        }
    }

    static function checkMoneyFloat($money) {
        $src = '/[0-9]*\.[0-9]{2}/';
        $check = preg_match($src, $money);
        return $check === 1 ? true : false;
    }

    static function checkPermission($str, Usuario $usuario) {
        if ($usuario->CodCargo->{$str} != '1') {
            Util::redirect(ROOT_HTTP_ADMIN . 'principal.php');
        } else {
            return NULL;
        }
    }

    static function checkSizeStr($string, $max = 1, $min = 1) {
        $size = strlen($string);
        return $size >= $min && $size <= $max ? true : false;
    }

    static function cpf($cpf) {
        $src = '/^[0-9]{3}\.[0-9]{3}\.[0-9]{3}\-[0-9]{2}$/';
        $check = preg_match($src, $cpf);
        if ($check !== 1) {
            return false;
        }
        //	REMOVE OTHERS CHARACTERS
        $cpf = str_replace(".", "", $cpf);
        $cpf = str_replace("-", "", $cpf);

        //	CREATING ARRAY WITH DIGITS
        $array = array();
        for ($i = 0; $i < strlen($cpf); $i++) {
            $array[$i] = substr($cpf, $i, 1);
        }

        for ($i = 1; $i <= 9; $i++) {
            $error = "";
            for ($j = 0; $j < 11; $j++) {
                $error+=$i;
            }
            if ($error === $cpf) {
                return false;
            }
        }

        //	GENERATING THE FIRST DIGIT
        $add = 0;
        for ($i = 0; $i < 9; $i++) {
            $add += $array[$i] * (10 - $i);
        }
        $rest = $add % 11;
        if ($rest < 2) {
            $firstDigit = 0;
        } else {
            $firstDigit = 11 - $rest;
        }

        //	CHECK FIRST DIGIT
        if ($firstDigit != $array[9]) {
            return false;
        }

        //	GENERATING THE SECOND DIGIT
        $add = 0;
        for ($i = 0; $i < 10; $i++) {
            $add += $array[$i] * (11 - $i);
        }
        $rest = $add % 11;
        if ($rest < 2) {
            $secondDigit = 0;
        } else {
            $secondDigit = 11 - $rest;
        }

        //	CHECK SECOND DIGIT
        if ($secondDigit != $array[10]) {
            return false;
        }

        return true;
    }

    static function cnpj($cnpj) {
        $src = '/^([0-9]){2,3}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$/';
        $src = preg_match($src, $cnpj);
        if ($src !== 1) {
            return false;
        }
        if (strlen($cnpj) == 18) {
            $chars = array(6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2);
        } else {
            $chars = array(7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2);
        }
        //	CRIANDO UM CNPJ COM APENAS N�MEROS
        $rep = '/\.|\/|\-/';
        $int = preg_replace($rep, '', $cnpj);
        //	EXECUTANDO A OPERA��O DOS D�GITOS
        //	GERANDO 1� DIGITO
        $soma = 0;
        for ($i = 0; $i < strlen($int) - 2; $i++) {
            $soma+= substr($int, $i, 1) * $chars[$i + 1];
        }
        $rest = $soma % 11;
        $firstDigit = $rest < 2 ? 0 : (11 - $rest);

        //	GERANDO 2� DIGITO
        $soma = 0;
        for ($i = 0; $i < strlen($int) - 1; $i++) {
            $soma+= substr($int, $i, 1) * $chars[$i];
        }
        $rest = $soma % 11;
        $secondDigit = $rest < 2 ? 0 : (11 - $rest);
        //	VERIFICANDO ULTIMOS DIGITOS
        $pD = substr($int, strlen($int) - 2, 1);
        $uD = substr($int, strlen($int) - 1, 1);
        if ($firstDigit != $pD) {
            return false;
        } else if ($secondDigit != $uD) {
            return false;
        } else {
            return true;
        }
    }

    static function floatToNumber($value) {
        $src = '/^\d*[\.]?\d*?$/';
        $check = preg_match($src, $value);
        $return = $check === 1 ? str_replace(".", ",", $value) : false;
        return $return;
    }

    static function formatAllText($str) {
        $return = self::toHTML($str);
        $return = str_replace('[]', '<span>', $return);
        $return = str_replace('[/]', '</span>', $return);
        return $return;
    }

    static function formatToSql($str) {
        return mysql_escape_string($str);
    }

    static function getIp() {
        return $_SERVER['REMOTE_ADDR'];
    }

    static function isDate($date) {
        $src = '/^(1+9|2[01])[0-9]{2}\-((0[13578]|1[02])\-(0[0-9]|[12][0-9]|3[01])|(0[469]|1[1])\-(0[0-9]|[12][0-9]|3+0)|((0+2)\-(0[0-9]|[12][0-8])))$/';
        $check = preg_match($src, $date);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function moneyToNumber($value) {
        $value = str_replace(".", "", $value);
        $value = str_replace(",", ".", $value);
        $src = '/^\d*\.\d*?$/';
        $check = preg_match($src, $value);
        $return = $check === 1 ? $value : false;
        return $return;
    }

    static function numberToFloat($value) {
        $src = '/^\d*[\,]?\d*?$/';
        $check = preg_match($src, $value);
        $return = $check === 1 ? str_replace(",", ".", $value) : false;
        return $return;
    }

    static function numberToMoney($value) {
        $src = '/^\d*[\.]?\d*?$/';
        $check = preg_match($src, $value);
        $return = $check === 1 ? number_format($value, 2, ",", ".") : false;
        return $return;
    }

    static function partOfPhone($value, $ddd = true, $phone = false) {
        if ($value == '') {
            return NULL;
        }
        $array = explode(' ', $value);
        if ($ddd === true && $phone === false) {
            return $array[0];
        } else if ($ddd === false && $phone === true) {
            return $array[1];
        } else {
            return $array[0] . ' ' . $array[1];
        }
    }

    static function phone($phone) {
        $src = '/^[0-9]{2} [0-9]{8}$/';
        $check = preg_match($src, $phone);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function revDate($value, $explode = '-', $implode = '/') {
        $date = explode($explode, $value);
        $date = array_reverse($date);
        return implode($implode, $date);
    }

    static function sqlToDateTime($value) {
        $array = explode(" ", $value);
        $date = explode("-", $array[0]);
        $date = array_reverse($date);
        $date = implode("/", $date);
        $array[0] = $date;
        $array = implode(" ", $array);
        return $array;
    }

    static function stripTagsSize($str, $size) {
        $size = $size == '#' ? strlen($str) : $size;
        $return = strip_tags($str);
        $new = html_entity_decode($return);
        return htmlentities(substr($new, 0, $size));
    }

    static function stripTagsSizeHtml($str, $size) {
        return substr($str, 0, $size);
    }

    static function strPad($str, $type, $size, $chr) {
        switch ($type) {
            case 'L':
                $type = 'STR_PAD_LEFT';
                break;
            case 'R':
                $type = 'STR_PAD_RIGHT';
                break;
            case 'B':
                $type = 'STR_PAD_BOTH';
                break;
        }
        return str_pad($str, $size, $chr, $type);
    }

    static function toHTML($value) {
        //return htmlentities(utf8_decode($value));
        //return nl2br(htmlentities($value));		
        return $value;
    }

    static function toBd($value) {
        //return htmlspecialchars(utf8_encode($value));
        return $value;
    }

    static function toLower($str) {
        return strtolower($str);
    }

    static function toUpper($str) {
        return strtoupper($str);
    }

    static function typeOfRow($str) {
        $pos1 = strpos($str, '(');
        if ($pos1 == 0) {
            return $str;
        } else {
            return substr($str, 0, $pos1);
        }
        //return $str;
    }

    static function uf($value) {
        $src = '/^[A-Z]{2}$/';
        $check = preg_match($src, $value);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function validEmail($email) {
        $src = '/^[\.,\w]*?\w*@\w*\.\w*[\.,\w]*?$/';
        $check = preg_match($src, $email);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function validLogin($login) {
        $valid = '/^\w{6,20}$/';
        $check = preg_match($valid, $login);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function validPassword($password) {
        $valid = '/^\w{6,20}$/';
        $check = preg_match($valid, $password);
        $return = $check === 1 ? true : false;
        return $return;
    }

    static function geraCupom(Database $db) {
        $objCupom = new Cupomdesconto($db);
        $cupom = "pwd" . mt_rand();
        $cupomexiste = $objCupom->select('where identificadorCupomDesconto = "' . $cupom . '"');
        if ($cupomexiste == false) {
            return $cupom;
        } else {
            $cupomnovo = "pwd" . mt_rand();
            $cupomexistenovo = $objCupom->select('where identificadorCupomDesconto = "' . $cupomnovo . '"');
            if ($cupomexiste == false) {
                return $cupomnovo;
            } else {
                return "Insira um n�mero aleat�rio para o identificador do cupom de desconto.";
            }
        }
    }

}

?>