<?php
/*
> querySQLServer (public) - executa uma query [1. SQL] # retorna a query consultada
> fetchArraySQLServer (private) - retorna um array de uma consulta [1. resultado da consulta , 2. 0=assoc | 1=row] # array[?][assoc]
> listFieldsSQLServer (public) - lista todas as colunas relativas a uma tabela [1. nome da tabela] # array[?][0]
> specialSelectSQLServer (public) - executa uma query de sele��o livre [1. query]
*/
abstract class SQLServerCommands {
	
	private $conexaoSQLServer;
	private $dbSQLServer;
	private $dbNameSQLServer;
	
	public function __construct($dbSQLServer,$userSQLServer,$passwordSQLServer){
		
		try{	
			if(!odbc_connect($dbSQLServer, $userSQLServer, $passwordSQLServer)){ 
				throw  new Exception("Erro ao estabelecer conex�o!"); 
			}else{
				$this->conexaoSQLServer = odbc_connect($dbSQLServer, $userSQLServer, $passwordSQLServer);	
				$this->dbNameSQLServer = $dbSQLServer;			
			}
		}catch(Exception $e){ 
			echo "Erro ao estabelecer conex�o ODBC no servidor!"; 
		}
		
	}
	
	
	public function __get($var){
		switch($var){
			case 'DbName'	:	return $this->dbNameSQLServer;	break;
		}
	}
	
	protected function querySQLServer($sqlServer){		
		$querySQLServer = odbc_exec($this->conexaoSQLServer, $sqlServer);				
		if($querySQLServer){
			return $querySQLServer;
		}else{
			return false;
		}
	}
	
	protected function fetchArraySQLServer($resultadoSQLServer,$typeSQLServer = 0){

		$returnSQLServer = array();			
		
		if($typeSQLServer==0){
			while( $rowSQLServer = odbc_fetch_array($resultadoSQLServer) ){
				$returnSQLServer[] = $rowSQLServer;
			}
		}else{
			
			while(odbc_fetch_row($resultadoSQLServer)){
			  $returnSQLServer[] = odbc_result($resultadoSQLServer, 1);
			}
						
		}

		return $returnSQLServer;
	}	
	
	public function listFieldsSQLServer($tableSQLServer){
		$fieldsSQLServer = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE (TABLE_NAME = '".$tableSQLServer."') ";
		$resultadoSQLServer = $this->querySQLServer($fieldsSQLServer);
		$returnSQLServer = $resultadoSQLServer!==false ? $this->fetchArraySQLServer($resultadoSQLServer,1) : false;
		$returnSQLServer = $returnSQLServer!==0 ? $returnSQLServer : false;
		return $returnSQLServer;
	}


	public function specialQuerySQLServer($querySQLServer){
		$resultadoSQLServer = self::querySQLServer($querySQLServer);		
		$checkSQLServer = $resultadoSQLServer!==false ? self::fetchArraySQLServer($resultadoSQLServer) : false;
		//$checkSQLServer = $resultadoSQLServer!==false ? $resultadoSQLServer : false;
		$returnSQLServer = $checkSQLServer!==false ? ( count($checkSQLServer)===0 ? false : $checkSQLServer ) : false;
		return $returnSQLServer;
	}

	
	public function __destruct(){
		odbc_close($this->conexaoSQLServer);
	}
	
}

?>