<?php
/***************************** ABSTRACT CLASS FILESYSTEM *****************************/
/*
> deleteFile (public|static) - remove um arquivo ou diret�rio [1. URL]
> copyFile (protected) - faz uma c�pia a partir de um arquivo [1. arquivo a ser copiado , 2. diret�rio de destino , 3. novo nome para o arquivo]
> moveUploaded (protected) - move um arquivo recebido por upload [1. arquivo a ser copiado , 2. novo endere�amento de arquivo]
> fileExists (public|static) - verifica se um arquivo ou diret�rio existe [1. endere�o de arquivo|diret�rio]
> makeDir (protected) - cria um novo diret�rio [1. endere�o de destino para cria��o do diret�rio]
> removeDir (protected) - remove um diret�rio [1. endere�o do diret�rio a ser removido]
> isDir (protected) - verifica se o endere�o passado � um diret�rio v�lido [1. endere�o a ser verificado]
> freeSpace (public|static) - retorna o espa�o (padr�o em bytes) dispon�vel no diret�rio [1. endere�o a ser verificado , 2. forma de retorno] # valor
> totalSpace (public|static) - retorna o espa�o (padr�o em bytes) ocupado no diret�rio [1. endere�o a ser verificado , 2. forma de retorno] # valor
> lastAccess (public|static) - retorna o ultimo acesso ao arquivo [1. endere�o do arquivo] # data
> lastModify (public|static) - retorna ultima modifica��o do arquivo [1. endere�o do arquivo] # data
> sizeFile (public|static) - retorna o tamanho (padr�o em bytes) de um arquivo [1. endere�o do arquivo , 2. forma de retorno] # valor
> isExe (public|static) - verifica se um arquivo � execut�vel [1. endere�o do arquivo]
> httpPost (public|static) - verifica se o arquivo foi enviado por meio de um upload via HTTP [1. endere�o do arquivo]
> byteLevel (protected) - transforma um valor multiplicado|dividido por 1024 [1. valor , forma de calculo (*|/)] # valor
> listAll (public|static) - lista diret�rios e arquivos contidos em um diret�rio [1. endere�o do diret�rio] # imprime lista de arquivos e diret�rios
> positionType (protected) - retorna o n�vel de posi��o de uma medida a partir de bytes (posi��o 0) [1. tipo] # inteiro com a posi��o
> typeFile (public|static) - retorna o tipo de um arquivo [1. string] # tipo do arquivo
> isValidImg (public|static) - verifica se a imagem � v�lida para trabalhar no programa atual [1. string]
*/
abstract class FileSystem{
	
	public static function deleteFile($url){
		$check = self::fileExists($url);
		$return = $check===true ? ( unlink($url) ? true : false ) : false;
	}
	
	protected function copyFile($file,$path,$name){
		$check[] = self::fileExists($file);
		$check[] = self::fileExists($path);
		$return = $check[0]===true && $check[1]===true ? ( copy($file,$path.$name) ? true : false ) : false;
		return $return;
	}
	
	protected function moveUploaded($path,$newPath){
		$return = move_uploaded_file($path,$newPath) ? true : false;
		return $return;
	}
	
	public static function fileExists($path){
		$return = file_exists($path) ? true : false;
		return $return;
	}
	
	protected function makeDir($path){
		echo $path;
		$check = self::fileExists($path);
		$return = $check===false ? ( mkdir($path) ? true : false ) : false;
		return $return;
	}
	
	protected function removeDir($path){
		$check = self::fileExists($path);
		$return = $check===true ? ( rmdir($path) ? true : false ) : false;
		return $return;
	}
	
	protected function isDir($path){
		$check = self::fileExists($path);
		$return = $check===true ? ( is_dir($path) ? true : false ) : false;
		return $return;
	}
	
	public static function freeSpace($path, $typeOfReturn = 'B'){
		$check = self::fileExists($path);
		$check = $check===true ? self::isDir($path) : false;
		$return = $check===true ? diskfreespace($path) : false;
		for($i=0;$i<self::positionType($typeOfReturn);$i++){
			$return = self::byteLevel($return,$type = 1);
		}
		return $return;
	}
	
	public static function totalSpace($path, $typeOfReturn = 'B'){
		$check = self::fileExists($path);
		$check = $check===true ? self::isDir($path) : false;
		$return = $check===true ? disk_total_space($path) : false;
		return $return;
		for($i=0;$i<self::positionType($typeOfReturn);$i++){
			$return = self::byteLevel($return,$type = 1);
		}
		return $return;
	}
	
	public static function lastAccess($path){
		$check = self::fileExists($path);
		$return = $check===true ? fileatime($path) : false;
		$return = $return!==false ? Calendar::stampToDate($return,0) : false;
		return $return;
	}
	
	public static function lastModify($path){
		$check = self::fileExists($path);
		$return = $check===true ? filemtime($path) : false;
		$return = $return!==false ? Calendar::stampToDate($return,0) : false;
		return $return;
	}
	
	public static function sizeFile($path, $typeOfReturn = 'B'){
		$check = self::fileExists($path);
		$return = $check===true ? filesize($path) : false;
		for($i=0;$i<self::positionType($typeOfReturn);$i++){
			$return = self::byteLevel($return,$type = 1);
		}
		return $return;
	}
	
	public static function isExe($path){
		$check = self::fileExists($path);
		$return = $check===true ? is_executable($path) : false;
		return $return;
	}
	
	public static function httpPost($path){
		$check = self::fileExists($path);
		$return = $check===true ? is_uploaded_file($path) : false;
		return $return;
	}
	
	protected function byteLevel($value,$type = 1){
		$return = $type===1 ? $value/1024 : $value*1024;
		return $return;
	}
	
	public static function listAll($diretorio){
		$return = glob($diretorio);
		if($return!==false){
			foreach($return as $f){
				$check = self::isDir($f);
				if($check===true){
					$id = str_replace('/','_',$f);
					$class = 'dir';
					$divOpen = '<div id="'.$id.'" class="hide">';
					$divClose = '</div>';
					$aOpen = '<a href="javascript:openCloseDir(\''.$id.'\');">';
					$aClose = '</a>';
					$size = ' <span>('.self::lastModify($f).')</span>';
				}else{
					$delimiter = strrpos($f,".")+1;
					$class = strtolower(substr($f,$delimiter)).' normal';
					$divOpen = NULL;
					$divClose = NULL;
					$aOpen = '<a href="'.$f.'">';
					$aClose = '</a>';
					$size = ' <span>('.ceil(self::sizeFile($f,'KB')).' KB)</span>';
				}
				echo '<blockquote class="'.$class.'">'.$aOpen.$f.$aClose.$size.$divOpen;
				if($check===true){
					self::listAll($f.'/*');
				}
				echo $divClose.'</blockquote>';
			}
		}else{
			echo 'N&atilde;o h&aacute; arquivos ou pastas.';
		}
	}
	
	protected function positionType($type){
		switch($type){
			case 'B'		: return 0;			break;
			case 'KB'		: return 1;			break;
			case 'MB'		: return 2;			break;
			case 'GB'		: return 3;			break;
			default			: return 0;			break;
		}
	}
	
	public static function typeFile($str){
		$type = strrchr($str,'.');
		return str_replace('.','',$type);
	}
	
	public static function isValidImg($str){
		$type = Validation::toLower(self::typeFile($str));
		switch($type){
			case 'jpg'			:
			case 'gif'			:
			case 'png'			:
			case 'JPG'			:
			case 'GIF'			:
			case 'PNG'			:
				$return = true;
				break;
			default				:
				$return = 'Imagem inv�lida, apenas: *.jpg, *.gif ou *.png';
				break;
		}
		return $return;
	}
}
?>