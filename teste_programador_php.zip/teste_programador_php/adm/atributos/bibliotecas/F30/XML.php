<?php
/***************************** CLASS XML *****************************/
/*
> getRoot - retorna a estrutura root com todos os n�s j� vinculados # estrutura ROOT
> getXml - mostra a estrutura xml no browser # estrutura XML
> newElement - cria um novo elemento e o retorna [1. nome do elemento , 2. valor do elemento] # elemento criado
> removeAttribute - remove um atributo de um elemento [1. elemento , 2. nome do atributo] # pr�prio elemento
> removeElement - remove um elemento do root [1. nome do elemento]
> setAttribute - insere um atributo a um elemento [1. elemento que receber� o atributo , 2. nome do atributo , 3. valor do atributo] # pr�prio elemento
> setElement - atribui o elemento ao root [1. elemento]
*/
class XML {
	
	private $object;
	private $root;
	
	function __construct($root = 'root'){
		$this->object = new DOMDocument('1.0');
		$this->root = $this->object->createElement($root);
	}
	
	function __toString(){
		return Validation::textToHTML($this->name);
	}
	
	public function getRoot(){
		return $this->root;
	}
	
	public function getXml(){
		$this->object->appendChild($this->root);
		header('Content-type: application/xml');
		return $this->object->saveXML();
	}
	
	public function newElement($name = "child",$value = NULL){
		$element = $this->object->createElement($name);
		if($value!==NULL){
			$text = $this->object->createTextNode($value);
			$element->appendChild($text);
		}
		return $element;
	}
	
	public function removeAttribute($element,$name = "att"){
		$element->removeAttribute($name);
		return $element;
	}
	
	public function removeElement($element = "child"){
		$this->root->removeElement($element);
	}
	
	public function setAttribute($element,$name = "att",$value = NULL){
		$element->setAttribute($name,$value);
		return $element;
	}
	
	public function setElement($element = "child"){
		if($append===NULL){
			$this->root->appendChild($element);
			return NULL;
		}else{
			$append->appendChild($element);
			return $append;
		}
	}
}
?>