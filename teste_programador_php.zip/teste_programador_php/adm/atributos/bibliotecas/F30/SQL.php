<?php

/*
  > insert (public) - faz uma consulta de inser��o [1. nome da tabela , 2. array com campos , 3. array com valores]
  > select (public) - faz uma consulta de sele��o [1. nome da tabela , 2. array com campos , 3. atributos para filtragem] # array[assoc]
  > update (public) - faz uma consulta de edi��o [1. nome da tabela , 2. array com campos , 3. array com valores , 4. atributos de condi��o]
  > delete (public) - faz uma consulta de remo��o [1. nome da tabela , 2. atributos de condi��o]
 */

abstract class SQL extends SQLCommands {

    public function __construct($host, $user, $password, $db) {
        parent::__construct($host, $user, $password, $db);
    }

    public function insert($table, $field, $value) {
        $check = Util::testArraySize(array($field, $value));
        if ($check !== true) {
            return false;
        } else {
            $fields = NULL;
            $size = count($field);
            for ($i = 0; $i < $size; $i++) {
                $fields[] = $field[$i] . " = '" . $value[$i] . "'";
            }
            $fields = implode(",", $fields);
            $sql = "insert into " . $table . " set " . $fields;
            /*
            echo $sql;
            die;
            */
            $resultado = parent::query($sql);
            $return = $resultado !== false ? true : false;
            return $return;
        }
    }

    public function select($table, $field, $attribute = NULL) {
        $fields = implode(",", $field);        
        $sql = "select " . $fields . " from " . $table . " " . $attribute;
        
        //echo $sql;die;
        $resultado = parent::query($sql);
        $check = $resultado !== false ? parent::fetchArray($resultado) : false;
        $return = $check !== false ? ( count($check) === 0 ? false : $check ) : false;
        return $return;
    }

    public function selectDistinct($table, $field, $attribute = NULL) {
        $fields = implode(",", $field);
        $sql = "select distinct " . $fields . " from " . $table . " " . $attribute;
        //echo $sql;exit;
        $resultado = parent::query($sql);
        $check = $resultado !== false ? parent::fetchArray($resultado) : false;
        $return = $check !== false ? ( count($check) === 0 ? false : $check ) : false;
        return $return;
    }

    public function update($table, $field, $value, $attribute = NULL) {

        $check = Util::testArraySize(array($field, $value));
        if ($check !== true) {
            return false;
        } else {
            $fields = NULL;
            $size = count($field);
            for ($i = 0; $i < $size; $i++) {
                $fields[] = $field[$i] . " = '" . $value[$i] . "'";
            }
            $fields = implode(",", $fields);
        }
        $sql = "update " . $table . " set " . $fields . " " . $attribute;
/*        
        echo $sql;    
        die;
*/
        $resultado = parent::query($sql);
        $return = $resultado !== false ? true : false;
        return $return;
    }

    public function delete($table, $attribute = NULL) {
        $sql = "delete from " . $table . " " . $attribute;
/*        
        echo $sql;die;
*/
        $resultado = parent::query($sql);
        $return = $resultado !== false ? true : false;
        return $return;
    }

}

?>