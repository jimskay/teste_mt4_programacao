<?php
/*
>	__construct - Criando Conex�o ODBC (Modelo SQLServer)
*/
class DatabaseSQLServer extends SQLServer {
	
	public function __construct() {
		parent::__construct("SBOMania", "", ""); /*ODBC*/		
	}
	
}
?>