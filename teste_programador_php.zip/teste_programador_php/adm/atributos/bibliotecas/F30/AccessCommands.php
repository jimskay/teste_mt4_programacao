<?php
/*
> queryAccess (public) - executa uma query [1. SQL] # retorna a query consultada
> fetchArrayAccess (private) - retorna um array de uma consulta [1. resultado da consulta , 2. 0=assoc | 1=row] # array[?][assoc]
> listFieldsAccess (public) - lista todas as colunas relativas a uma tabela [1. nome da tabela] # array[?][0]
> specialQueryAccess (public) - executa uma query de sele��o livre [1. query]
*/
abstract class AccessCommands {
	
	private $conexaoAccess;
	private $dbAccess;
	private $dbNameAccess;
	
	public function __construct($dbAccess,$userAccess,$passwordAccess){
		
		try{	
			if(!odbc_connect($dbAccess, $userAccess, $passwordAccess)){ 
				throw  new Exception("Erro ao estabelecer conex�o!"); 
			}else{
				$this->conexaoAccess = odbc_connect($dbAccess, $userAccess, $passwordAccess);	
				//$this->conexaoAccess = odbc_connect("NSSERVICE","","");
				$this->dbNameAccess = $dbAccess;			
			}
		}catch(Exception $e){ 
			echo "Erro ao estabelecer conex�o ODBC no servidor!"; 
		}
		
	}
	
	
	public function __get($var){
		switch($var){
			case 'DbName'	:	return $this->dbNameAccess;	break;
		}
	}
	
	protected function queryAccess($Access){
		$queryAccess = odbc_exec($this->conexaoAccess, $Access);				
		if($queryAccess){
			return $queryAccess;
		}else{
			return false;
		}
	}
	
	protected function fetchArrayAccess($resultadoAccess,$typeAccess = 0){

		$returnAccess = array();			
		
		if($typeAccess==0){
			while( $rowAccess = odbc_fetch_array($resultadoAccess) ){
				$returnAccess[] = $rowAccess;				
			}
		}else{
			while(odbc_fetch_row($resultadoAccess)){
			  $returnAccess[] = odbc_result($resultadoAccess, 1);		
			}
								
		}

		return $returnAccess;
	}	
	
	public function listFieldsAccess($tableAccess){
		switch($tableAccess){
			case "MarcaEquipto":
				$fields = array('C�digo','Descri��o'); break;
			case "Equipamentos":
				$fields = array('[Codigo equipamento]','[Descricao equipamento]','Marca'); break;
			case "Modelos":
				$fields = array('C�digo','[Descri��o modelo]','Equipamento','Marca','Foto'); break;
			case "Pecas":
				$fields = array('[Codigo peca]','[Descricao peca]'); break;
			case "Clientes":
				$fields = array('[Codigo cliente]','[Nome cliente]'); break;
			}
		
		/*
		$fieldsAccess = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE (TABLE_NAME = '".$tableAccess."') ";
		$resultadoAccess = $this->queryAccess($fieldsAccess);
		$returnAccess = $resultadoAccess!==false ? $this->fetchArrayAccess($resultadoAccess,1) : false;
		$returnAccess = $returnAccess!==0 ? $returnAccess : false;<a href="../classes/Access/MarcaEquipto.php">MarcaEquipto.php</a>
		*/
		$returnAccess = $fields;
		return $returnAccess;
	}


	public function specialQueryAccess($queryAccess){
		$resultadoAccess = self::queryAccess($queryAccess);		
		$checkAccess = $resultadoAccess!==false ? self::fetchArrayAccess($resultadoAccess) : false;
		//$checkAccess = $resultadoAccess!==false ? $resultadoAccess : false;
		$returnAccess = $checkAccess!==false ? ( count($checkAccess)===0 ? false : $checkAccess ) : false;
		return $returnAccess;
	}

	
	public function __destruct(){
		odbc_close($this->conexaoAccess);
	}
	
}

?>