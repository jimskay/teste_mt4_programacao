<?php
/*
>	__construct - cria conexao com Database
*/
class Database extends SQL {
	
	public function __construct() {

		$url = explode("/", $_SERVER['SCRIPT_NAME']);

		if ($url[1] == "teste_programador_php") {

			parent::__construct('localhost', 'root', '', 'teste_programador_php');
			
		} else {
			parent::__construct('localhost', 'root', '', 'teste_programador_php');	/*INTERNET*/
		}		
		
	}
	
}
?>