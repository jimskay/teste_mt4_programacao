<?php
/*
>	__construct - Criando Conex�o ODBC (Modelo ACCESS)
*/
class DatabaseAccess extends Access {
	
	public function __construct() {
		parent::__construct("gardenastore", "", ""); /*ODBC*/
	}
	
}
?>