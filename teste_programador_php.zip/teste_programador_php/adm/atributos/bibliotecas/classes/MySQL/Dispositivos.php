<?php

/*
  CLASSE Dispositivo

  > save (public) - salva uma nova informação no DB de dados, seja inserção ou edição # em caso de erro retorna uma mensagem com o erro
  > delete (public) - remove um dado do DB
  > select (public) - seleciona dados do DB relativos a classe corrente [1. atributos para filtragem da consulta] # array com objetos criados
  > security (private) - segurança quando essa classe é salva
  > originalVar (public) - resgata uma variável sem qualquer tipo de formatação [1. nome da variável] # valor original da variável
 */

class Dispositivos {

    private $fields;
    private $db;
    private $idDispositivo;
    private $hostname;
    private $ip;
    private $tipo;
    private $fabricante;

    public function __construct(Database $db, $idDispositivo = NULL) {
        $this->db = $db;
        $fields = $this->db->listFields('dispositivo');
        if ($fields !== false) {
            foreach ($fields as $f) {
                $this->fields[] = $f[0];
            }
        } else {
            $this->fields = NULL;
        }
        if ($idDispositivo !== NULL) {
            $attribute = "where idDispositivo = '" . $idDispositivo . "'";
            $resultado = $this->db->select('dispositivo', $this->fields, $attribute);

            if ($resultado !== false) {

                $this->idDispositivo = $resultado[0]['idDispositivo'];
                $this->hostname      = $resultado[0]['hostname'];
                $this->ip            = $resultado[0]['ip'];
                $this->tipo          = $resultado[0]['tipo'];
                $this->fabricante    = $resultado[0]['fabricante'];
                
            }
        }
    }

    public function __toString() {
        return $this->idDispositivo;
    }

    public function __set($var, $value) {
        switch ($var) {
            
            case 'Hostname'   : $this->hostname = $value;
                break;           
            case 'Ip'         : $this->ip = $value;
                break;
            case 'Tipo'       : $this->tipo = $value;
                break;
            case 'Fabricante' : $this->fabricante = $value;
                break;                    
                      
        }
    }

    public function __get($var) {
        switch ($var) {
            
            case 'idDispositivo'    : return $this->idDispositivo;
                break;
            case 'idDispositivo64'  : return base64_encode($this->idDispositivo);
                break;

            case 'Hostname' : return $this->hostname;
                break;

            case 'Ip' : return $this->ip;
                break;

            case 'Tipo' : return $this->tipo;
                break;

            case 'Fabricante' : return $this->fabricante;
                break;
                                    
        }
    }

    //	SAVE
    public function save($fields = '', $values = '') {

        if ($this->idDispositivo === NULL) {
            return self::insert();
        } else {
            return self::update($fields,$values);
        }
    }

    //	INSERT
    public function insert() {

        $fields = array('hostname', 'ip', 'tipo', 'fabricante');
        $values = array($this->hostname, $this->ip, $this->tipo, $this->fabricante);
        $check  = $this->db->insert('dispositivo', $fields, $values);

        $this->idDispositivo = $check === true ? mysqli_insert_id($this->db->conexao) : NULL;
        $return = $check === true ? true : false;

        return $return;
    }

    //	UPDATE
    public function update($fields = '', $values = '') {
        
        if ($fields == '') {
            $fields = array('hostname', 'ip', 'tipo', 'fabricante');
        }

        if ($values == '') {
            $values = array($this->hostname, $this->ip, $this->tipo, $this->fabricante);
        }

        $attribute  = "where idDispositivo = '" . $this->idDispositivo . "'";
        $check      = $this->db->update('dispositivo', $fields, $values, $attribute);        
        $return     = $check === true ? true : false;

        return $return;
    }

    //	DELETE
    public function delete() {
        if ($this->idDispositivo !== NULL) {
            $attribute = "where idDispositivo = '" . $this->idDispositivo . "'";
            $check = $this->db->delete('dispositivo', $attribute);
            $return = $check === true ? true : false;
        } else {
            $return = false;
        }
        $this->idDispositivo = $return === true ? NULL : $this->idDispositivo;
        return $return;
    }

    //	SELECT
    public function select($attribute = NULL) {
        $resultado = $this->db->select('dispositivo', $this->fields, $attribute);
        if ($resultado !== false) {
            $return = array();
            foreach ($resultado as $f) {
                $return[] = new Pedido($this->db, $f['idDispositivo']);
            }
        } else {
            $return = false;
        }
        return $return;
    }

    //	SECURITY
    private function security() {


        //	idDispositivo
        if ($this->idDispositivo == '') {
            return 'idDispositivo deve estar preenchido.';
        }

        return true;

    }

    public function originalVar($var) {
        return $this->{$var};
    }

}

?>