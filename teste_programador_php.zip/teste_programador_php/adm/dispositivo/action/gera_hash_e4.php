<?PHP
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once "../assets/random_compat/lib/random.php";

function hash_pbkdf2($algo, $password, $salt, $count, $length = 0, $raw_output = false)
{

    if (!in_array(strtolower($algo), hash_algos())) trigger_error(__FUNCTION__ . '(): Unknown hashing algorithm: ' . $algo, E_USER_WARNING);
    if (!is_numeric($count)) trigger_error(__FUNCTION__ . '(): expects parameter 4 to be long, ' . gettype($count) . ' given', E_USER_WARNING);
    if (!is_numeric($length)) trigger_error(__FUNCTION__ . '(): expects parameter 5 to be long, ' . gettype($length) . ' given', E_USER_WARNING);
    if ($count <= 0) trigger_error(__FUNCTION__ . '(): Iterations must be a positive integer: ' . $count, E_USER_WARNING);
    if ($length < 0) trigger_error(__FUNCTION__ . '(): Length must be greater than or equal to 0: ' . $length, E_USER_WARNING);

    $output = '';
    $block_count = $length ? ceil($length / strlen(hash($algo, '', $raw_output))) : 1;
    for ($i = 1; $i <= $block_count; $i++)
    {
        $last = $xorsum = hash_hmac($algo, $salt . pack('N', $i), $password, true);
        for ($j = 1; $j < $count; $j++)
        {
            $xorsum ^= ($last = hash_hmac($algo, $last, $password, true));
        }
        $output .= $xorsum;
    }

    if (!$raw_output) $output = bin2hex($output);
    return $length ? substr($output, 0, $length) : $output;

}

$TextoClaro = urldecode($_GET['q']);
$HashCompar = urldecode($_GET['w']);
$codificada = hash('sha512', $TextoClaro);
$calculo['sha512'] = $codificada;


if ($HashCompar == $calculo['sha512']) {
    $calculo['res_sha512'] = 'Igual';
} else {
    $calculo['res_sha512'] = 'Diferente';
}

$Chave      = base64_encode(hash_pbkdf2( "sha512", "ywng#Z9", "ywng#Z9$", 100000, 0, true ));
$TextoClaro = $_GET['q'];
$Cifra      = 'AES-256-CTR';
$IV         = random_bytes(openssl_cipher_iv_length($Cifra)); 

$TextoCifrado = openssl_encrypt($TextoClaro, $Cifra, $Chave, OPENSSL_RAW_DATA, $IV);

$Resultado = base64_encode($IV.$TextoCifrado);
$calculo['AES256'] = $Resultado;

if ($HashCompar == $calculo['AES256']) {
    $calculo['res_AES256'] = 'Igual';
} else {
    $calculo['res_AES256'] = 'Diferente';
}


$Chave      = base64_encode(hash_pbkdf2( "sha512", "ywng#Z9", "ywng#Z9$", 250000, 0, true ));
$TextoClaro = $_GET['q'];
$Cifra      = 'AES-256-CTR';
$IV         = random_bytes(openssl_cipher_iv_length($Cifra)); 

$TextoCifrado = openssl_encrypt($TextoClaro, $Cifra, $Chave, OPENSSL_RAW_DATA, $IV);

$Resultado = base64_encode($IV.$TextoCifrado);

$calculo['pers'] = $Resultado;

if ($HashCompar == $calculo['pers']) {
    $calculo['res_pers'] = 'Igual';
} else {
    $calculo['res_pers'] = 'Diferente';
}

die(json_encode($calculo)); 

?>