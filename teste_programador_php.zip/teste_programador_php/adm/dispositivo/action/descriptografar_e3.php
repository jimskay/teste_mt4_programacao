<?PHP
session_start();

ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once "../assets/random_compat/lib/random.php";


if ($_GET) {
	
	$Chave      	= $_SESSION['aes_chave'];
	$Cifra 			= 'AES-256-CTR';
	$Resultado  	= urldecode($_GET['q']);
	$Resultado  	= base64_decode($Resultado);
	$TextoCifrado 	= mb_substr($Resultado, openssl_cipher_iv_length($Cifra), null, '8bit');
	$IV 		  	= mb_substr($Resultado, 0, openssl_cipher_iv_length($Cifra), '8bit');
	$TextoClaro   	= openssl_decrypt($TextoCifrado, $Cifra, $Chave, OPENSSL_RAW_DATA, $IV);

	$calculo['aes'] = $TextoClaro;


	/* Descriptografar cifra de César */
		
	$tamanhoAlfabeto  = 256; // Tamanho do alfabeto baseado em tabela
	$n                = 4; // Define quantos algarismos iremos deslocar.
	$fora             = 32; // Define quantos caracteres ficaram fora por serem ilegíveis ao Browser.
	$desCriptografada = '';
	$criptografada 	= urldecode($_GET['w']);

	for ($i=0; $i<strlen($criptografada); $i++) {

	    $key = ord($criptografada[$i]);

	    $novoCodigo = $key - $n;

	    if($novoCodigo >= 0 && $novoCodigo < $fora) {
	        $novoCodigo-= $fora;
	    }

	    if ($novoCodigo < 0) {
	        $novoCodigo = $tamanhoAlfabeto + $novoCodigo;
	    }

	    $desCriptografada.= chr($novoCodigo);

	}

	$calculo['cesar'] = $desCriptografada;


	/* Descriptografa o Personalizado */

	$Chave      	= $_SESSION['pers_chave'];
	$Cifra 			= 'AES-256-CTR';
	$Resultado  	= urldecode($_GET['u']);
	$Resultado  	= base64_decode($Resultado);
	$TextoCifrado 	= mb_substr($Resultado, openssl_cipher_iv_length($Cifra), null, '8bit');
	$IV 		  	= mb_substr($Resultado, 0, openssl_cipher_iv_length($Cifra), '8bit');
	$TextoClaro   	= openssl_decrypt($TextoCifrado, $Cifra, $Chave, OPENSSL_RAW_DATA, $IV);

	$calculo['pers'] = $TextoClaro;

	die(json_encode($calculo));

}


?>