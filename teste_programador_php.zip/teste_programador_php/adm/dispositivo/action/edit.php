<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once('../../global.php');
$fields = array('idDispositivo', 'hostname', 'ip', 'tipo', 'fabricante');

foreach($fields as $f){
	$values[$f] = isset($_POST[$f]) ? $_POST[$f] : NULL;
}

$idDispositivo = base64_decode($values['idDispositivo']);
$dispositivos  = new Dispositivos($db, $idDispositivo);

$dispositivos->Hostname 	= $values['hostname'];
$dispositivos->Ip 			= $values['ip'];
$dispositivos->Tipo 		= $values['tipo'];
$dispositivos->Fabricante 	= $values['fabricante'];
$check 					 	= $dispositivos->save();

/*
if ($equip != false) {

	foreach ($equip as $e) {

		$e->Descricao = $values['descricao'];	
		$check 		  = $e->save();
*/
		if($check===true){
			$session->set('msg','Serviços do Cliente editado com sucesso.');
		}else{
			$session->set('msg',$check);
		}
/*		
	}


}else{
	$session->set('msg','registro n&atilde;o encontrado.');
}
*/

Util::redirect('../index.php');

?>