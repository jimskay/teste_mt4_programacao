<?

require_once('../../global.php');
$fields 	= array('hostname', 'ip', 'tipo', 'fabricante');

foreach($fields as $f){
	$values[$f] = isset($_POST[$f]) ? $_POST[$f] : NULL;
}

$dispositivos			 	= new Dispositivos($db);
$dispositivos->Hostname 	= $values['hostname'];
$dispositivos->Ip 			= $values['ip'];
$dispositivos->Tipo 		= $values['tipo'];
$dispositivos->Fabricante 	= $values['fabricante'];
$check 					 	= $dispositivos->save();

if($check===true){
	$session->set('msg_user','cadastrado com sucesso!');
	Util::redirect('../index.php');
}else{
	$session->set('msg_user',$check);
	Util::redirect('../register.php');
}

?>