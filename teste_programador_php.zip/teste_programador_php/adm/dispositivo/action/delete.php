<?

ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once('../../global.php');

$fields = array('idDispositivo');

foreach($fields as $f){
	$values[$f] = isset($_GET[$f]) ? $_GET[$f] : NULL;
}

$dispositivo = new Dispositivos($db,base64_decode($values['idDispositivo']));

if ($dispositivo->idDispositivo!='') {

	$check = $dispositivo->delete();

	if ($check===true) {

		$session->set('msg','Produto exclu&iacute;do com sucesso.');

	} else {

		$session->set('msg',$check);

	}

} else { 

	$session->set('msg','Produto n&atilde;o encontrado.');

}

Util::redirect('../index.php');
