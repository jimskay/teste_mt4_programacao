<?php

ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
include('./assets/biblioteca_ssh/Net/SSH2.php');
require_once('../global.php');
//$msg = $session->getAndDestroy('msg');

if ($_POST) {

    $login   = $_POST['login'];
    $senha   = $_POST['senha'];
    $dominio = $_POST['dominio'];

    $ssh = new Net_SSH2($dominio);
    if (!$ssh->login($login, $senha)) {
        exit('Login Failed');
    }

    echo $ssh->exec('pwd');
    echo $ssh->exec('ls -la');
/*    
    $con   = ssh2_connect('192.168.0.1', 22);
    ssh2_auth_password($con, $login, $senha);
    $shell = ssh2_shell($con, 'xterm');

    fwrite( $shell, 'cd /www;'.PHP_EOL);
    fwrite( $shell, 'ls -la;'.PHP_EOL);
    fwrite( $shell, 'cd /dir_two;'.PHP_EOL);
    fwrite( $shell, 'ls -la;'.PHP_EOL);
*/
}


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>TESTE PROGRAMADOR PHP</title>

    <link href="<?=ROOT_HTTP_ADMIN?>/atributos/estilos/2.0/bootstrap.min.css" rel="stylesheet">

    <link href="<?=ROOT_HTTP_ADMIN?>/atributos/fonts/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?=ROOT_HTTP_ADMIN?>/atributos/estilos/2.0/animate.min.css" rel="stylesheet">

    
    <link href="<?=ROOT_HTTP_ADMIN?>/atributos/estilos/2.0/custom.css" rel="stylesheet">
    <link href="<?=ROOT_HTTP_ADMIN?>/atributos/estilos/2.0/icheck/flat/green.css" rel="stylesheet">    

    <script src="<?=ROOT_HTTP_ADMIN?>/atributos/js/jquery.min.js"></script>

    <script src="<?=ROOT_HTTP?>atributos/js/jquery-1.10.2.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?=ROOT_HTTP?>/atributos/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="<?=ROOT_HTTP?>/atributos/js/jquery.maskedinput.min.js"></script>
    <!--<script type="text/javascript" src="<?=ROOT_HTTP?>/atributos/js/scripts.js"></script>-->
    <script type="text/javascript" src="<?=ROOT_HTTP?>atributos/js/funcoes_cpf.js"></script>
    

    <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        
        <!--START DATEPICKER-->


    <script type="text/javascript">

        function onlyLower(onlyLowerObj){
            var $obj = onlyLowerObj;
            var $not = /[^a-z|^0-9]/g;
            var $value = $obj.value;
            $obj.value = $value.replace($not,'');
            return null;
        }

        function login(loginForm){
            var $form = loginForm;
            var $loginUsuario = $form.loginUsuario;
            var $senhaUsuario = $form.senhaUsuario;
            var $validation = new Validation();
            if($validation.checkSizeStr($loginUsuario.value,10,6)===false){
                $loginUsuario.focus();
                alert('Preencha o campo usuário corretamente.');
                return false;
            }
            if($validation.checkSizeStr($senhaUsuario.value,10,6)===false){
                $senhaUsuario.focus();
                alert('Preencha o campo senha corretamente.');
                return false;
            }
        }

        function enviar(){
            document.getElementById("loginForm").submit();
        }

    </script>


</head>

<body style="background:#F7F7F7;">
    
    <div class="">
        <a class="hiddenanchor" id="toregister"></a>
        <a class="hiddenanchor" id="tologin"></a>

        <div id="wrapper">
            <div id="login" class="animate form">
                <section class="login_content">
                    <form id="loginForm" action="<?$PHP_SELF?>" method="post" onsubmit="return login(this);">
                        <div>
                            <input type="hidden" class="form-control" name="dominio" value="<?=$_GET['dominio']?>"/>
                        </div>

                        <div>
                            <input type="text" class="form-control" placeholder="Login" required="" name="login"/>
                        </div>

                        <div>
                            <input type="password" class="form-control" placeholder="Senha" required="" name="senha"/>
                        </div>
                        
                        <div>
                            <a class="btn btn-default submit" href="javascript:" onclick="enviar()">Acessar</a>                            
                        </div>
                        <div class="clearfix"></div>
                        <div class="separator">
                            <div class="clearfix"></div>
                            <br />
                            <div>
                                <p>Teste Programador PHP</p>
                            </div>
                        </div>
                    </form>
                    <!-- form -->
                </section>
                <!-- content -->
            </div>
          
        </div>
    </div>

</body>

</html>