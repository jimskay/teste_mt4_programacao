function getSubcategoria(getSubcategoriaCategoria, getSubcategoriaId) {
    var $categoria = getSubcategoriaCategoria;
    if ($categoria == '-1' || $categoria == '') {
        return null;
    } else {
        getSubcategoriaObj = document.getElementById(getSubcategoriaId);
        getSubcategoriaObj.setAttribute('disabled', 'disabled');
        while (getSubcategoriaObj.hasChildNodes()) {
            getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
        }
        var $dom = new Dom();
        var $loading = $dom.option('Carregando . . .', '-1');
        getSubcategoriaObj.appendChild($loading);
        getSubcategoriaAjax = ajaxRequest();
        ajaxCon(getSubcategoriaAjax, getSubcategoriaR, '../atributos/bibliotecas/ajaxPages/getSubcategoria.php', 'codCategoria=' + $categoria, 'get');
    }
}

function getSubcategoriaR() {
    var $dom = new Dom();
    if (getSubcategoriaAjax.readyState == 4) {
        if (getSubcategoriaAjax.status == 200) {
            var $docxml = getSubcategoriaAjax.responseXML;
            if ($docxml.hasChildNodes()) {
                while (getSubcategoriaObj.hasChildNodes()) {
                    getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
                }
                var $subcategorias = $docxml.getElementsByTagName('subcategoria');
                for (var $i = 0; $i < $subcategorias.length; $i++) {
                    var $node = $subcategorias[$i];
                    $option = $dom.option($node.childNodes[0].nodeValue, $node.getAttribute('value'));
                    getSubcategoriaObj.appendChild($option);
                }
                getSubcategoriaObj.removeAttribute('disabled');
                getSubcategoriaObj.focus();
            } else {
                while (getSubcategoriaObj.hasChildNodes()) {
                    getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
                }
                var $error = $dom.option('Erro ao listar subcategorias.', '-1');
                getSubcategoriaObj.appendChild($error);
            }
        } else {
            while (getSubcategoriaObj.hasChildNodes()) {
                getSubcategoriaObj.removeChild(getSubcategoriaObj[0]);
            }
            var $error = $dom.option('P�gina nao encontrada, contate o adminstrador para mais informa�oes.', '-1');
            getSubcategoriaObj.appendChild($error);
        }
    }
}

function register(registerForm) {
    var $form = registerForm;
    var $nomeProduto = $form.nomeProduto;
    var $idCategoria_1 = $form.idCategoria_1;
    var $idSubcategoria_1 = $form.idSubcategoria_1;
    var $valorPrincipalProduto = $form.valorPrincipalProduto;

    //	CHECK ACTION
    if ($form.getAttribute('action') != 'action/register.php') {
        alert('Erro inesperado. Esta p�gina nao pode continuar.');
        self.location = 'index.php';
        return false;
    }

    if ($nomeProduto.value == '') {
        $nomeProduto.focus();
        alert('Preencha corretamente o nome do produto.');
        return false;
    }

    if ($idCategoria_1.value == '-1') {
        $idCategoria_1.focus();
        alert('Adicione ao menos uma categoria.');
        return false;
    }

    if ($valorPrincipalProduto.value == '') {
        $valorPrincipalProduto.focus();
        alert('Informe ao menos o valor principal do produto.');
        return false;
    }
   
    var $q = window.confirm('Deseja realmente cadastrar esse produto?');
    return $q;
}

function edit(registerForm) {
    var $form = registerForm;
    var $nomeProduto = $form.nomeProduto;
    var $idCategoria_1 = $form.idCategoria_1;
    var $idSubcategoria_1 = $form.idSubcategoria_1;
    var $valorPrincipalProduto = $form.valorPrincipalProduto;

    //	CHECK ACTION
    if ($form.getAttribute('action') != 'action/edit.php') {
        alert('Erro inesperado. Esta p�gina nao pode continuar.');
        self.location = 'index.php';
        return false;
    }

    if ($nomeProduto.value == '') {
        $nomeProduto.focus();
        alert('Preencha corretamente o nome do produto.');
        return false;
    }
    
    if ($idCategoria_1.value == '-1') {
        $idCategoria_1.focus();
        alert('Adicione ao menos uma categoria.');
        return false;
    }
    
    // FIM 

    if ($valorPrincipalProduto.value == '') {
        $valorPrincipalProduto.focus();
        alert('Informe ao menos o valor principal do produto.');
        return false;
    }

    var $q = window.confirm('Deseja realmente editar esse produto?');
    return $q;
}

function disable(registerForm) {
    var $form = registerForm;

    //	CHECK ACTION
    if ($form.getAttribute('action') != 'action/disable.php') {
        alert('Erro inesperado. Esta p�gina nao pode continuar.');
        self.location = 'index.php';
        return false;
    }

    var $q = window.confirm('Deseja realmente inativar esse produto?');
    return $q;
}

function deleteForm(registerForm) {
    var $form = registerForm;

    //	CHECK ACTION
    if ($form.getAttribute('action') != 'action/delete.php') {
        alert('Erro inesperado. Esta p�gina nao pode continuar.');
        self.location = 'index.php';
        return false;
    }

    var $q = window.confirm('Deseja realmente excluir esse produto?');
    return $q;
}

function enable(registerForm) {
    var $form = registerForm;

    //	CHECK ACTION
    if ($form.getAttribute('action') != 'action/enable.php') {
        alert('Erro inesperado. Esta p�gina nao pode continuar.');
        self.location = 'index.php';
        return false;
    }

    var $q = window.confirm('Deseja realmente ativar esse produto?');
    return $q;
}

function formataUrlAmigavel(url) {
    $nomeEmpresa = url;
    $url = document.getElementById("urlAmigavel");
    $nomeEmpresa = $nomeEmpresa.replace(/(\.)|(\')|(\,)|(\[)|(\])|(\;)|(\:)|(\_)|(\~)|(\^)|(\´)|(\`)|(\=)|(\-)|(\/)|(\\)|(\()|(\))/g, "");
    $nomeEmpresa = $nomeEmpresa.toLowerCase();


    var specialChars = [
        {val: "a", let: "�����"},
        {val: "e", let: "����"},
        {val: "i", let: "����"},
        {val: "o", let: "����"},
        {val: "u", let: "����"},
        {val: "c", let: "�"},
        {val: "�", let: "n"},
        {val: "A", let: "�����"},
        {val: "E", let: "����"},
        {val: "I", let: "����"},
        {val: "O", let: "����"},
        {val: "U", let: "����"},
        {val: "C", let: "�"},
        {val: "�", let: "N"},
        {val: "", let: "!@#$%�&*()_+��������[~],.;`{^}<>:��/?|\'"}
    ];

    var $spaceSymbol = '-';
    var regex;
    var returnString = $nomeEmpresa;
    for (var i = 0; i < specialChars.length; i++) {
        regex = new RegExp("[" + specialChars[i].let + "]", "g");
        returnString = returnString.replace(regex, specialChars[i].val);
        regex = null;
    }
    $url.value = returnString.replace(/\s/g, $spaceSymbol);
}

function formataTituloSEO(url) {
    $nomeEmpresa = url;
    $url = document.getElementById("tituloPaginaSEOProduto");
    $url.value = $nomeEmpresa;
}

function formataMetatags(url) {
    $nomeEmpresa = url;
    $url = document.getElementById("metatagsSEOProduto");
    $nomeEmpresa = $nomeEmpresa.replace(/(\ )/g, ",");
    $nomeEmpresa = $nomeEmpresa.toLowerCase();


    var specialChars = [
        {val: ",", let: " "}
    ];

    var regex;
    var returnString = $nomeEmpresa;
    for (var i = 0; i < specialChars.length; i++) {
        regex = new RegExp("[" + specialChars[i].let + "]", "g");
        returnString = returnString.replace(regex, specialChars[i].val);
        regex = null;
    }
    $url.value = returnString;
}

function formataDescricaoSEO(text) {
    console.log('oi');
}
