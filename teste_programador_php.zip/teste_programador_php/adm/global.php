<?php

//	QUIDDE COMPANY
//	UTILIZANDO FRAMEWORK 3.0
//	INTEGRA��O DE BASES DE DADOS (MYSQL, SQL SERVER E ACCESS)
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

define('FRAMEWORK', 'atributos/bibliotecas/F30/');
define('CLASSES', 'atributos/bibliotecas/classes/');
define('CONTROLLER', 'atributos/bibliotecas/controller/');

define('ACCESS', CLASSES . 'Access/');
define('MYSQL', CLASSES . 'MySQL/');
define('SQLSERVER', CLASSES . 'SQLServer/');

$url = explode("/", $_SERVER['SCRIPT_NAME']);

//define('ROOT', '/templates/fulltec/rc_widgets/fulltecprint/'); /* SERVER */
define('ROOT', '/teste_programador_php/'); /* SERVER */
define('ROOT_HTTP', 'http://' . $_SERVER['SERVER_NAME'] . ROOT);


define('ADMIN', 'adm/');
define('ROOT_DIR', str_replace('adm', '', dirname(__FILE__)));
define('ROOT_HTTP_ADMIN', 'http://' . $_SERVER['SERVER_NAME'] . ROOT . ADMIN);
define('ROOT_DIR_ADMIN', ROOT_DIR . ADMIN);
define('PROTOCOLO', (strpos(strtolower($_SERVER['SERVER_PROTOCOL']), 'https') === false) ? 'http://' : 'https://');
define('URL_FULL', PROTOCOLO . $_SERVER['SERVER_NAME'] . $_SERVER['SCRIPT_NAME']);

define('TITLE_PAGE', 'Administrativo - Fulltec');
define('TITLE', 'Fulltec');

function __autoload($className) {

    $return = file_exists(ROOT_DIR_ADMIN . MYSQL . $className . '.php') ? true : false;
    if ($return === true) {
        require_once(ROOT_DIR_ADMIN . MYSQL . $className . '.php');
    } else {
        $return = file_exists(ROOT_DIR_ADMIN . ACCESS . $className . '.php') ? true : false;
        if ($return === true) {
            require_once(ROOT_DIR_ADMIN . ACCESS . $className . '.php');
        } else {
            $return = file_exists(ROOT_DIR_ADMIN . FRAMEWORK . $className . '.php') ? true : false;

            if ($return === true) {
                require_once(ROOT_DIR_ADMIN . FRAMEWORK . $className . '.php');                
            } else {
                $return = file_exists(ROOT_DIR_ADMIN . CONTROLLER . $className . '.php') ? true : false;

                if ($return === true) {
                    require_once(ROOT_DIR_ADMIN . CONTROLLER . $className . '.php');
                } else {
                    echo 'Classe ' . $className . ' n&atilde;o encontrada. programa n&atilde;o pode continuar.';
                }
            }
        }
    }
}

function pr($variable) {
    echo '<pre>';
    echo print_r($variable, true);
    echo '</pre>';
}

if(!isset($session)) {
    $session = new Session();
}

if(!isset($db)){

    try {

        $db = new Database();

    } catch ( Exception $e ) {

        echo 'Erro ao conectar';
        exit ();

    }   

}

?>
