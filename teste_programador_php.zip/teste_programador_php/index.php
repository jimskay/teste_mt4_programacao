<?php
require_once('adm/global.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>

<META http-equiv="refresh" content="0;URL=http://<?=$_SERVER['SERVER_NAME'] . ROOT . ADMIN?>dispositivo/index.php">

</head>

<body></body>

</html>