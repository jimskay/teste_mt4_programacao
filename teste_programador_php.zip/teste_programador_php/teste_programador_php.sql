/*
SQLyog Community Edition- MySQL GUI v6.15
MySQL - 5.5.34-0ubuntu0.13.04.1 : Database - teste_programador_php
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `teste_programador_php`;

USE `teste_programador_php`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `dispositivo` */

DROP TABLE IF EXISTS `dispositivo`;

CREATE TABLE `dispositivo` (
  `idDispositivo` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `fabricante` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idDispositivo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `dispositivo` */

insert  into `dispositivo`(`idDispositivo`,`hostname`,`ip`,`tipo`,`fabricante`) values (1,'www.teste.com.br','120.0.0.0','roteador','cisco');
insert  into `dispositivo`(`idDispositivo`,`hostname`,`ip`,`tipo`,`fabricante`) values (2,'https://teste1.teste.com.br','200.200.0.1','switch','us robotics');
insert  into `dispositivo`(`idDispositivo`,`hostname`,`ip`,`tipo`,`fabricante`) values (5,'teste','122.230.2.2','hub','system');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
